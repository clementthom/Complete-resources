# Chapter 12: Modulation Matrix, Patch Storage, and Advanced Performance Features

---

## 12.1 Introduction

Modern synthesizers stand out not only for their sound engine, but for their flexibility in modulation and patch management. A modulation matrix allows any source (LFO, envelope, MIDI controller, etc.) to affect any destination (pitch, filter, VCA, effect, etc.)—sometimes with complex scaling, logic, and dynamic assignment. Patch storage lets users save and recall entire synth states for performance or composition. This chapter details their theory, design, implementation, and best practices for advanced, expressive hybrid synths.

---

## 12.2 Modulation Routing: Matrix vs. Hardwired

- **Hardwired:** Fixed routing; e.g., LFO always to vibrato, envelope always to amp.
- **Matrix:** Dynamic, assignable; user (or code) can route any source to any destination, set depth (amount), and often polarity (positive/negative).
- **Classic examples:** Oberheim Xpander/Matrix-12, Korg MS-20 (patch panel), modern VSTs.

---

## 12.3 Mod Matrix Architecture

### 12.3.1 Sources

- Envelopes (amp, filter, mod)
- LFOs (per-voice, global)
- Velocity, aftertouch, mod wheel (MIDI)
- Pitch bend, key tracking
- Macros, external CVs, sequencer tracks

### 12.3.2 Destinations

- Oscillator pitch, pulse width, waveform
- Filter cutoff, resonance
- VCA level, panning
- FX parameters, mod matrix depth (meta-modulation)
- Custom/internal parameters

---

## 12.4 Data Structures in C

```c name=include/modmatrix.h
#define MAX_MOD_SOURCES 16
#define MAX_MOD_DESTINATIONS 16
#define MAX_MOD_ENTRIES 32

typedef struct {
    int src_idx;     // Source index (enum or ID)
    int dst_idx;     // Destination index (enum or ID)
    float amount;    // Depth, positive or negative
} ModEntry;

typedef struct {
    float sources[MAX_MOD_SOURCES];
    float destinations[MAX_MOD_DESTINATIONS];
    ModEntry entries[MAX_MOD_ENTRIES];
    int num_entries;
} ModMatrix;
```

---

## 12.5 Matrix Operation

- Each audio frame, refill sources array (LFOs, envelopes, MIDI, etc.).
- Zero destinations array.
- For each ModEntry:  
  `destinations[dst_idx] += sources[src_idx] * amount;`
- Apply destination values to synth parameters (pitch, cutoff, VCA, etc.).

---

## 12.6 Dynamic Routing and UI

- Allow user to assign sources/destinations and set amount via UI, MIDI learn, or SysEx.
- Store all routing in patch data for recall.

---

## 12.7 Example: Mod Matrix Assignment

- Slot 0: LFO1 → Osc1 pitch, +0.3
- Slot 1: Env1 → Filter cutoff, +0.6
- Slot 2: Mod wheel → LFO1 depth, -0.5
- Slot 3: Velocity → Amp, +1.0

---

## 12.8 Patch Storage and Management

### 12.8.1 What is a Patch?

- A complete snapshot of synth state:
  - Oscillator settings, filter, envelopes
  - Mod matrix assignments
  - UI state, macros, routings
  - FX, output, performance settings

### 12.8.2 Patch Format

- **Text (JSON, YAML):** Easy to read/modify, portable.
- **Binary:** Fast, compact, not user-friendly.
- **SysEx:** For MIDI-based storage/recall and compatibility with other gear/software.

---

## 12.9 C Implementation: Patch Serialization

```c name=include/patch.h
typedef struct {
    OscillatorParams osc_params[MAX_OSC];
    FilterParams filter_params;
    EnvelopeParams env_params[MAX_ENVS];
    ModMatrix mod_matrix;
    // ... UI, FX, macro, etc.
    char name[32];
} Patch;

void patch_save(FILE *f, Patch *patch);
void patch_load(FILE *f, Patch *patch);
```

- Use simple `fwrite`/`fread` for binary, or serialize to text for JSON/YAML.

---

## 12.10 Patch Recall and Performance

- Recall must be fast (<100ms typical).
- Always mute or fade-out audio during patch change to prevent clicks.
- Restore all parameter values, modulation matrix, and UI state.
- Recall can be triggered by UI, MIDI program change, or SysEx.

---

## 12.11 Advanced Features: Macros, Morphing, Scenes

### 12.11.1 Macro Controls

- One physical control (knob, slider, MIDI CC) changes multiple parameters together (e.g., morph between pads and leads).
- Store macro assignments in patch.

### 12.11.2 Patch Morphing

- Interpolate between two patches:  
  `param_i = (1 - t) * patchA.param_i + t * patchB.param_i`
- Morph all params, matrix entries, etc., in real time for evolving sounds.

### 12.11.3 Scenes and Performance Sets

- Group patches, routings, and sequences for live performance.
- Allow instant recall of complex setups with a single button or MIDI command.

---

## 12.12 MIDI and SysEx for Patch Management

- Define custom SysEx messages for patch dump/load, matrix assignment, macro mapping, etc.
- Allow backup/restore of all user patches via MIDI.

---

## 12.13 Robustness and Versioning

- Always include a version number in patch formats for future compatibility.
- Check CRC or hash on patch load to guard against corruption.
- Fallback to default patch on error.

---

## 12.14 Exercise: Mod Matrix and Patch Storage Demo

1. Implement a mod matrix as above.
2. Add a UI page for assigning sources/destinations and setting depth.
3. Save a patch to file (or memory); change settings; reload and verify.
4. Implement patch morphing and macro assignment; experiment with expressive control.

---

## 12.15 Debugging and Best Practices

- Log all patch load/save events and errors.
- Print current matrix assignments for debugging.
- Test patch recall under stress (rapid changes, during playback).

---

## 12.16 Further Reading

- [Matrix-12/Expander Modulation Matrix Manual](http://www.synthmanuals.com/manuals/oberheim/matrix-12/owners_manual/)
- [Sound On Sound: Advanced Modulation Techniques](https://www.soundonsound.com/techniques/advanced-synth-modulation)
- [Open Source Matrix Synth Projects](https://mutable-instruments.net/archive/schematics.html)
- [SysEx MIDI Standard](https://www.midi.org/specifications-old/item/table-4-universal-system-exclusive-messages)

---

**End of Chapter 12**

*Next: Chapter 13 — Effects, Audio Output, and Final Signal Path*  
*Let me know if you want to continue with effects, calibration/troubleshooting, or appendices!*