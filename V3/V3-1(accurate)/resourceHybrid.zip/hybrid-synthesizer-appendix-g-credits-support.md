# Appendix G: Credits and Support

---

## G.1 Author and Contributors

- **Lead Author:** Clement Thom  
  Design, writing, editing, and technical review.

- **Contributors:**  
  - [Your Name Here] — Code contributions, testing, feedback
  - [Community usernames or real names as appropriate]
  - [Add others as the project grows]

- **Special Thanks:**  
  - DIY synth community at Mod Wiggler, Lines, and r/synthdiy
  - Open-source firmware projects: Mutable Instruments, Zynthian, Axoloti, and more
  - All testers, reviewers, and supporters

---

## G.2 How to Get Support

- **GitHub Issues:**  
  If you find errors, unclear instructions, or bugs in the documentation or code, please open an issue on the project’s GitHub repository.

- **Community Forums:**  
  For technical questions, troubleshooting, and inspiration, check:
  - [Mod Wiggler Forum](https://www.modwiggler.com/forum/)
  - [Lines](https://llllllll.co/)
  - [Reddit: r/synthdiy](https://www.reddit.com/r/synthdiy/)

- **Direct Contact:**  
  For specific questions to the author, use the contact email provided in the project’s GitHub profile or repository.

---

## G.3 How to Contribute

- **Documentation:**  
  Submit suggestions, corrections, or improvements via pull requests or issues on GitHub.

- **Code and Hardware:**  
  Fork the repo, make your changes, and open a pull request with detailed notes.

- **Test and Report:**  
  Build the synth, test features, and report bugs, quirks, or usability notes.

- **Share Your Build:**  
  Tag your project photos, videos, or blog posts with #HybridSynthBook  
  Share your mods, panels, or completed units in the synth DIY forums.

---

## G.4 Ongoing Development

- The project aims to remain open and actively maintained.
- New features, hardware support, and documentation updates will be announced via the repo and community channels.
- Contributions and collaboration are encouraged!

---

**Thank you for being part of the hybrid synth builder community!**

**End of Resource**