# Chapter 1: Introduction, History, and Goals

## 1.1 Introduction

Welcome to the first chapter of the Hybrid Synthesizer Course. This comprehensive resource aims to take you, from a complete beginner, through the entire journey of understanding, designing, and building a hybrid synthesizer inspired by legendary instruments such as the Synclavier 9600, Fairlight Series III, Emulator III, PPG Wave 2.3, PPG Realiser, Yamaha DX1, Oberheim Matrix-12, and OB-X. This chapter will cover the background and context for these instruments, the evolution of hybrid synthesizers, and the goals and philosophy behind this project. We'll also set expectations for what you will learn and build.

---

## 1.2 What is a Hybrid Synthesizer?

A **hybrid synthesizer** combines both digital and analog components. Typically, digital oscillators or sound generators create the initial waveform, while analog circuits handle filtering, amplification, and sometimes modulation. This hybrid approach seeks to combine the flexibility and power of digital synthesis with the warmth and character of analog audio processing.

**Key characteristics:**
- **Digital sound sources:** Oscillators, samplers, wavetables.
- **Analog processing:** Filters (VCF), amplifiers (VCA), sometimes even envelope generators or LFOs.
- **Voice architecture:** Polyphonic, often multi-timbral, with each 'voice' comprising its own signal path.
- **User Interface:** Historically complex, often using screens, soft keys, and tactile controls.

---

## 1.3 Historical Overview: Classic Hybrid Synths

### Synclavier 9600
- Developed in the late 1970s and 1980s by New England Digital.
- Combined FM synthesis, additive synthesis, sampling, and digital control.
- Used digital oscillators and analog VCA/filter boards.
- Featured a unique computer-based UI (monochrome or limited color).

### Fairlight Series III
- Australian sampler and workstation (early 1980s).
- Pioneered digital sampling with analog processing.
- Large touch-sensitive screen, computer interface, and light pen.

### Emulator III
- American sampler (E-mu Systems, late 1980s).
- Digital sampling, SSM analog filters.
- Known for its punchy, musical sound.

### PPG Wave 2.3 & PPG Realiser
- German hybrid synths (early/mid 1980s).
- Digital wavetable oscillators, analog filters.
- Realiser was a visionary, ultra-flexible digital music workstation.

### Yamaha DX1
- Flagship FM synth (mid-1980s).
- All-digital, but included for its advanced voice allocation, keyboard, and interface.

### Oberheim Matrix-12 & OB-X
- Polyphonic analog synths, with advanced modulation and voice architecture.
- Matrix-12: digitally controlled analog, flexible routing.

---

## 1.4 Goals of This Project

The aim is to design and build a **modern hybrid synthesizer** that:
- Draws inspiration from the flexibility and sound of the classics.
- Uses a modular, voice-based architecture (one .c file per voice component).
- Emulates oscillators digitally (on a Pi 4, output via DAC).
- Processes audio analogically (custom filter/amp boards).
- Is easily portable from PC (Linux, using PortAudio) to Raspberry Pi (bare metal, then Linux).
- Is coded entirely in C for performance and portability.
- Will be designed for maximum flexibility, modularity, and speed.
- Uses modern tools for electronics design (KiCAD), simulation (SPICE), and software (Git, GitHub).

---

## 1.5 Why Hybrid? Why Not All Digital or All Analog?

- **Analog warmth:** True analog circuits impart desirable nonlinearities, saturation, and unpredictability.
- **Digital flexibility:** Oscillators, complex envelopes, modulation, and sampling are easier and more powerful digitally.
- **Best of both worlds:** Hybrid synths can sound unique and musical, with digital control and analog soul.

---

## 1.6 Learning Outcomes

By the end of this course, you will:
- Understand the history and architecture of hybrid synthesizers.
- Master the basics and advanced topics of C programming for embedded systems.
- Learn the fundamentals of digital and analog audio.
- Design digital oscillators, envelopes, LFOs, and voice allocation logic.
- Interface a Raspberry Pi 4 with DACs and analog circuits.
- Design, simulate, and build analog filter and VCA boards.
- Port your code from PC to Raspberry Pi (bare metal and Linux).
- Use PortAudio for cross-platform audio on Linux.
- Test, debug, and simulate both software and hardware.
- Build a user interface for your synth.
- Assemble, calibrate, and create sounds on your own hybrid synthesizer.

---

## 1.7 Course Structure

The course is organized as follows:

1. **Introduction, History, and Goals** (this chapter)
2. **Project Management & Git/GitHub Basics**
3. **C Programming for Embedded Systems (Basics)**
4. **C Programming (Advanced Topics: Pointers, Structs, Memory)**
5. **Audio Fundamentals: Digital and Analog Sound**
6. **Oscillator Theory and Implementation (w/ DACs)**
7. **Analog Electronics for Synthesizers (Filters, VCAs, Signal Routing)**
8. **Envelopes, LFOs, and Modulation Sources**
9. **Polyphony & Voice Allocation**
10. **Interfacing Pi 4 with DACs and Analog Circuits**
11. **Porting: PC to Raspberry Pi (Bare Metal to Linux)**
12. **Audio I/O on Linux with PortAudio**
13. **Testing, Debugging, and Simulation**
14. **Building the UI: Basic Controls, MIDI**
15. **Final Assembly, Calibration, and Sound Design**

Each chapter will contain:
- Detailed explanations (no detail omitted).
- Example code in C.
- Practical exercises and mini-projects.
- Circuit diagrams and simulation instructions.
- Step-by-step advice for both software and hardware.

---

## 1.8 What You Need

### Software
- C compiler (GCC)
- Git
- PortAudio
- KiCAD (for PCB and analog design)
- SPICE (for electronics simulation)
- (Later) cross-compilers for Raspberry Pi

### Hardware
- PC (Linux recommended)
- Raspberry Pi 4
- DAC (e.g., MCP4922 or PCM5102A)
- Breadboard and basic electronic components
- Oscilloscope (optional, but very useful)
- Soldering tools (for final assembly)
- Analog filter and amp components (covered later)

---

## 1.9 Philosophy: No Detail Omitted

This course will **leave no relevant detail unexplained**. Whether it's why you need to debounce a button, how pointer arithmetic works in C, or how to prevent aliasing in digital oscillators, you'll find full explanations and references.

**Learning by doing:** Each chapter ends with a hands-on exercise or mini-project. You will build as you learn.

---

## 1.10 The Big Picture

You are about to embark on a journey from **complete beginner** to **hybrid synth designer**. By the end, you will have:
- A working hybrid synthesizer you designed, built, and programmed.
- Deep understanding of both software and hardware, from C to analog circuits.
- The skills to tackle even more ambitious musical instrument projects.

---

## 1.11 Practical Exercise: Research and Listening

Before diving into code or electronics, spend a few hours listening to and reading about the synths that inspired this project. Try to find:
- Audio demos of the Synclavier, Fairlight, Emulator III, PPG Wave, DX1, Matrix-12, and OB-X.
- Videos or schematics of their user interfaces and internals.
- User manuals (many are available online).
- Reviews and analysis of what made these instruments unique.

**Write down (in your own notes):**
- What sounds or features inspire you most?
- What do you wish to achieve with your own instrument?
- Any questions you have at this point.

---

## 1.12 Chapter Summary

This chapter covered the historical and technical context for your project, the rationale for a hybrid synthesizer, and what you will learn and build. The next chapter will introduce project management and Git basics—a critical skill for any modern embedded system developer.

---

## 1.13 Further Reading

- [VSE: Classic Digital and Hybrid Synths](https://www.vintagesynth.com/)
- [Fairlight CMI Documentation Archive](http://www.cmiarchive.com/)
- [The Synclavier Story](https://www.synclavier.com/history/)
- [E-mu Emulator III Service Manual](https://archive.org/details/emu-emulator-iii-service-manual)
- [PPG Wave and Realiser info](https://greatsynthesizers.com/en/review/ppg-wave-2-2-3/)
- [Matrix-12 Service Manual](https://www.synthxl.com/oberheim-matrix-12-service-manual/)
- [Yamaha DX1 info](https://dx1.org/)

---

**End of Chapter 1**

*Next: Chapter 2 - Project Management & Git/GitHub Basics*