# Chapter 11: User Interface, MIDI, and Control Integration

---

## 11.1 Introduction

A synthesizer is only as powerful as its interface. The user interface (UI) and control system are what transform your hybrid synth from a science experiment into a musical instrument. In this chapter, we’ll explore the theory and practical design of user interfaces, MIDI integration, real-time control, and their implementation in both hardware and software. We’ll cover everything from classic knobs and switches to modern touchscreens, from direct GPIO to robust MIDI and USB MIDI handling.

---

## 11.2 User Interface Philosophy

- **Expressivity:** Controls should allow nuanced, real-time performance.
- **Clarity:** The interface must make the synth’s structure and modulation clear.
- **Efficiency:** Changes should be fast, with minimal menu-diving or confusion.
- **Feedback:** The UI should show, via lights, displays, or sound, what the synth is doing.

---

## 11.3 Types of Synthesizer UI

### 11.3.1 Classic Hardware UI

- **Knobs:** Continuous analog control (potentiometers or encoders).
- **Sliders:** For envelopes, mixing, or filter sweeps.
- **Switches:** Mode selection (e.g., waveform, octave, routing).
- **Buttons:** Note triggers, menu navigation, program change.
- **LEDs:** Status, VU meters, parameter indication.

### 11.3.2 Modern UI

- **OLED or LCD displays:** For parameter values, patch names, graphic envelopes, etc.
- **Touchscreens:** Direct parameter manipulation, XY pads, menus.
- **Rotary encoders:** For endless parameter adjustment and menu navigation.
- **RGB LEDs:** For color-coded feedback, LFO/envelope visualization.

### 11.3.3 Software UI

- **Headless control:** SSH, web UI, or OSC for remote control.
- **DAW integration:** VST/AU plugins, control surfaces.
- **Custom editor software:** Patch management, modulation visualization.

---

## 11.4 Physical Controls: Interfacing with the Pi

### 11.4.1 Reading Pots and Encoders

- Use ADC chips (e.g., MCP3008, ADS1115) for analog pots (Pi has no built-in ADC!).
- Digital rotary encoders: read via GPIO with interrupts or polling.
- Debouncing: necessary for clean, jitter-free readings.

### 11.4.2 Button and Switch Handling

- Use GPIO input with pull-up/pull-down resistors.
- Detect rising/falling edges for event-driven control.
- Implement debounce logic in software (delay or state machine).

### 11.4.3 LEDs and Display Output

- Drive single LEDs via GPIO or shift registers.
- Use I2C/SPI for OLEDs, LCDs, or LED matrices.
- Update display at a lower rate (~10-30Hz) to save CPU.

---

## 11.5 MIDI Integration

### 11.5.1 What is MIDI?

- **Musical Instrument Digital Interface:** 1983 standard for digital music control.
- Serial protocol, 31.25 kbaud, 8N1 format, 16 channels, 128 notes, CCs, pitch bend, program change, etc.
- Used for note data, modulation, clock sync, patch changes.

### 11.5.2 MIDI on the Raspberry Pi

- **USB MIDI:** Most modern controllers connect via USB; Pi recognizes as `/dev/midi*` or ALSA MIDI devices.
- **DIN MIDI (5-pin):** Use serial UART on Pi GPIO + opto-isolator for classic hardware.
- **BLE MIDI:** Wireless, for advanced builds.

### 11.5.3 MIDI Libraries in C

- **RtMidi:** Cross-platform, works on Pi/Linux.
- **ALSA MIDI API:** Native Linux support.
- **Raw UART:** For low-level, bare-metal MIDI parsing.

---

## 11.6 MIDI Message Types

- **Note On/Off:** Play/release notes.
- **Control Change (CC):** Continuous controllers (mod wheel, sustain pedal, etc).
- **Pitch Bend:** High-resolution pitch mod.
- **Program Change:** Patch change.
- **Aftertouch (Channel/Poly):** Expressive pressure data.
- **Clock, Start/Stop:** Syncing arpeggiators, sequencers.

---

## 11.7 MIDI Message Parsing in C

### 11.7.1 Data Structures

```c name=include/midi.h
typedef struct {
    uint8_t status;
    uint8_t data1;
    uint8_t data2;
    uint32_t timestamp;
} MidiMsg;
```

### 11.7.2 Basic Parser

```c name=src/midi/midi.c
void midi_parse_byte(uint8_t byte, MidiMsg *msg, int *state) {
    // Parse incoming bytes into full MIDI messages (state machine)
    // ... (implementation)
}
```
Handle running status, SysEx, and multi-byte messages.

---

## 11.8 Control Mapping

- **Fixed mapping:** Each CC or knob is hardwired to a parameter.
- **Learn mode:** User assigns a control to a parameter by twiddling.
- **Matrix mapping:** Each physical or MIDI control can be routed to any parameter with adjustable depth, just like mod matrix.

---

## 11.9 Real-Time Parameter Update

- All parameter changes must be thread-safe and glitch-free.
- Use atomic operations or lock-free queues for UI-to-audio thread communication.
- Implement smoothing or slew-limiting for abrupt parameter jumps (prevents zipper noise).

---

## 11.10 Patch Management

- **Patches:** Complete synth state (oscillators, envelopes, mod matrix, UI settings).
- **Storage:** Use SD card, Pi filesystem, or EEPROM.
- **Loading/saving:** Via UI, MIDI SysEx, or USB.

### 11.10.1 Patch File Format

- Text: JSON, YAML, or custom syntax (easy for users to edit).
- Binary: More compact, harder to hack.

---

## 11.11 Display and Feedback

- Show patch name, key parameters, LFO/envelope shapes.
- Use bar-graphs for levels, meters for modulation amount.
- Flash or color-code LEDs on state changes (MIDI received, patch changed, error).

---

## 11.12 Advanced UI Topics

### 11.12.1 Menu Systems

- Use rotary encoders + button for hierarchical menus (like Elektron, Waldorf, etc).
- For touchscreens, design clear, finger-friendly layouts.

### 11.12.2 Macro Controls

- One knob controls multiple parameters (e.g., "morph" between sounds).
- Assignable via UI or MIDI.

### 11.12.3 Performance Controls

- X/Y pads, ribbons, aftertouch, breath control, foot pedals.
- Integrate into mod matrix for real-time expressivity.

---

## 11.13 Exercise: Building a Minimal UI and MIDI Handler

1. Wire up a rotary encoder and button to the Pi.
2. Write C code to read encoder steps and button presses (GPIO or via library).
3. Display parameter changes on an OLED or print to console.
4. Connect a USB or DIN MIDI controller; parse note on/off and CC messages.
5. Map MIDI CC to filter cutoff; adjust in real time, listening for smoothness and musicality.

---

## 11.14 Debugging and Robustness

- Print/log all control events for debugging.
- Implement error dialogs or LED blink codes for hardware faults.
- Test for stuck notes, double triggers, missed UI events.

---

## 11.15 Further Reading

- [MIDI 1.0 Detailed Specification](https://www.midi.org/specifications/midi1-specifications)
- [RtMidi C++ Library](https://www.music.mcgill.ca/~gary/rtmidi/)
- [WiringPi GPIO Library](http://wiringpi.com/)
- [OpenDeck: DIY MIDI Controller Platform](https://github.com/shanteacontrols/OpenDeck)
- [ALSA MIDI API Docs](https://www.alsa-project.org/alsa-doc/alsa-lib/seq.html)

---

**End of Chapter 11**

*Next: Chapter 12 — Modulation Matrix, Patch Storage, and Advanced Performance Features*