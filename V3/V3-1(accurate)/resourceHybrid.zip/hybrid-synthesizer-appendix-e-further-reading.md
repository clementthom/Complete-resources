# Appendix E: Further Reading and Resources

---

## E.1 Books and Print References

- **"Handbook for Synthesizer Programming"** — Peter Gorges  
  Classic overview of analog and digital synthesis, with practical programming tips.
- **"The Art of Electronics"** — Paul Horowitz & Winfield Hill  
  Definitive textbook for analog and digital circuit design.
- **"Make: Analog Synthesizers"** — Ray Wilson  
  Hands-on DIY synth circuits and explanations.
- **"Electronic Music: Systems, Techniques, and Controls"** — Allen Strange  
  Foundation text for modular synthesis and electronic music concepts.
- **"Musical Applications of Microprocessors"** — Hal Chamberlin  
  Early but in-depth guide to digital audio and MIDI system building.

---

## E.2 Online Tutorials and Guides

- [Mutable Instruments GitHub](https://github.com/pichenettes/eurorack) — Open-source hybrid synth designs, code, and schematics.
- [Electrosmash: Audio Effect Analysis & Circuits](https://www.electrosmash.com/) — Deep dives into classic pedal and synth circuits.
- [Synth DIY Wiki](https://sdiy.info/) — Extensive wiki for all things synth building.
- [Open Music Labs](http://www.openmusiclabs.com/) — Tutorials on analog and digital synth circuits.
- [Look Mum No Computer](https://www.lookmumnocomputer.com/) — Entertaining YouTube & blog for wild synth DIY projects.

---

## E.3 Technical Standards and Specifications

- [MIDI 1.0 Complete Specification](https://www.midi.org/specifications/midi1-specifications)
- [ALSA Project Documentation](https://www.alsa-project.org/alsa-doc/) — Linux audio/MIDI API.
- [Raspberry Pi Documentation](https://www.raspberrypi.com/documentation/)
- [PT2399 Datasheet](https://www.princeton.com.tw/Portals/0/Product/PT2399.html) — For digital delay effects.
- [LM13700 Datasheet](https://www.ti.com/product/LM13700) — OTA for VCF, VCA, and more.

---

## E.4 Open Source Projects and Firmware

- [Mutable Instruments Firmware](https://github.com/pichenettes/eurorack)
- [OpenDeck MIDI Platform](https://github.com/shanteacontrols/OpenDeck)
- [Helm Synthesizer](https://tytel.org/helm/) — Modern open-source cross-platform synth.
- [Zynthian](https://zynthian.org/) — Raspberry Pi-based multi-engine synth and effects platform.
- [Axoloti](https://www.axoloti.com/) — DIY digital modular synth toolkit.

---

## E.5 Community Forums and Support

- [Mod Wiggler Forum](https://www.modwiggler.com/forum/) — Largest synth DIY community.
- [Lines](https://llllllll.co/) — Open-source instrument and sound design community.
- [Reddit: r/synthdiy](https://www.reddit.com/r/synthdiy/) — Synth DIY subreddit.
- [DIY Stompboxes Forum](https://www.diystompboxes.com/smfforum/) — Focused on effects circuits.

---

## E.6 Parts and Fabrication

- [Tayda Electronics](https://www.taydaelectronics.com/) — Affordable parts, knobs, jacks, and enclosures.
- [Thonk](https://www.thonk.co.uk/) — Eurorack and DIY synth parts.
- [Mouser](https://www.mouser.com/) / [Digi-Key](https://www.digikey.com/) — Comprehensive electronic components.
- [Front Panel Express](https://www.frontpanelexpress.com/) — Custom metal front panels.
- [JLCPCB](https://jlcpcb.com/) — PCB prototyping and fabrication.

---

## E.7 Software Tools

- **KiCAD** — Free PCB CAD software ([kicad.org](https://www.kicad.org/))
- **LTspice** — Free analog circuit simulation ([Analog Devices](https://www.analog.com/en/design-center/design-tools-and-calculators/ltspice-simulator.html))
- **Audacity** — Free audio recording and analysis ([audacityteam.org](https://www.audacityteam.org/))
- **Pure Data & Max/MSP** — Visual programming for audio prototyping ([puredata.info](https://puredata.info/))
- **Arduino IDE** — For microcontroller-based synth add-ons ([arduino.cc](https://www.arduino.cc/))

---

## E.8 Acknowledgments

This resource draws on decades of innovation from the synth DIY and open source hardware/software communities. Special thanks to all contributors to open-source synth projects, technical documentation, and maker forums worldwide.

---

**End of Appendix E**

**This is the last .md file of the first resource (Hybrid Synthesizer Construction Book).**  
Your hybrid synth project now has a complete, reference-grade design and documentation set!