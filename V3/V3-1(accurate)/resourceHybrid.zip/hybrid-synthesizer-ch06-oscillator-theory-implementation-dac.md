# Chapter 6: Oscillator Theory and Implementation (with DACs)

## 6.1 Introduction

Oscillators are the heart of any synthesizer. They generate periodic waveforms—sine, square, saw, triangle, and noise—that serve as the raw material for all synthesized sounds. In a hybrid synth, oscillators are often digital, with their output sent to a DAC and then processed by analog circuitry. This chapter covers the theory, algorithms, and practical C implementations for software oscillators, and how to send their output to a DAC.

---

## 6.2 Oscillator Fundamentals

### What is an Oscillator?

- Produces a repeating waveform at a certain frequency and amplitude.
- In analog: uses capacitors, transistors, op-amps to generate voltage cycles.
- In digital: uses math to generate a sequence of numbers representing the waveform.

**Common waveforms:**
- Sine
- Square
- Sawtooth
- Triangle
- Noise

---

## 6.3 Digital Oscillator Design

**Key parameters:**
- Frequency (`f`)
- Amplitude (`A`)
- Phase (`φ`)
- Sample rate (`f_s`)

**Digital oscillator equation:**
```
y[n] = A * waveform(2πfn / f_s + φ)
```
Where:
- `n` = sample index
- `f_s` = sample rate (e.g., 44100 Hz)

---

## 6.4 Phase Accumulation (Numerically Controlled Oscillator)

A simple and efficient way to generate periodic waveforms in software is the **phase accumulator** approach.

- Maintain a phase variable in [0, 1).
- At each sample, increase phase by `freq / f_s`.
- If phase ≥ 1, wrap around (subtract 1).

**Example:**
```c
typedef struct {
    float frequency;
    float phase;      // [0.0, 1.0)
    float amplitude;
} Oscillator;

void oscillator_update(Oscillator *osc, float sample_rate) {
    osc->phase += osc->frequency / sample_rate;
    if (osc->phase >= 1.0f) osc->phase -= 1.0f;
}
```

---

## 6.5 Sine Wave Oscillator

**Theory:**  
`y = A * sin(2π * phase)`

**C implementation:**
```c name=src/audio/oscillators.c
#include <math.h>
#include "oscillators.h"

float sine_wave(Oscillator *osc, float sample_rate) {
    float out = osc->amplitude * sinf(2.0f * M_PI * osc->phase);
    // Update phase for next sample
    osc->phase += osc->frequency / sample_rate;
    if (osc->phase >= 1.0f) osc->phase -= 1.0f;
    return out;
}
```

---

## 6.6 Square Wave Oscillator

**Theory:**  
`y = A` if phase < 0.5, `y = -A` otherwise

**C implementation:**
```c
float square_wave(Oscillator *osc, float sample_rate) {
    float out = osc->phase < 0.5f ? osc->amplitude : -osc->amplitude;
    osc->phase += osc->frequency / sample_rate;
    if (osc->phase >= 1.0f) osc->phase -= 1.0f;
    return out;
}
```

---

## 6.7 Sawtooth and Triangle Oscillators

**Sawtooth:**  
`y = 2A * phase - A` (ramps up from -A to +A)

**C implementation:**
```c
float saw_wave(Oscillator *osc, float sample_rate) {
    float out = 2.0f * osc->amplitude * osc->phase - osc->amplitude;
    osc->phase += osc->frequency / sample_rate;
    if (osc->phase >= 1.0f) osc->phase -= 1.0f;
    return out;
}
```

**Triangle:**  
`y = 4A * |phase - 0.5| - A` (ramps up and down)

```c
float triangle_wave(Oscillator *osc, float sample_rate) {
    float out = 4.0f * osc->amplitude * fabsf(osc->phase - 0.5f) - osc->amplitude;
    osc->phase += osc->frequency / sample_rate;
    if (osc->phase >= 1.0f) osc->phase -= 1.0f;
    return out;
}
```

---

## 6.8 Noise Oscillator

**White noise:**  
Random value between -A and +A at each sample.

**C implementation:**
```c
#include <stdlib.h>

float noise_wave(Oscillator *osc) {
    float r = ((float)rand() / (float)RAND_MAX) * 2.0f - 1.0f; // [-1, 1]
    return osc->amplitude * r;
}
```

---

## 6.9 Selecting Waveforms

Use an enum and function pointer for flexible wave selection:

```c name=include/oscillators.h
typedef enum {
    OSC_SINE,
    OSC_SQUARE,
    OSC_SAW,
    OSC_TRIANGLE,
    OSC_NOISE
} OscType;

typedef struct Oscillator Oscillator;

typedef float (*OscillatorRenderFn)(Oscillator *, float);

struct Oscillator {
    float frequency;
    float phase;
    float amplitude;
    OscType type;
    OscillatorRenderFn render;
};
```

**Initialization:**
```c
void oscillator_set_type(Oscillator *osc, OscType type) {
    osc->type = type;
    switch(type) {
        case OSC_SINE:    osc->render = sine_wave; break;
        case OSC_SQUARE:  osc->render = square_wave; break;
        case OSC_SAW:     osc->render = saw_wave; break;
        case OSC_TRIANGLE:osc->render = triangle_wave; break;
        case OSC_NOISE:   osc->render = noise_wave; break;
    }
}
```

---

## 6.10 Anti-Aliasing and Bandlimiting (Intro)

- **Aliasing**: When high partials reflect into the audible range, causing digital "harshness."
- **Basic fix**: Limit frequency so partials don't exceed Nyquist.
- **Advanced fix**: Use bandlimited algorithms (e.g., BLEP, PolyBLEP, minBLEP, oversampling).
- **For now**: Use sine for clean sound; accept some aliasing in other waveforms.

---

## 6.11 Multivoice Oscillator Array

For polyphony, use an array of oscillators:

```c
#define NUM_VOICES 8
Oscillator voices[NUM_VOICES];

for (int v = 0; v < NUM_VOICES; ++v) {
    float sample = voices[v].render(&voices[v], sample_rate);
    // Mix sample to output buffer
}
```

---

## 6.12 Sending Audio to a DAC

### On PC: Use PortAudio

- PortAudio allows cross-platform real-time audio output.
- You'll implement a callback that fills the audio buffer with oscillator samples.

**Example (simplified):**
```c
#include <portaudio.h>

static int pa_callback(const void *input, void *output, unsigned long frameCount,
                      const PaStreamCallbackTimeInfo* timeInfo,
                      PaStreamCallbackFlags statusFlags, void *userData) {
    float *out = (float*)output;
    Oscillator *osc = (Oscillator*)userData;
    for (unsigned long i = 0; i < frameCount; i++) {
        *out++ = osc->render(osc, 44100.0f);
    }
    return paContinue;
}
```

---

### On Raspberry Pi: Using a Hardware DAC

- Connect DAC (e.g., MCP4922, PCM5102A) to Pi via SPI or I2S.
- Output the oscillator samples by writing digital values to the DAC at the audio sample rate.
- SPI/I2S transfer code will be hardware-specific (covered in later chapters).

---

## 6.13 DAC Sample Scaling

- DACs expect unsigned integers (e.g., 0–4095 for 12-bit).
- Scale output from [-1.0, +1.0] to this range.

**Example for 12-bit DAC:**
```c
uint16_t float_to_dac(float sample) {
    // Clamp to [-1,1]
    if (sample > 1.0f) sample = 1.0f;
    if (sample < -1.0f) sample = -1.0f;
    // Scale to [0,4095]
    return (uint16_t)((sample + 1.0f) * 2047.5f);
}
```

---

## 6.14 Practical Exercise: Polyphonic Oscillator Demo

1. Implement all waveforms as described.
2. Write a test program using PortAudio to play a chord (C-E-G) with 3 oscillators, each a different waveform.
3. Experiment with changing frequency, amplitude, and wave type in real time (keyboard input).

---

## 6.15 Summary

You now know the theory and practice of digital oscillator design and how to output their sound on both PC and hardware via DAC. Next, we’ll turn to analog electronics—filters, VCAs, and signal routing—to shape these raw waveforms.

---

## 6.16 Further Reading

- [PortAudio API Reference](http://www.portaudio.com/docs/v19-doxydocs/)
- [PolyBLEP Oscillator Theory](https://www.kvraudio.com/forum/viewtopic.php?t=375517)
- [DSP Synth Oscillator Cookbook](https://www.musicdsp.org/en/latest/Oscillators/)

---

**End of Chapter 6**

*Next: Chapter 7 — Analog Electronics for Synthesizers (Filters, VCAs, Signal Routing)*