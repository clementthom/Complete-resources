# Appendix B: Example Code Structure & File Map

---

## B.1 Introduction

For maintainability, portability, and collaboration, it’s essential to organize your synth firmware and supporting code in a clear, modular structure. This appendix provides a recommended directory tree and describes the contents and purpose of each main file and folder for your hybrid synthesizer project.

---

## B.2 Recommended Directory Tree

```
hybrid-synth/
├── README.md
├── LICENSE
├── Makefile / CMakeLists.txt
├── docs/
│   ├── schematics/
│   ├── pcb_layouts/
│   └── manual/
├── src/
│   ├── main.c
│   ├── synth/
│   │   ├── engine.c
│   │   ├── voice.c
│   │   ├── oscillator.c
│   │   ├── envelope.c
│   │   ├── filter.c
│   │   ├── vca.c
│   │   ├── lfo.c
│   │   ├── modmatrix.c
│   │   ├── patch.c
│   │   └── effects.c
│   ├── hw/
│   │   ├── dac_spi.c
│   │   ├── dac_i2s.c
│   │   ├── adc.c
│   │   ├── gpio.c
│   │   ├── midi_uart.c
│   │   └── display.c
│   ├── ui/
│   │   ├── menu.c
│   │   ├── encoder.c
│   │   ├── buttons.c
│   │   └── oled.c
│   ├── midi/
│   │   ├── midi.c
│   │   ├── parser.c
│   │   └── sysex.c
│   ├── platform/
│   │   ├── linux/
│   │   │   └── alsa_out.c
│   │   └── baremetal/
│   │       └── timer.c
│   └── utils/
│       ├── ringbuf.c
│       ├── logger.c
│       └── config.c
├── include/
│   ├── synth/
│   ├── hw/
│   ├── ui/
│   ├── midi/
│   ├── platform/
│   └── utils/
├── patches/
│   └── factory/
│   └── user/
├── tests/
│   ├── synth/
│   ├── hw/
│   └── integration/
├── scripts/
│   ├── update_firmware.sh
│   └── diagnostics.py
├── tools/
│   └── editor/
├── resources/
│   ├── fonts/
│   └── icons/
└── build/
```

---

## B.3 File/Directory Descriptions

- **README.md**: Overview, build/run instructions, dependencies, credits.
- **LICENSE**: Open-source license (MIT, GPL, etc).
- **Makefile/CMakeLists.txt**: Build scripts for compiling the firmware.
- **docs/**: Schematics, PCB layouts, user manual, and technical docs.
- **src/**: All source code (C or C++), organized by subsystem.
  - **synth/**: Core synthesizer engine modules.
  - **hw/**: Hardware abstraction (DAC, ADC, GPIO, display, MIDI hardware).
  - **ui/**: User interface code (menu system, encoders, buttons, display).
  - **midi/**: MIDI parsing, routing, SysEx.
  - **platform/**: Platform-specific code (Linux/ALSA, bare-metal).
  - **utils/**: Reusable helpers (ring buffers, logging, configuration).
- **include/**: Headers for each major module, matching `src/`.
- **patches/**: Preset and user patch files (JSON, binary, or SysEx).
- **tests/**: Unit and integration tests for core modules and hardware.
- **scripts/**: Helper scripts (firmware flashing, diagnostics, patch conversion).
- **tools/**: External/GUI tools (patch editor, librarian).
- **resources/**: Fonts, icons, graphics for display or UI.
- **build/**: Output directory for firmware binaries, logs, or artifacts.

---

## B.4 Example: Minimal ALSA Output Module

```c name=src/platform/linux/alsa_out.c
#include <alsa/asoundlib.h>
#include "platform/alsa_out.h"

static snd_pcm_t *pcm;

int alsa_out_init(int sample_rate, int channels) {
    int err = snd_pcm_open(&pcm, "default", SND_PCM_STREAM_PLAYBACK, 0);
    if (err < 0) return err;
    err = snd_pcm_set_params(pcm,
        SND_PCM_FORMAT_FLOAT_LE, SND_PCM_ACCESS_RW_INTERLEAVED,
        channels, sample_rate, 1, 50000);
    return err;
}

int alsa_out_write(float *buffer, int frames) {
    return snd_pcm_writei(pcm, buffer, frames);
}

void alsa_out_close() {
    snd_pcm_close(pcm);
}
```

---

## B.5 Example: Patch and Mod Matrix Data Structures

```c name=include/synth/patch.h
typedef struct {
    float osc1_freq;
    float osc2_freq;
    // ... more params ...
    ModMatrix mod_matrix;
    char name[32];
} Patch;
```

```c name=include/synth/modmatrix.h
#define MAX_MOD_SOURCES 16
#define MAX_MOD_DEST 16
#define MAX_MOD_ENTRIES 32

typedef struct {
    int src_idx;
    int dst_idx;
    float amount;
} ModEntry;

typedef struct {
    float sources[MAX_MOD_SOURCES];
    float destinations[MAX_MOD_DEST];
    ModEntry entries[MAX_MOD_ENTRIES];
    int num_entries;
} ModMatrix;
```

---

## B.6 Test and Utilities

- **tests/**: Contains C files for unit testing (can use Unity, CMocka, or custom framework).
- **scripts/diagnostics.py**: Python script to poll MIDI, test DAC, and log errors.

---

## B.7 How to Extend

- Add new modules (e.g., effects, UI panels) in their own subdirs.
- Keep hardware abstraction strict: No synth code should directly access GPIO, SPI, etc.—always go through `hw/` or `platform/`.
- Document new modules and APIs in `docs/manual/` or header comments.

---

**End of Appendix B**

*Next: Appendix C — Schematics and Reference Circuits*