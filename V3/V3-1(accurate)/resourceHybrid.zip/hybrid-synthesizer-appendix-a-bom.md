# Appendix A: Bill of Materials (BOM) — Hybrid Synthesizer

---

## A.1 Introduction

This appendix lists the parts, chips, modules, and resources needed for building the hybrid synthesizer as described in the previous chapters. Quantities are for a standard 8-voice, stereo-output configuration. Adjust as needed for your build.

---

## A.2 Core Digital Platform

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| Raspberry Pi 4 Model B     | 2GB/4GB/8GB                        | 1   | Main processor, audio engine  |
| microSD Card               | ≥16GB, Class 10/UHS-I              | 1   | OS, patches, logs             |
| Power Supply               | 5V 3A USB-C                        | 1   | Official Pi PSU recommended   |
| Heatsinks/Fan              | For Pi CPU cooling                  | 1   | Optional, for heavy DSP loads |

---

## A.3 DAC & Audio Output

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| MCP4922 (or PCM5102A)      | Dual 12-bit SPI DAC (or I2S DAC)   | 1-4 | Parallel for multichannel     |
| 10uF Tantalum Cap          | PSU decoupling for DACs            | 2   | Per DAC                       |
| 0.1uF Ceramic Cap          | Decoupling (close to VDD)          | 2   | Per DAC                       |
| TL072 / NE5532 Op-Amps     | Output buffer/mixer                | 2-4 | Stereo, quad output           |
| 100Ω–470Ω Resistor         | Output protection                  | 2-8 | Per output channel            |
| 10uF Non-polar Cap         | Output DC-block                    | 2-4 | Per output channel            |
| TRS 1/4" Jack              | Line/headphone output              | 2-4 | Panel-mount                   |

---

## A.4 Analog Signal Path (VCF, VCA, Analog Effects)

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| LM13700/OTA                | Dual OTA for VCF/VCA               | 4-8 | Per voice or shared           |
| TL072 / NE5532 Op-Amps     | Filter, mixer, buffer              | 4-12| As needed per circuit         |
| 100kΩ Precision Resistor   | Audio path, feedback               | ~20 | 1% tolerance                  |
| 220nF–1uF Film Cap         | Filter caps                        | ~10 | Polypropylene preferred       |
| BBD (MN3207, PT2399)       | For chorus/flanger/delay           | 1-2 | Optional, for analog FX       |
| Spring Reverb Tank         | Accutronics/Belton                 | 1   | Optional                      |

---

## A.5 Power Supplies

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| AC-DC Module (12V, 1A)     | Linear or switching                | 1   | For analog rails              |
| 7812, 7912 Regulator       | +12V, -12V linear regulator        | 1ea | For analog supply             |
| 5V Regulator (if needed)   | 7805 or switching                  | 1   | For logic/analog isolation    |
| Bypass/Filter Capacitors   | 100nF, 47uF, 2200uF                | 10+ | For all rails                 |
| Fuses                      | 0.5–1A slow-blow                   | 1-2 | Per rail                      |

---

## A.6 User Interface & Control

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| Rotary Encoder             | detented, with push switch         | 2-6 | Parameter/menu control        |
| 10kΩ Linear Potentiometer  | For sliders, synth controls        | 4-12| For filters, envelopes, etc.  |
| Tactile Push Buttons       | Panel-mount, for triggers, menus   | 4-10|                              |
| OLED/LCD Display           | I2C/SPI, 128x64 or 20x4 char       | 1   | Status, patch names, etc.     |
| MCP3008 / ADS1115 ADC      | For reading pots                   | 1-2 | SPI/I2C, 8/16 channels        |
| LED (3mm/5mm/RGB)          | Status, metering, indication       | 6-12|                              |
| 220Ω Resistor              | LED current limiting               | 6-12|                              |

---

## A.7 MIDI, Connectivity, and Expansion

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| 5-Pin DIN Socket           | MIDI In/Out                        | 1-2 | Panel mount                   |
| 6N138 Opto-Isolator        | MIDI In protection                  | 1   | MIDI standard                 |
| USB Host Cable             | For USB MIDI controllers           | 1   | Pi 4 USB-A                    |
| GPIO Header                | 2x20 male/female                   | 1   | For Pi GPIO expansion         |
| PCB Standoffs, Screws      | Hardware assembly                   | —   |                              |

---

## A.8 Enclosure & Panel

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| Aluminum/Steel Chassis     | Custom or pre-made                 | 1   | 19" rack or desktop           |
| Front Panel (Acrylic/Alu)  | Laser-cut or CNC                   | 1   | Cutouts for controls, jacks   |
| Knobs                      | For pots/encoders                  | 6-20|                              |
| Rubber Feet                | For stability                       | 4   |                              |
| Ventilation Grills         | For cooling                         | 1-2 |                              |

---

## A.9 Miscellaneous

| Part/Module                | Description                        | Qty | Notes                         |
|----------------------------|------------------------------------|-----|-------------------------------|
| Hook-up Wire               | 24AWG stranded/solid                | —   | Various colors                |
| Ribbon Cable               | For panel-PCB interconnect           | —   | 10–20 pin                    |
| Heat Shrink Tubing         | For insulation                       | —   | Various sizes                 |
| Sockets, Headers           | For ICs, modular boards              | —   | DIP, SIL, DIL                 |
| Solder, Flux, Tools        | Iron, sucker, wick                   | —   | As needed                     |

---

## A.10 Recommended Vendors

- Mouser, Digi-Key, Farnell, Tayda, Thonk (Eurorack), Adafruit, SparkFun, Jameco, AliExpress (for some passives).
- Panel/enclosure: Schaeffer/Front Panel Express, local machine shops, laser cutting services.

---

## A.11 Example BOM Spreadsheet

| Ref. | Part/Module        | Vendor Part # | Qty | Notes              |
|------|--------------------|---------------|-----|--------------------|
| U1   | MCP4922-E/SL       | 579-MCP4922   | 2   | SPI DAC, SOIC      |
| U2   | TL072CP            | 595-TL072CP   | 4   | Op-amp DIP         |
| J1   | 1/4" TRS Jack      | 502-110-0350-1| 2   | Line Out           |
| ...  | ...                | ...           | ... | ...                |

*(See project repository for downloadable spreadsheet.)*

---

**End of Appendix A**

*Next: Appendix B — Example Code Structure & File Map*