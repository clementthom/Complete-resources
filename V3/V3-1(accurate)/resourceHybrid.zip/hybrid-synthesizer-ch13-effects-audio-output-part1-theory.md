# Chapter 13: Effects, Audio Output, and Final Signal Path — Part 1: Theory and Classic Circuits

---

## 13.1 Introduction

Once your hybrid synthesizer’s voices have passed through oscillators, filters, VCAs, and modulation, the final stage is often a set of effects and output drivers. This section explores the theory and practice of audio effects—both analog and digital—as well as output buffering, mixing, and interfacing your synth with amplifiers, mixers, and recording gear. We’ll pay special attention to classic effects (reverb, delay, chorus), their implementation, and the art of designing a clean, robust output stage.

---

## 13.2 Why Effects Matter in Synth Design

- **Sound Shaping**: Effects add depth, space, movement, and polish to raw synth sounds.
- **Performance**: Well-integrated effects allow for expressive, inspiring real-time control.
- **Integration**: A professional output stage ensures compatibility with studio and live setups.
- **Classic Character**: Effects like chorus, delay, and reverb are iconic elements of synth history.

---

## 13.3 Overview of Common Effects

### 13.3.1 Reverb

- Simulates acoustic spaces (rooms, halls, plates, springs).
- Adds depth, “air”, and blends dry sounds into a mix.
- Types:  
    - **Spring reverb** (classic analog, e.g., in guitar amps and synths like Roland Space Echo).
    - **Plate reverb** (mechanical, e.g., EMT 140).
    - **Digital reverb** (algorithms: Schroeder, Freeverb, “Lexicon” style).

### 13.3.2 Delay / Echo

- Repeats the signal after a short time, creating echoes.
- Analog: Bucket Brigade Devices (BBD, e.g., MN3007), tape delay.
- Digital: Circular buffer algorithms, can be stereo/ping-pong/multitap.

### 13.3.3 Chorus / Flanger / Phaser

- **Chorus**: Slightly detuned, delayed copies of the signal, simulating multiple voices.
- **Flanger**: Very short, modulated delay with feedback, produces “jet plane” swoosh.
- **Phaser**: All-pass filter stages with LFO modulation, creating moving notches in frequency response.

### 13.3.4 Distortion / Overdrive

- Adds harmonic content, edge, and “analog” character.
- Can be subtle (tape/valve-like saturation) or aggressive (fuzz, bitcrush, clipping).

### 13.3.5 Equalization (EQ)

- Shaping tonal balance; cuts/boosts specific frequency ranges.

### 13.3.6 Compression and Limiting

- Controls dynamic range, prevents output clipping, “glues” the sound.

---

## 13.4 Analog vs. Digital Effects

- **Analog**: Distinctive character, simple circuitry, often mono, classic for chorus/delay/overdrive.
- **Digital**: More complex, flexible, stereo or multichannel, can implement any effect algorithm, often integrated on the Pi.

---

## 13.5 Classic Analog Effects Circuits

### 13.5.1 Spring Reverb Tank

- Physical spring, input transducer vibrates spring, output coil picks up reverb.
- Used in many classic 70s/80s synths and guitar amps.
- Requires driver and recovery amps (op-amp or discrete).

### 13.5.2 Bucket Brigade Delay (BBD)

- Uses series of capacitors and analog switches to delay signal in discrete steps.
- Chips: MN3007, MN3207, PT2399 (the latter is pseudo-digital).
- Requires clock generator, pre-emphasis/de-emphasis filtering.

### 13.5.3 Analog Chorus/Flanger

- Built around BBD chips, LFO modulates delay time.
- Feedback path for flanger; multiple delay lines for chorus.

### 13.5.4 Overdrive/Distortion

- Soft clipping: Diodes or FETs in op-amp feedback.
- Tube emulation: Triode circuits or JFETs.
- Hard clipping: Op-amp or transistor saturation.

---

## 13.6 Digital Effects on the Pi

### 13.6.1 Advantages

- Can run multiple, stereo, or complex effects.
- Easy to store/recall settings per patch.
- Flexible modulation (LFO, envelope, MIDI).

### 13.6.2 Disadvantages

- Requires low-latency, high-performance code.
- Digital artifacts if not properly designed (aliasing, zipper noise).
- Output needs to be properly buffered/filtered before analog output.

---

## 13.7 Signal Flow: Effects Routing

### 13.7.1 Serial vs. Parallel Effects

- **Serial**: Output of one effect feeds into the next (e.g., chorus → delay → reverb).
- **Parallel**: Dry signal split, sent through multiple effects in parallel, then mixed.
- **Blend controls**: Allow mixing dry and wet (effected) signals.

### 13.7.2 Insert vs. Send/Return

- **Insert**: Effect is “in-line” with the main signal path.
- **Send/Return**: Portion of the signal is sent to effect, returned and mixed with original.

### 13.7.3 Effects Placement

- Pre-filter: Envelope follower, distortion, some modulation effects.
- Post-filter: Delay, reverb, chorus, EQ, compression.

---

## 13.8 Output Buffering and Mixing

### 13.8.1 Why Buffer the Output?

- Protects against loading from cables, mixers, or amplifiers.
- Lowers output impedance, prevents tone loss.
- Allows for proper level shifting (e.g., synth-level to line-level).

### 13.8.2 Typical Output Buffer Circuits

- **Op-amp voltage follower**: Classic, simple, robust.
- **Discrete transistor emitter follower**: Vintage character.
- **Transformer output**: For balanced outputs, galvanic isolation.

### 13.8.3 Headphone and Line Drivers

- Specialized op-amps or amplifier chips (TL072, NE5532, TDA2822).
- Must handle low-impedance loads (32–600Ω for headphones).
- May include mute relay to avoid power-up “pops”.

---

## 13.9 Output Level and Impedance Standards

- **Eurorack**: ±5V or ±10V signals, typically 1kΩ output impedance.
- **Line level (pro)**: +4dBu (1.23Vrms), balanced, 600Ω or lower out, 10kΩ or higher in.
- **Line level (consumer)**: -10dBV (0.316Vrms), unbalanced.
- **Headphones**: 32–600Ω, need 50–200mW per channel for loud output.

---

## 13.10 Grounding, Shielding, and Hum

- Use star-grounding for analog and digital sections.
- Shield all output cables and connectors.
- Avoid ground loops by using balanced outputs or isolators if needed.
- Keep analog and digital grounds separate until a single point.

---

## 13.11 Output Protection and Safety

- Series resistors (100–470Ω) on output to prevent shorts.
- Output capacitor for DC blocking (10–100μF, non-polar for line/headphones).
- TVS diode or Zener clamp on output jack for ESD protection.
- Mute circuit on power-up and shutdown to avoid speaker/headphone damage.

---

## 13.12 Metering and Monitoring

- VU meters (LED bar, analog needle, or OLED) indicate output level.
- Clip indicator shows when output is saturating.
- Implement in analog (op-amp peak detector) or digital (code).

---

## 13.13 Case Study: Classic Poly Synth Output Stages

- **Roland Juno-106**: BBD chorus, analog mix, NE5532 headphone/line buffer.
- **Sequential Prophet-5**: Stereo outputs, discrete line drivers, analog mix bus.
- **E-mu Emulator III**: Digital effects (Reverb, Chorus), SSM VCAs, high-headroom output amps.

---

## 13.14 Planning Your Synth’s Effects and Output Stage

- Decide which effects are analog, which are digital (run on Pi).
- Plan signal routing for maximum flexibility (serial, parallel, insert/send).
- Choose output buffer and driver circuits for intended use (studio, stage, headphones).
- Design for robust, low-noise, and safe operation.

---

## 13.15 Looking Ahead

The next part will detail **practical analog and digital effects circuits**, C code for delay/chorus/reverb on the Pi, and step-by-step output stage construction, with breadboarding and testing procedures.

---

**End of Chapter 13, Part 1**

*Next: Chapter 13, Part 2 — Practical Effects Circuits, Digital Effects in C, and Output Stage Design*