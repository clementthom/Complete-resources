# Chapter 7: Analog Electronics for Synthesizers (Filters, VCAs, Signal Routing) — Part 2

---

## 7.13 Voltage-Controlled Filters (VCF): Deep Dive

### 7.13.1 What Makes a Filter "Voltage-Controlled"?

- In a VCF, the cutoff frequency is set not by a fixed resistor or potentiometer, but by a *control voltage* (CV).
- This allows envelopes, LFOs, keyboard tracking, or sequencers to modulate the filter dynamically.
- Key to expressive, "alive" synth sounds.

### 7.13.2 Methods of Voltage Control

- **OTA (Operational Transconductance Amplifier)**: The most common for classic synths (e.g., LM13700, CA3080).
    - The control current (from CV) sets the filter's cutoff.
- **Vactrols**: LED + photoresistor; slow but "organic" response (used in some older designs).
- **FETs as voltage-controlled resistors**: Less common due to nonlinearity and temperature sensitivity.

---

## 7.14 Classic VCF Circuits

### 7.14.1 OTA-Based 4-Pole Low-Pass (Moog Ladder, Roland, SSM/CEM)

- 4-pole = 24dB/octave slope.
- Multiple cascaded filter stages for sharper rolloff and better resonance control.
- Each stage uses an OTA to set the frequency.

**Generalized schematic block:**
```
Input → [OTA1] → [OTA2] → [OTA3] → [OTA4] → Output (LP)
                                      |
                                   (feedback for resonance)
```

### 7.14.2 State Variable Filter (SVF) with Voltage Control

- Can output: Low-pass, Band-pass, High-pass, Notch.
- Cutoff set by CV, often using OTAs or FETs for variable resistors.

---

## 7.15 Building a Simple VCF (LM13700 Example)

### 7.15.1 Bill of Materials

- 1x LM13700 OTA
- 2x TL072/074 op-amps
- Resistors (various, 10k–100k)
- Capacitors (various, 1nF–100nF)
- Potentiometer (for manual control, optional)
- Power (+12V, -12V, GND)
- Breadboard, jumpers

### 7.15.2 Basic Schematic Walkthrough

- Audio input AC-coupled (via capacitor) to OTA input.
- Integrator circuits with op-amps and capacitors set the filter response.
- CV input summed into the OTA bias current input (Iabc pin).
- Resonance is a feedback loop from output to input, often through a resistor network.

### 7.15.3 Tuning and Scaling

- 1V/octave CV scaling for keyboard tracking: Exponential converter circuit (using matched transistors) can be added for accurate musical tracking.
- Offset trimmer for zeroing cutoff at minimum CV.

---

## 7.16 Simulating and Testing Your VCF

### 7.16.1 SPICE Simulation Goals

- Observe frequency response as you sweep the CV.
- Examine resonance behavior—does it self-oscillate?
- Input a square wave and observe how harmonics are filtered as cutoff is modulated.

### 7.16.2 Breadboard Prototyping

- Use a function generator (or a DAC output from your digital section) to supply test signals.
- Sweep cutoff with a potentiometer or LFO voltage.
- Listen for smoothness, resonance, and any distortion or instability.
- Measure real cutoff frequency vs. CV using an oscilloscope and frequency counter.

---

## 7.17 Voltage-Controlled Amplifiers (VCA)

### 7.17.1 What is a VCA?

- A VCA controls the amplitude of an audio signal with a control voltage.
- Used for envelopes, velocity, volume automation, tremolo, etc.

### 7.17.2 OTA-Based VCA

- Most common in synths; LM13700, CA3080, SSM2164.
- CV (Iabc) sets the output level.
- Can be linear or exponential response.

**Simple OTA VCA block:**
```
Audio In → [OTA] → Buffer → Audio Out
              ↑
             CV
```

### 7.17.3 Other VCA Methods

- Analog multipliers (e.g., THAT2180, SSM2164)
- JFET-based (less linear, more "vintage" distortion)

---

## 7.18 VCA Circuit Example (LM13700)

### 7.18.1 Bill of Materials

- 1x LM13700
- 1x TL072/TL074 op-amp
- A few resistors/capacitors
- Breadboard, power, jumpers

### 7.18.2 Circuit Walkthrough

- Audio in to OTA input
- CV to Iabc pin (scaled to set gain)
- Buffer op-amp on output for low output impedance
- Capacitor to ground for basic noise filtering

### 7.18.3 Testing

- Send a constant audio signal; sweep CV from zero to max.
- Listen for linearity; watch for bleed (audio present at zero CV).
- Use an envelope generator (hardware or digital) to control amplitude dynamically.

---

## 7.19 Signal Routing and Mixing

### 7.19.1 Mixing Audio and CV

- Op-amp summing circuits for mixing voices, waveforms, mod sources.
- Use resistors for setting mix ratios.

### 7.19.2 Buffered Routing

- Buffer stages (op-amps in voltage follower mode) prevent signal loss and allow for multiple destinations.
- Essential for modular patching or polyphonic architectures.

### 7.19.3 Switches and Multiplexers

- Analog switches (e.g., 4051, 4066, 74HC4053) for automated routing under microcontroller or manual control.
- Used for voice allocation, effects sends, or patch memory switching.

---

## 7.20 Interfacing Analog and Digital: From DAC to VCF

### 7.20.1 Level Shifting and Buffering

- DAC outputs may be unipolar (0–3.3V or 0–5V). Most analog synth circuits expect bipolar ±5V or ±10V.
- Use op-amp level shifter circuits to convert DAC output to appropriate analog range.

**Example:**
- Summing amplifier to add a negative offset, then an inverting buffer to restore phase and match impedance.

### 7.20.2 Anti-Aliasing and Output Filtering

- Always use a low-pass filter after the DAC to remove digital "steps" (reconstruction filter).
- For 44.1kHz sample rate, cutoff slightly below Nyquist (e.g., 18kHz).

---

## 7.21 PCB Design: From Breadboard to KiCAD

### 7.21.1 Why PCB?

- Stable, reliable, repeatable.
- Minimize noise and interference.
- Easier integration into enclosures and with other boards.

### 7.21.2 PCB Design Tips for Synth Circuits

- Keep analog and digital ground planes separate if possible.
- Route audio traces away from power/switching lines.
- Use decoupling capacitors on all IC power pins.
- Shield sensitive analog nodes from digital noise.

### 7.21.3 KiCAD Workflow

1. Schematic design: Draw circuit, assign footprints.
2. PCB layout: Arrange components, route traces, set ground planes.
3. DRC check: Fix errors/warnings.
4. Generate Gerber files for manufacturing.

---

## 7.22 Analog Troubleshooting and Debugging

### 7.22.1 Common Issues

- Hum or noise: Check grounding, shielding, power supply quality.
- Distortion: Check signal levels, headroom, op-amp specs.
- Oscillation/instability: Bypass capacitors, layout tweaks, check for feedback paths.

### 7.22.2 Tools

- Oscilloscope: Essential for viewing waveforms, measuring frequency and amplitude.
- Audio probe: Simple capacitor with lead to amplify and listen to different circuit points.
- Multimeter: For DC bias and checking for shorts/opens.

---

## 7.23 Exercise: Build and Simulate a Full Analog Voice Path

1. Breadboard or simulate (in KiCAD/SPICE) a path:
   - DAC output → Level shifter → VCF input
   - VCF output → VCA input (CV from envelope)
   - VCA output → Output buffer → Speaker/headphones
2. Sweep the filter cutoff with a CV. Observe and listen to the effect.
3. Modulate the VCA with a slow envelope or LFO; listen for smooth amplitude changes.
4. Try mixing two oscillator signals before the filter. Listen for intermodulation and filter effects.

---

## 7.24 Further Reading and Classic Circuits

- [Open Music Labs: Filter and VCA Circuits](http://www.openmusiclabs.com/)
- [Yusynth: DIY Synthesizer Projects](http://yusynth.net/Modular/index_en.html)
- [Mutable Instruments Analog Schematics](https://mutable-instruments.net/archive/schematics.html)
- [MFOS (Music From Outer Space) Analog DIY](http://musicfromouterspace.com/)

---

**End of Chapter 7, Part 2**

*Next: Chapter 8 — Envelopes, LFOs, and Modulation Sources (Theory and Implementation)*