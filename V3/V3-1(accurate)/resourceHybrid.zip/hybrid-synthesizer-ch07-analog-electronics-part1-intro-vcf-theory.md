# Chapter 7: Analog Electronics for Synthesizers (Filters, VCAs, Signal Routing) — Part 1

---

## 7.1 Introduction

Analog electronics are the soul of classic synthesizers. Even in a hybrid system, analog components—filters, amplifiers, and signal routing—impart distinct sonic character, warmth, and nonlinearity. This chapter (split into several parts for depth and clarity) will build your understanding from first principles to practical, breadboarded, and simulated circuits, focusing on the essential blocks: filters (VCF), voltage-controlled amplifiers (VCA), and audio signal routing.

---

## 7.2 Safety and Lab Setup

### 7.2.1 Safety First

- Always power down circuits before modifying them.
- Double-check connections—miswiring can destroy ICs.
- Use a bench power supply with current limiting.
- Avoid handling powered boards on metal surfaces.
- Discharge large capacitors before touching.

### 7.2.2 Minimum Lab Equipment

- Breadboard and jumper wires
- Multimeter (for continuity, voltage, resistance)
- Oscilloscope (for viewing waveforms; optional, but highly recommended)
- Soldering iron and supplies (for final assembly)
- Bench power supply (+12V, -12V, +5V rails typical for synth circuits)
- Small speakers or audio interface for monitoring output

---

## 7.3 Analog Signal Levels and Impedance

- **Line level**: Most synth circuits operate at ±5V or ±10V peak-to-peak.
- **Modular (Eurorack)**: ±5V signals, 1V/octave pitch control.
- **Impedance matching**: Output impedance should be much lower than input impedance for minimal signal loss.
- **Grounding**: Always tie circuit ground to power supply ground.

---

## 7.4 Theory: Filters in Synthesis

### 7.4.1 Why Filters Matter

Filters are crucial for sound shaping. They attenuate or boost selected frequency ranges, create movement (sweeps), and, with resonance, can even self-oscillate. The filter’s character defines much of a synth’s voice.

- Low-pass: Removes high harmonics, smooths sound.
- High-pass: Removes low frequencies, thins sound.
- Band-pass: Isolates a specific range, great for vocal/formant effects.
- Notch: Removes a narrow band (phase cancellation, "hollow" sound).

### 7.4.2 Filter Parameters

- **Cutoff frequency (fc):** The point where the filter begins to attenuate the signal.
- **Resonance (Q):** Boost at the cutoff frequency, can cause ringing or self-oscillation.
- **Slope:** How rapidly frequencies are attenuated (measured in dB/octave, e.g., 12dB/octave = 2-pole).

---

## 7.5 The RC Low-Pass Filter: The Simplest Filter

### 7.5.1 Circuit

```text
Vin ----[ R ]----+---- Vout
                 |
                ---
                --- C
                 |
                GND
```

- **R** = resistor
- **C** = capacitor

### 7.5.2 Formula

- **Cutoff frequency:**  
  `fc = 1 / (2πRC)`

### 7.5.3 Example Calculation

If R = 10kΩ, C = 1nF:  
`fc = 1 / (2 * π * 10,000 * 0.000000001)` ≈ 15.9 kHz

### 7.5.4 Limitations

- Only 6dB/octave slope (gentle roll-off)
- Fixed cutoff (not voltage-controlled)
- Not enough for most synth applications, but important building block

---

## 7.6 Op-Amp Active Filters

### 7.6.1 Why Use Op-Amps?

- Provide buffering (high input, low output impedance)
- Enable higher-order filters (steeper slopes)
- Allow for voltage control and resonance

### 7.6.2 Sallen-Key Low-Pass Filter

#### Circuit

```text
Vin ---[R1]---+---[R2]---+---- Vout
              |          |
             ---        ---
             C1         C2
              |          |
             GND        GND
```

- Uses an op-amp as a buffer or gain stage.

#### Formula

- **Cutoff frequency:**  
  `fc = 1 / (2π√(R1*R2*C1*C2))`

- **Q (resonance):**  
  Set by resistor ratios and op-amp feedback.

#### Advantages

- 12dB/octave roll-off (2-pole)
- Can be cascaded for steeper slopes

---

## 7.7 State Variable Filter (SVF): The Classic Synth Circuit

### 7.7.1 Overview

The State Variable Filter is a versatile design found in many classic synths (Oberheim SEM, E-mu filters). It can simultaneously output low-pass, band-pass, and high-pass signals.

### 7.7.2 Block Diagram

```
                +------+
    Input ------|  SUM |-----+
                +------+     |
                              |
                +-------------+
                |
            Integrator 1 (LP)
                |
            Integrator 2 (BP)
                |
               Output
```

### 7.7.3 Key Features

- Voltage-controlled cutoff and resonance
- Multiple outputs (LP, BP, HP)
- Smooth, musical resonance

---

## 7.8 ICs for Synth Filters

### 7.8.1 Classic Chips

- **SSM2044, SSM2045, CEM3320:** Legendary, used in E-mu, Sequential, Oberheim, etc.
- **OTA (Operational Transconductance Amplifiers):** CA3080, LM13700: Used for voltage-controlled operation.

### 7.8.2 Modern Substitutes

- SSM2164/V2164 (quad VCA, popular for modern analog synths)
- TL074, TL072 (quad/dual op-amps, good for audio)

---

## 7.9 Practical: Breadboarding a Simple Low-Pass Filter

### 7.9.1 What You Need

- 1x TL072 or TL074 op-amp IC
- 2x 10kΩ resistors
- 2x 10nF capacitors
- Breadboard, jumpers, power supply

### 7.9.2 Breadboard Steps

1. Place the op-amp chip on the breadboard; connect power rails (+12V, -12V, GND).
2. Connect resistors and capacitors per Sallen-Key schematic.
3. Apply a signal (e.g., from a function generator or synth oscillator output).
4. Monitor output using oscilloscope or headphones (via buffer/amplifier).

### 7.9.3 What to Observe

- Sweep the input frequency.
- Listen and observe the roll-off above the cutoff.
- Adjust component values to change cutoff frequency.

---

## 7.10 Simulation: SPICE in KiCAD

### 7.10.1 Why Simulate?

- Predict circuit behavior before soldering.
- Visualize frequency response, resonance, and stability.
- Try parameter sweeps easily.

### 7.10.2 Setting Up

1. In KiCAD, create the filter schematic.
2. Set up a SPICE simulation profile for AC sweep (frequency response).
3. Run the simulation; plot output amplitude vs. frequency.

### 7.10.3 What to Look For

- -3dB point = cutoff frequency
- Slope after cutoff = filter order
- Resonance peak (with feedback)

---

## 7.11 Exercise: Design and Simulate a 2-Pole Low-Pass Filter

1. Calculate R and C for a cutoff of 1kHz.
2. Build the circuit in KiCAD.
3. Simulate using SPICE; plot the frequency response.
4. Swap the capacitor or resistor values and observe the cutoff change.
5. Add resonance (feedback) and observe its effect.

---

## 7.12 Looking Ahead

Part 2 of this chapter will dive into **voltage-controlled filters** (VCF), resonance circuits, voltage-controlled amplifiers (VCA), and tips for noise reduction, signal routing, and interfacing with your digital (DAC) output.

---

**End of Chapter 7, Part 1**

*Next: Chapter 7, Part 2 — Voltage-Controlled Filters, VCA, and Advanced Analog Synth Circuits*