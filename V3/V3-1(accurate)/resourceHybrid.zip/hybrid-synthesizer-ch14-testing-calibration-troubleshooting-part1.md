# Chapter 14: Testing, Calibration, and Troubleshooting — Part 1: Tools, Principles, and Test Procedures

---

## 14.1 Introduction

After building your hybrid synthesizer, thorough testing and calibration are essential to guarantee reliable, musical, and robust performance. This chapter covers the tools, methods, and best practices for verifying each subsystem, tuning analog and digital circuits, and diagnosing common problems—from voice misalignment to noise, distortion, or digital glitches. Whether you're a DIY enthusiast or building a production instrument, a systematic testing approach ensures quality and longevity.

---

## 14.2 Essential Test Equipment

### 14.2.1 Multimeter

- For measuring voltages, currents, and resistances.
- Use for power supply checks, continuity, and bias measurements.

### 14.2.2 Oscilloscope

- Visualizes audio, control, and clock waveforms.
- Essential for checking oscillator output, filter shapes, envelopes, and DAC performance.
- Digital scopes offer storage, FFT, and triggering.

### 14.2.3 Signal Generator

- Sine, square, triangle, ramp outputs.
- Used to inject test signals into VCF, VCA, or effects for response analysis.

### 14.2.4 Frequency Counter / Tuner

- Measures oscillator and output frequencies for tuning.
- Guitar tuners or smartphone apps can suffice for basic work.

### 14.2.5 Audio Interface and DAW

- For recording, analyzing, and monitoring output.
- Useful for spectral analysis, noise floor measurement, and long-term stability testing.

### 14.2.6 Logic Analyzer

- For debugging SPI, I2S, MIDI, and GPIO timing at the digital level.

---

## 14.3 Initial Power-up Checks

1. **No ICs installed:** Power up the board with just passives to check for shorts, correct voltage rails.
2. **With ICs:** Install chips, check for excessive current draw or overheating.
3. **Check all power rails:** Confirm ±12V, +5V, +3.3V as needed.
4. **Test ground connections:** All sections should measure ~0Ω to ground.

---

## 14.4 Digital Section: Boot and Communication

- Verify Pi boots and runs synth code (check serial or HDMI console).
- Check SPI/I2S communication to DACs using logic analyzer.
- Use test patterns (square wave, ramp) to confirm DAC outputs correct voltage range.

---

## 14.5 Analog Section: Oscillator and Filter Tuning

### 14.5.1 VCO (if present)

- Check for stable waveform (square, saw, triangle) at expected frequencies.
- Adjust trimmers for correct tuning and scaling (e.g., 1V/oct).
- Use frequency counter or tuner to verify tracking across several octaves.

### 14.5.2 VCF

- Inject sine or white noise; sweep cutoff manually and via modulation.
- Observe filter response on oscilloscope and/or with spectrum analyzer.
- Adjust resonance trimmers; verify self-oscillation (if designed for it).
- Confirm modulation depth and envelope response.

---

## 14.6 Envelope, LFO, and Modulation Testing

- Trigger envelopes with manual or MIDI note-on; observe shape, times, and sustain behavior.
- Verify LFO waveforms (sine, triangle, square) and rate controls.
- Test modulation matrix: assign different sources to destinations, check scaling and polarity.

---

## 14.7 Polyphony and Voice Allocation Test

- Play chords and rapid note sequences via MIDI or onboard controls.
- Confirm all voices trigger, release, and recycle correctly.
- Listen for stuck notes, voice stealing, or missed triggers.
- Log voice allocation events for debugging.

---

## 14.8 Effects and Output Testing

- Inject known signals to effects chain; verify delay, chorus, reverb timing and depth.
- Test dry/wet mix and output level.
- Use oscilloscope to check final output waveform for clipping, distortion, or excessive noise.
- Test headphones and line out for correct levels and absence of hum.

---

## 14.9 Calibration Procedures

### 14.9.1 DAC Calibration

- Check that -1.0 to +1.0 digital range maps precisely to target analog voltage (e.g., ±5V).
- Adjust output scaling or offset in code or via hardware trimpots.

### 14.9.2 Analog Tuning (VCO/VCF)

- Set reference voltage (e.g., 1V) and verify pitch/frequency scaling.
- Use trimpots or software calibration tables as needed.

### 14.9.3 Envelope and LFO Timing

- Check actual attack, decay, release times vs. settings.
- Calibrate timing constants for accurate envelopes/LFOs.

---

## 14.10 Noise, Hum, and Interference

- With all voices off, measure output noise floor (should be < -80dB for high-quality build).
- Listen and look for hum (50/60Hz), buzz, or digital noise.
- Move cables, touch grounds, or power up/down sections to isolate source.
- Add shielding, improve grounding, or add filtering as needed.

---

## 14.11 Digital Artifacts: Glitches, Pops, and Aliasing

- Look for steps or discontinuities in output (scope, audio).
- Confirm sample rate and buffer sizes are correct.
- Apply smoothing or interpolation to parameter changes if needed.
- Listen for zipper noise on fast parameter sweeps (use slew limiters).

---

## 14.12 Common Problems and Solutions

| Problem                 | Symptom                       | Troubleshooting Steps               |
|-------------------------|-------------------------------|-------------------------------------|
| No sound                | Silent output                 | Check power, signal path, DAC       |
| Excessive noise         | Hiss, buzz, hum               | Check grounding, shielding, PSUs    |
| Stuck notes             | Voices hang after key off     | Debug MIDI parsing, voice logic     |
| Glitches/pops           | Random ticks/clicks           | Buffer underrun, check timing       |
| Wrong pitch             | Notes out of tune             | Calibrate VCO, check scaling        |
| Effects not working     | No wet signal                 | Check code, analog routing, levels  |

---

## 14.13 Documenting Your Calibration and Test Results

- Keep a log of all calibration adjustments (trimmer settings, code constants).
- Record before/after measurements for future reference.
- Update your BOM or build docs with any changes needed for stable operation.

---

## 14.14 Safety When Testing

- Never work on powered circuits while making hardware changes.
- Discharge all capacitors before probing analog sections.
- Use proper ESD precautions on all digital and analog boards.
- Wear hearing protection when testing at high output levels.

---

## 14.15 Looking Ahead

The next part will cover **advanced troubleshooting, voice tuning, maintenance, and long-term reliability**, including case studies from real-world projects.

---

**End of Chapter 14, Part 1**

*Next: Chapter 14, Part 2 — Advanced Troubleshooting, Voice Tuning, and Maintenance*