# Appendix D: Glossary of Terms

---

## D.1 Introduction

This glossary defines technical terms, abbreviations, and jargon used throughout the hybrid synthesizer construction guide. Refer to this section for quick clarification of synth, audio, electronics, and computing vocabulary.

---

### A

- **ADC (Analog-to-Digital Converter):** A device or circuit that converts analog voltages into digital values for processing by a microcontroller or computer.
- **ALSA (Advanced Linux Sound Architecture):** The main audio and MIDI API for Linux systems, used in Raspberry Pi audio programming.
- **Amplitude:** The magnitude of a waveform; in audio, usually measured in volts or decibels.

### B

- **BBD (Bucket Brigade Device):** An analog delay line made of a chain of capacitors, used in chorus, flanger, and delay effects.

### C

- **CV (Control Voltage):** An analog voltage used to control parameters in synthesizers (e.g., pitch, filter cutoff).
- **Comb Filter:** An effect or filter with delayed feedback, producing notches or peaks in the frequency response.
- **Chorus:** An effect that thickens sounds by combining slightly delayed and modulated copies of the signal.

### D

- **DAC (Digital-to-Analog Converter):** A chip or circuit that converts digital values from a processor into analog voltages.
- **Decay:** The second stage of an envelope; the time it takes for a sound to fall from the attack peak to the sustain level.
- **DIN:** A standard round connector; in synths, usually refers to the 5-pin MIDI connector.

### E

- **Envelope:** A function (usually ADSR) that shapes how a parameter (like amplitude) changes over time.
- **ESD (Electrostatic Discharge):** A sudden flow of electricity between objects; can damage sensitive electronics.

### F

- **Filter:** A circuit that attenuates or boosts specific frequencies.
- **Firmware:** Low-level software that controls hardware directly.

### G

- **Ground Loop:** An unwanted current in the ground path, causing hum or noise.
- **GPIO (General Purpose Input/Output):** Digital pins on a microcontroller or computer for interfacing with external hardware.

### H

- **Headroom:** The range between the normal operating level and the maximum level before clipping.
- **Harmonic:** A frequency that is a whole-number multiple of a fundamental frequency.

### I

- **I2S:** A digital audio interface standard for transmitting PCM audio data.
- **Insert (Audio):** An effects routing method where the signal is sent entirely through an effect before returning to the main path.

### J

- **Jack (Audio):** A connector type, e.g., 1/4" TRS for line/headphone output.

### K

- **Key Tracking:** Modulation of a parameter (e.g., filter cutoff) based on keyboard note position.

### L

- **LFO (Low-Frequency Oscillator):** Generates slow periodic signals for modulation.
- **Line Level:** Standard audio signal level for mixers, interfaces, and effects.

### M

- **MIDI (Musical Instrument Digital Interface):** A protocol for digital communication between music devices.
- **Mod Matrix (Modulation Matrix):** A routing system allowing flexible assignment of sources to destinations.

### N

- **Noise Floor:** The level of background noise in a system, usually measured in dB.

### O

- **Op-Amp (Operational Amplifier):** A fundamental analog IC used in filters, VCAs, mixers, and buffers.
- **Oscillator:** Circuit generating periodic waveforms (sine, square, saw, etc.).

### P

- **Patch:** A set of synthesizer settings saved as a preset.
- **Polyphony:** The number of simultaneous notes or voices a synth can play.

### Q

- **Q (Quality Factor):** Describes the sharpness of a filter’s resonance.

### R

- **Raspberry Pi:** A family of small, affordable computers widely used in DIY projects.
- **Resonance:** The emphasis of frequencies near a filter’s cutoff point.

### S

- **Sample Rate:** The number of digital samples per second in audio; e.g., 44.1kHz.
- **Slew Limiter:** Circuit or algorithm that smooths abrupt changes in a signal.

### T

- **TRS (Tip-Ring-Sleeve):** A type of 1/4" or 1/8" audio connector, can carry stereo or balanced signals.
- **Tuning:** Adjusting oscillators or filters to precise frequencies.

### U

- **UART (Universal Asynchronous Receiver-Transmitter):** Serial communication protocol, used for classic MIDI.

### V

- **VCA (Voltage-Controlled Amplifier):** An amplifier whose gain is set by a control voltage.
- **VCF (Voltage-Controlled Filter):** A filter whose cutoff/resonance is set by a control voltage.
- **Voice Stealing:** Reallocating voices in a polyphonic synth when all voices are in use.

### W

- **Waveform:** The shape of an audio or control signal.
- **Wet/Dry:** The ratio of effected (wet) to original (dry) signal.

---

## D.2 Acronyms and Abbreviations

| Abbreviation | Meaning                              |
|--------------|--------------------------------------|
| ADSR         | Attack, Decay, Sustain, Release      |
| BBD          | Bucket Brigade Device                |
| CV           | Control Voltage                      |
| DAC          | Digital-to-Analog Converter          |
| LFO          | Low-Frequency Oscillator             |
| MIDI         | Musical Instrument Digital Interface |
| SPI          | Serial Peripheral Interface          |
| VCA          | Voltage-Controlled Amplifier         |
| VCF          | Voltage-Controlled Filter            |
| VCO          | Voltage-Controlled Oscillator        |

---

**End of Appendix D**

*Next: Appendix E — Further Reading and Resources*