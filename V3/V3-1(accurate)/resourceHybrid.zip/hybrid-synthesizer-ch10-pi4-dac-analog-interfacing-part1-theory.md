# Chapter 10: Interfacing the Raspberry Pi 4 with DACs and Analog Synth Circuits — Part 1: Theory, Hardware, and Signal Flow

---

## 10.1 Introduction

Building a hybrid synthesizer means bridging the digital world (Raspberry Pi 4, C code, digital oscillators) with the analog realm (filters, VCAs, analog mixing). This chapter, the first of a multi-part section, covers the theory, hardware, and practical concerns of interfacing the Pi 4 with DACs (Digital-to-Analog Converters), and then with analog circuits. We’ll cover digital audio data, electrical standards, DAC choices, and the basics of getting clean, reliable audio out of your Pi and into analog filters.

---

## 10.2 Why the Raspberry Pi 4?

- **Powerful ARM CPU**: Easily handles real-time digital audio with 8+ voices.
- **I/O variety**: SPI, I2C, I2S, GPIO, USB — perfect for interfacing with DACs and synth hardware.
- **Linux or bare-metal**: Can run full Linux or a minimal real-time OS for lowest latency.
- **Community and support**: Huge open-source ecosystem, many audio libraries, and existing projects.

---

## 10.3 Digital Audio Output Options

### 10.3.1 Built-in Audio Jack

- Pi has a built-in 3.5mm analog jack, but:
    - Low quality (PWM-based, noisy, not suitable for pro synth work)
    - Not “true” DAC — avoid for serious audio output.

### 10.3.2 HDMI Audio

- Digital audio over HDMI; requires external AV receiver or monitor.
- Not suitable for direct synth hardware interfacing.

### 10.3.3 USB Audio Interfaces

- Commercial USB audio DACs work out of the box with Linux.
- High quality, but limited for DIY analog interfacing, less control for low-level hacking.

### 10.3.4 External DACs (SPI/I2S)

- **SPI DACs** (e.g., MCP4922, MCP4822): Easy to interface, up to 2 channels (stereo), 12–16 bits, up to 1 MHz update rate.
- **I2S DACs** (e.g., PCM5102A, WM8731): Dedicated audio interface, typically higher fidelity, multi-channel.
- **Parallel DACs**: Rare, lots of pins, not practical on Pi 4.

---

## 10.4 Choosing a DAC for Synthesizer Use

### 10.4.1 Key Parameters

- **Resolution**: 12, 16, or 24 bits (more = less quantization noise).
- **Channels**: Mono, stereo, or more (for multi-voice or multi-out).
- **Maximum update/sampling rate**: Needs to be at least twice your audio bandwidth (usually ≥44.1kHz).
- **Interface**: SPI (simple, flexible), I2S (audio standard, lower jitter).
- **Voltage output range**: Unipolar (0–Vref) or bipolar (±Vref) — affects analog circuit design.
- **Settling time and output current**: Important for driving analog loads.

### 10.4.2 Popular DAC Choices

- **MCP4922**: Dual 12-bit SPI DAC, easy to breadboard, widely available.
- **PCM5102A**: 24-bit I2S audio DAC, very high quality, used in many DIY “HiFi” hats.
- **WM8731**: Stereo I2S audio codec, ADC+DAC, more complex (requires configuration).
- **AD5669**: Quad 16-bit SPI DAC, for polyphonic/multi-voice designs (advanced).

---

## 10.5 Understanding SPI and I2S Protocols

### 10.5.1 SPI (Serial Peripheral Interface)

- Simple 4-wire protocol: MOSI (data), MISO (not used for output-only DACs), SCLK (clock), CS (chip select).
- Master (Pi) pushes data to the DAC at up to several MHz.
- Good for control-rate or audio-rate signals.
- Easy to bit-bang in C, or use Pi’s hardware SPI controller.

### 10.5.2 I2S (Inter-IC Sound)

- Designed for digital audio streaming (standard on digital synths and pro audio).
- Transmits left/right channels at fixed sample rate and bit depth.
- Requires dedicated Pi pins (not the same as SPI).
- Lower jitter, less CPU overhead for continuous audio.

---

## 10.6 Preparing the Raspberry Pi for Hardware Audio Output

### 10.6.1 Pinout and Power

- **GPIO pins**: Used for SPI/I2S and controlling DACs.
- **3.3V vs 5V**: Many DACs run on 3.3V logic (matches Pi), but output voltage may need scaling for analog synth circuits.
- **Grounding**: Always tie Pi’s ground to analog ground (star grounding best practice).

### 10.6.2 Avoiding Electrical Damage

- Never connect Pi pins directly to voltages >3.3V.
- Use logic-level shifters if needed.
- Use series resistors (100–470Ω) for extra protection on signal lines.

### 10.6.3 Power Supply Considerations

- Use a clean, well-regulated 5V supply for the Pi and DAC.
- Analog circuits (VCF/VCA) often need ±12V rails — keep analog and digital power separate as much as possible.

---

## 10.7 Signal Flow: From Pi to Analog Filter

1. **C code on Pi** generates digital audio samples (floats, ints).
2. **Sample values** are quantized and formatted for the DAC (e.g., 12 bits unsigned for MCP4922).
3. **Pi communicates** with DAC over SPI or I2S to send sample data at audio rate.
4. **DAC outputs** corresponding voltage (0–Vref or ±Vref).
5. **Level-shifting/buffering circuit** adapts DAC output to analog synth voltage standards (±5V, ±10V).
6. **Analog filter and VCA** process the signal further.
7. **Output buffer** prepares signal for line out, speakers, etc.

---

## 10.8 Data Formats: From Float to DAC Integer

### 10.8.1 Float-to-Integer Conversion

- Synth code typically uses `float` or `double` for audio calculations (range: -1.0 to +1.0).
- DAC expects unsigned int: e.g., 0–4095 for 12-bit DAC.

**Conversion:**
```c
uint16_t sample_to_dac(float s) {
    // Clamp to [-1,1]
    if (s > 1.0f) s = 1.0f;
    if (s < -1.0f) s = -1.0f;
    // Scale to [0,4095]
    return (uint16_t)((s + 1.0f) * 2047.5f);
}
```

### 10.8.2 Endianness and Byte Order

- SPI/I2S DACs expect data in a specific byte order (check datasheet).
- C code must pack bytes appropriately before sending.

---

## 10.9 Planning for Multi-Voice DAC Output

### 10.9.1 Mono, Stereo, and Multichannel

- **Mono**: All voices mixed in software, summed to one output.
- **Stereo**: Pan voices, sum L/R outputs, send to two DAC channels.
- **Multichannel**: One DAC channel per voice (advanced, requires parallel DACs or multi-channel chips).

### 10.9.2 Voice-to-DAC Routing Table

- For polyphonic hybrid synths, maintain a mapping from software voice to hardware DAC channel.
- Update routing dynamically for voice allocation and “voice stealing.”

---

## 10.10 Summary

- The Raspberry Pi 4, with SPI or I2S DACs, is a powerful digital front-end for a hybrid synth.
- Careful selection of DAC, attention to voltage standards, and proper digital/analog interfacing are crucial to high-quality, reliable output.
- You now understand the theory and hardware landscape; the next part will cover **C code for SPI/I2S interfacing, real-time audio streaming, and analog output testing**.

---

## 10.11 Further Reading

- [Raspberry Pi Official GPIO Pinout](https://www.raspberrypi.com/documentation/computers/raspberry-pi.html#gpio-and-the-40-pin-header)
- [MCP4922 Datasheet](https://ww1.microchip.com/downloads/en/DeviceDoc/20002249B.pdf)
- [PCM5102A Datasheet](https://www.ti.com/lit/ds/symlink/pcm5102a.pdf)
- [I2S Audio on Raspberry Pi](https://learn.adafruit.com/adafruit-i2s-stereo-decoder)
- [Open Music Labs: DIY DACs](http://www.openmusiclabs.com/)

---

**End of Chapter 10, Part 1**

*Next: Chapter 10, Part 2 — C Code for DAC Communication and Real-Time Audio Output*