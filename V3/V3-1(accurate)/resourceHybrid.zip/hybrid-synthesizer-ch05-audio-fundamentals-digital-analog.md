# Chapter 5: Audio Fundamentals: Digital and Analog Sound

## 5.1 Introduction

Sound is at the heart of synthesis. To build a hybrid synthesizer, you must thoroughly understand both digital and analog audio: how sound is generated, represented, processed, and perceived. This chapter explores the physics of sound, digital audio concepts, and the essential analog signal paths used in classic and modern synth design.

---

## 5.2 What is Sound?

- **Sound** is a vibration that propagates as a mechanical wave of pressure and displacement through a medium (usually air).
- **Frequency** (Hz): Cycles per second. Determines pitch.
- **Amplitude**: Height of the wave. Determines loudness.
- **Waveform**: The shape of the vibration (sine, square, saw, etc.), which determines timbre.

---

## 5.3 Analog Audio Basics

**Analog audio** is a continuous electrical signal that represents sound.

### Key Components:
- **Oscillators**: Generate periodic waveforms (VCOs).
- **Filters**: Shape frequency content (VCF).
- **Amplifiers**: Control amplitude (VCA).
- **Mixers**: Combine signals.
- **Envelope generators & LFOs**: Modulate parameters.

### Voltage and Audio

- **Line level**: Typical synth output is ±5V or ±10V peak-to-peak.
- **Eurorack**: ±5V is common.
- **Audio rate**: 20 Hz to 20 kHz.

---

## 5.4 Digital Audio Fundamentals

Digital audio is a **discrete** representation of sound, sampled at regular intervals.

### Key Concepts

- **Sampling rate** (`f_s`): Number of samples per second (e.g., 44,100 Hz).
- **Bit depth**: Number of bits per sample (e.g., 16, 24, 32).
- **Quantization**: Rounding analog values to discrete digital levels.
- **Nyquist theorem**: Max frequency = ½ sampling rate.  
  To capture 20 kHz, `f_s` must be at least 40 kHz.

---

## 5.5 Analog vs Digital: Pros and Cons

|               | Analog                        | Digital                      |
|---------------|------------------------------|------------------------------|
| Pros          | Warmth, nonlinearity, no aliasing | Flexibility, precision, recall, complex algorithms |
| Cons          | Drift, noise, less repeatable | Aliasing, quantization noise, digital harshness    |

Hybrid synths combine the best of both!

---

## 5.6 The Signal Chain: End-to-End

**A hybrid synth’s audio path might look like:**

1. **Digital domain:**  
   - Oscillator (DSP, Pi 4, C code)
   - Envelope, LFO, modulation (DSP)
   - Digital mixing/summing

2. **Digital-to-Analog Conversion (DAC):**
   - Converts digital samples to analog voltage.

3. **Analog domain:**
   - VCF (analog filter)
   - VCA (analog amplifier)
   - Analog effects (overdrive, chorus, etc.)
   - Output buffering and mixing

4. **Output:**
   - Line out, headphones, etc.

---

## 5.7 The Sine Wave: The Building Block

A sine wave is the simplest periodic waveform. All complex sounds can be decomposed into sine waves (Fourier).

**Mathematical form:**
```
y(t) = A * sin(2πft + φ)
```
- `A`: Amplitude
- `f`: Frequency (Hz)
- `φ`: Phase

**In C:**
```c
#include <math.h>
float sample = amplitude * sinf(2.0f * M_PI * frequency * t + phase);
```

---

## 5.8 Other Waveforms: Square, Saw, Triangle, Noise

### Square Wave
- Alternates between +A and -A.
- Rich in odd harmonics.

### Sawtooth Wave
- Ramps upward, then drops.
- Rich in all harmonics.

### Triangle Wave
- Linear rise and fall.
- Mostly odd harmonics, softer than square.

### Noise
- Random values, all frequencies.
- White noise = flat spectrum.

**Generating these in C will be detailed in the next chapter!**

---

## 5.9 Polyphony and Voice Structure

- **Monophonic**: One note at a time.
- **Polyphonic**: Multiple notes/voices simultaneously.
- Each voice typically has its own oscillator, envelope, and filter path.

**Example:**
- 8-voice polyphony = 8 independent signal chains.

---

## 5.10 Digital Audio: Sampling and Reconstruction

### Sampling

- At each sample time, analog signal is measured and stored as a number.
- **Aliasing**: If input > Nyquist, higher frequencies "fold back" as false lower frequencies.
- **Anti-aliasing filter**: Low-pass filter before sampling.

### Reconstruction

- DACs reconstruct the analog signal from digital samples.
- Analog smoothing filter removes "stair-step" artifacts.

---

## 5.11 Quantization and Bit Depth

- **Quantization**: Rounds signal to nearest digital level.
- **Bit depth**: More bits = smaller steps, less noise.
   - 16-bit: 65,536 levels (CD quality)
   - 24-bit: 16.7 million levels (studio)
   - 8-bit: 256 levels (lo-fi, Emulator II sound!)

**Quantization noise**: Heard as low-level hiss, especially at low bit depths.

---

## 5.12 Analog Audio: Filters, VCAs, and Saturation

### Filters

- **Low-pass (LPF)**: Passes low, cuts high frequencies.
- **High-pass (HPF)**: Passes high, cuts low.
- **Band-pass (BPF)**: Passes a band, cuts above/below.
- **Resonance (Q)**: Boosts frequencies near cutoff.

### Amplifiers (VCA)

- Control signal amplitude with control voltage (CV).
- Used for envelopes, dynamics, velocity.

### Nonlinearity and Saturation

- Analog circuits "color" the sound (harmonic distortion).
- Soft clipping, transistor and op-amp saturation are desirable for warmth.

---

## 5.13 Example Signal Chain: Emulator III

- **Digital**: Sample playback (8/16-bit, 44.1kHz)
- **DAC**
- **Analog SSM2045 filter**: Famous for warm, punchy sound
- **Analog VCA**
- **Output**

Your hybrid design will follow a similar architecture.

---

## 5.14 Exercise: Plot and Listen

1. Use software (e.g., Audacity, GNU Octave, Python/Matplotlib) to plot:
   - Sine, square, saw, triangle waveforms at 440 Hz.
   - Listen to each—how do they sound different?

2. Research and listen to filter sweeps (LPF, HPF) on synth demos.

3. If you have a breadboard and op-amps, build a simple RC low-pass filter and listen to white noise through it.

---

## 5.15 Summary

You now understand the fundamental building blocks of audio, both digital and analog. The next chapter will focus on implementing digital oscillators in C, and how to get sound out of your PC (and later the Pi) using DACs.

---

## 5.16 Further Reading

- [Sound on Sound: Synth Secrets](https://www.soundonsound.com/series/synth-secrets)
- [Analog Devices: Introduction to Analog Filters](https://www.analog.com/en/analog-dialogue/articles/introduction-to-filters.html)
- [The Scientist & Engineer's Guide to Digital Signal Processing](https://www.dspguide.com/)

---

**End of Chapter 5**

*Next: Chapter 6 — Oscillator Theory and Implementation (with DACs)*