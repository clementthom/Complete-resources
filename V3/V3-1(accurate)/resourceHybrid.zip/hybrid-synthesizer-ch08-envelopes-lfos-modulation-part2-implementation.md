# Chapter 8: Envelopes, LFOs, and Modulation Sources — Part 2: Digital Implementation in C

---

## 8.17 Introduction

This part covers **practical implementation** of envelopes and LFOs in C, with real code, structure, and integration advice. You'll learn how to create flexible, polyphonic, and efficient modulation sources for your hybrid synth, usable both in your PC test harness and portable to the Raspberry Pi.

---

## 8.18 Envelope Generator: Digital Design

### 8.18.1 Envelope State Machine

A digital ADSR envelope is implemented as a state machine:

| State      | Transition Trigger         | Action                                   |
|------------|---------------------------|------------------------------------------|
| Idle       | Note-on                   | Go to Attack, reset output               |
| Attack     | Output reaches max        | Go to Decay                              |
| Decay      | Output reaches sustain    | Go to Sustain                            |
| Sustain    | Note-off                  | Go to Release                            |
| Release    | Output reaches zero       | Go to Idle                               |

### 8.18.2 Envelope Struct in C

```c name=include/envelope.h
#ifndef ENVELOPE_H
#define ENVELOPE_H

typedef enum {
    ENV_IDLE,
    ENV_ATTACK,
    ENV_DECAY,
    ENV_SUSTAIN,
    ENV_RELEASE
} EnvelopeState;

typedef struct {
    EnvelopeState state;
    float sample_rate;
    float attack_time;   // seconds
    float decay_time;    // seconds
    float sustain_level; // 0.0–1.0
    float release_time;  // seconds
    float value;         // current output (0.0–1.0)
    float attack_inc, decay_dec, release_dec; // step sizes per sample
} Envelope;

void envelope_init(Envelope *env, float sample_rate);
void envelope_set_adsr(Envelope *env, float a, float d, float s, float r);
void envelope_note_on(Envelope *env);
void envelope_note_off(Envelope *env);
float envelope_process(Envelope *env);

#endif
```

---

### 8.18.3 Envelope Implementation

```c name=src/audio/envelope.c
#include "envelope.h"

void envelope_init(Envelope *env, float sample_rate) {
    env->sample_rate = sample_rate;
    env->state = ENV_IDLE;
    env->value = 0.0f;
    env->attack_time = 0.1f;
    env->decay_time = 0.2f;
    env->sustain_level = 0.7f;
    env->release_time = 0.3f;
    envelope_set_adsr(env, env->attack_time, env->decay_time, env->sustain_level, env->release_time);
}

void envelope_set_adsr(Envelope *env, float a, float d, float s, float r) {
    env->attack_time = a;
    env->decay_time = d;
    env->sustain_level = s;
    env->release_time = r;
    env->attack_inc = (a > 0.0001f) ? (1.0f / (a * env->sample_rate)) : 1.0f;
    env->decay_dec = (d > 0.0001f) ? ((1.0f - s) / (d * env->sample_rate)) : (1.0f - s);
    env->release_dec = (r > 0.0001f) ? (s / (r * env->sample_rate)) : s;
}

void envelope_note_on(Envelope *env) {
    env->state = ENV_ATTACK;
}

void envelope_note_off(Envelope *env) {
    env->state = ENV_RELEASE;
}

float envelope_process(Envelope *env) {
    switch (env->state) {
        case ENV_ATTACK:
            env->value += env->attack_inc;
            if (env->value >= 1.0f) {
                env->value = 1.0f;
                env->state = ENV_DECAY;
            }
            break;
        case ENV_DECAY:
            env->value -= env->decay_dec;
            if (env->value <= env->sustain_level) {
                env->value = env->sustain_level;
                env->state = ENV_SUSTAIN;
            }
            break;
        case ENV_SUSTAIN:
            // Hold current value
            break;
        case ENV_RELEASE:
            env->value -= env->release_dec;
            if (env->value <= 0.0f) {
                env->value = 0.0f;
                env->state = ENV_IDLE;
            }
            break;
        case ENV_IDLE:
        default:
            env->value = 0.0f;
            break;
    }
    return env->value;
}
```

---

### 8.18.4 Polyphonic Envelopes

For polyphony, use an array of Envelope structs, one per voice:

```c
#define NUM_VOICES 8
Envelope envelopes[NUM_VOICES];
```
Each voice triggers its envelope on note-on/note-off events.

---

## 8.19 LFO Implementation

### 8.19.1 LFO Struct and Waveforms

```c name=include/lfo.h
#ifndef LFO_H
#define LFO_H

typedef enum {
    LFO_SINE,
    LFO_TRIANGLE,
    LFO_SQUARE,
    LFO_SAW,
    LFO_RANDOM
} LfoType;

typedef struct {
    float frequency;
    float phase;
    float sample_rate;
    float value;
    LfoType type;
} Lfo;

void lfo_init(Lfo *lfo, float sample_rate, LfoType type, float freq);
float lfo_process(Lfo *lfo);

#endif
```

### 8.19.2 LFO Processing

```c name=src/audio/lfo.c
#include <math.h>
#include <stdlib.h>
#include "lfo.h"

void lfo_init(Lfo *lfo, float sample_rate, LfoType type, float freq) {
    lfo->sample_rate = sample_rate;
    lfo->type = type;
    lfo->frequency = freq;
    lfo->phase = 0.0f;
    lfo->value = 0.0f;
}

float lfo_process(Lfo *lfo) {
    float out = 0.0f;
    switch (lfo->type) {
        case LFO_SINE:
            out = sinf(2.0f * M_PI * lfo->phase);
            break;
        case LFO_TRIANGLE:
            out = 4.0f * fabsf(lfo->phase - 0.5f) - 1.0f;
            break;
        case LFO_SQUARE:
            out = (lfo->phase < 0.5f) ? 1.0f : -1.0f;
            break;
        case LFO_SAW:
            out = 2.0f * (lfo->phase) - 1.0f;
            break;
        case LFO_RANDOM:
            if (lfo->phase < 0.01f) // New value at start of cycle
                lfo->value = 2.0f * ((float)rand() / RAND_MAX) - 1.0f;
            out = lfo->value;
            break;
    }
    lfo->phase += lfo->frequency / lfo->sample_rate;
    if (lfo->phase >= 1.0f) lfo->phase -= 1.0f;
    return out;
}
```

---

## 8.20 Modulation Routing in C

### 8.20.1 Hardwired Example

```c
float osc_pitch = base_pitch + lfo_out * lfo_depth + env_out * env_depth;
float vca_amp = osc_amp * env_out;
```

### 8.20.2 Matrix Routing Example

You can use a struct array for a basic modulation matrix:

```c name=include/modmatrix.h
#define MAX_MOD_SOURCES 8
#define MAX_MOD_DESTS   8

typedef struct {
    int source_idx;  // Which mod source (LFO, ENV, etc.)
    int dest_idx;    // Which parameter (pitch, cutoff, etc.)
    float amount;    // Modulation depth
} ModRoute;

typedef struct {
    float sources[MAX_MOD_SOURCES];
    float dests[MAX_MOD_DESTS];
    ModRoute routes[MAX_MOD_SOURCES * MAX_MOD_DESTS];
    int num_routes;
} ModMatrix;

void modmatrix_apply(ModMatrix *matrix);
```

**In your process function:**
```c
void modmatrix_apply(ModMatrix *matrix) {
    // Clear destinations
    for (int d = 0; d < MAX_MOD_DESTS; ++d)
        matrix->dests[d] = 0.0f;
    // Sum all modulations
    for (int i = 0; i < matrix->num_routes; ++i) {
        int s = matrix->routes[i].source_idx;
        int d = matrix->routes[i].dest_idx;
        float amt = matrix->routes[i].amount;
        matrix->dests[d] += matrix->sources[s] * amt;
    }
}
```
Assign sources (LFO, ENV, etc.) each frame, then call `modmatrix_apply()` to sum them into destinations (pitch, cutoff, etc.).

---

## 8.21 Integrating Modulation with Voice Architecture

- Each voice gets its own envelopes and possibly LFOs (for per-voice modulation).
- Global LFOs can modulate all voices at once.
- Modulation values (e.g., env, lfo) are recalculated each audio frame and applied to oscillators, VCFs, VCAs.

---

## 8.22 Real-Time Considerations

- Modulation sources must be updated at audio rate for smoothest results.
- For CPU savings, some LFOs or envelopes can run at a lower "control rate" (e.g., 1kHz instead of 44.1kHz), but this may affect sound quality.
- Beware of denormal numbers (very small floats) on some CPUs—can cause performance issues.
- For bare metal Pi, ensure your code is deterministic and has no dynamic allocation in the audio path.

---

## 8.23 Advanced Features

- **Looping Envelopes:** EG returns to attack or decay on release (for evolving pads).
- **Multi-segment Envelopes:** More than ADSR; e.g., AHDSR, DAHDSR, or custom curves.
- **Syncable LFOs:** Reset phase on MIDI clock or note-on.
- **Random/Noise LFOs:** Stepped, smooth, drifting random modulation.

---

## 8.24 Exercise: Implement and Test

1. Implement the envelope and LFO code above.
2. Write a test harness on your PC (using PortAudio) to:
    - Play a sustained note with amplitude envelope and LFO vibrato.
    - Adjust envelope and LFO parameters in real time (keyboard or MIDI control).
    - Visualize envelopes/LFOs by printing values to console or plotting.
3. Prepare the code for porting to Raspberry Pi (separate UI, audio, and mod modules).

---

## 8.25 Debugging and Visualization

- Print envelope and LFO values to console for debugging.
- Output envelopes/LFOs as audio to hear their shapes (e.g., envelope to oscillator pitch or amplitude).
- Use a DAW or audio editor to record and analyze test outputs.

---

## 8.26 Further Reading

- [Attack Magazine: Synth Envelopes](https://www.attackmagazine.com/technique/synth-secrets/synth-envelope/)
- [Sound on Sound: LFOs & Modulation](https://www.soundonsound.com/techniques/synth-secrets-lfos)
- [Mutable Instruments Envelope Code (Open Source)](https://github.com/pichenettes/eurorack/blob/master/stages/envelope.h)

---

**End of Chapter 8, Part 2**

*Next: Chapter 9 — Polyphony & Voice Allocation*