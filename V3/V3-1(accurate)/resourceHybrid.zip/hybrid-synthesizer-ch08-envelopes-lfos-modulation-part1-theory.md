# Chapter 8: Envelopes, LFOs, and Modulation Sources — Part 1: Theory and Design

---

## 8.1 Introduction

Modulation is what makes synthesizers expressive and "alive." Envelopes shape the amplitude, filter, or pitch over time, while LFOs provide cyclic modulation for vibrato, tremolo, and more. This chapter explores the theory, types, and roles of envelopes, LFOs, and other modulation sources in hybrid synthesizers.

---

## 8.2 What Is Modulation?

- **Modulation** means varying one parameter with another signal.
    - Examples: Modulating oscillator pitch with an LFO for vibrato, modulating filter cutoff with an envelope for filter sweeps.
- In hybrid synths, modulation can be digital, analog, or a mix.

---

## 8.3 The Envelope Generator (EG)

### 8.3.1 What Is an Envelope?

- An **envelope** is a time-varying control signal, typically triggered by a note-on event (key press).
- Used to control amplitude (VCA), filter cutoff (VCF), or other parameters.

### 8.3.2 ADSR: The Most Common Envelope

- **Attack (A):** Time to reach peak after key press.
- **Decay (D):** Time to fall from peak to sustain level.
- **Sustain (S):** Level to hold while key is pressed.
- **Release (R):** Time to return to zero after key is released.

```
Time →
^
|         /\
|        /  \
|       /    \
|      /      \
|_____/        \_______
A   D   S      R
```
- **Other types:** AR, ADR, AHDSR, multi-stage, looping.

---

## 8.4 Envelope Applications

- **Amplitude envelope** (VCA): Shapes loudness contour.
- **Filter envelope** (VCF): Shapes timbre over time.
- **Pitch envelope**: For drum sounds, pitch sweeps, effects.
- **Modulation envelope**: Any destination (e.g., PWM depth, ring mod, etc.)

---

## 8.5 Envelope Generator Implementation (Analog and Digital)

### 8.5.1 Analog EGs

- Classic "RC" (resistor-capacitor) circuits with transistors or op-amps.
- More "organic," but less precise and repeatable.
- Voltage-controlled EGs allow modulation of envelope times by CVs.

### 8.5.2 Digital EGs

- Implemented in software (C code).
- Clocked at audio or control rate.
- Highly repeatable and flexible.
- Easy to implement multi-stage, looping, or complex shapes.

---

## 8.6 Envelope Generator Parameters

- **Attack time (ms):** 1–5000ms typical
- **Decay time (ms):** 1–5000ms
- **Sustain level:** 0–1 (0–100%)
- **Release time (ms):** 1–5000ms

**Extra parameters for advanced EGs:**
- Delay before attack
- Hold after attack
- Multi-stage (more than 4 segments)
- Curvature (linear, exponential, logarithmic)

---

## 8.7 Envelope Curves: Linear vs Exponential

- Human ears perceive loudness logarithmically.
- **Exponential envelopes** (natural RC circuits) sound more "natural."
- **Linear envelopes** (straight-line segments) are easier in digital, but can sound unnatural.

---

## 8.8 LFO: Low-Frequency Oscillator

### 8.8.1 What Is an LFO?

- An oscillator running below audio range (typically <20 Hz).
- Outputs periodic waveforms (sine, square, triangle, random) for modulation.
- Used for vibrato (pitch), tremolo (amplitude), filter sweeps, PWM, panning, etc.

### 8.8.2 LFO Parameters

- **Rate/frequency:** 0.01–20Hz (sometimes up to 100Hz for "audio rate" FM)
- **Waveform:** Sine, triangle, square, saw, random, stepped, sample-and-hold
- **Depth:** Modulation amount
- **Phase offset:** Start phase for syncing with note-on or other LFOs
- **Sync:** LFO can be synced to MIDI clock, sequencer, or other events

---

## 8.9 Modulation Sources in Hybrid Synths

- **Envelope generators**
- **LFOs**
- **Keyboard tracking (key number as voltage or value)**
- **Velocity (how hard you play a key)**
- **Aftertouch (pressure on key)**
- **Sequencer tracks**
- **External CVs (from other synths or controllers)**
- **Random sources (sample & hold, noise)**
- **MIDI CCs (mod wheel, etc.)**

---

## 8.10 Modulation Destinations

- Oscillator pitch, amplitude, or waveform
- Filter cutoff, resonance
- VCA level
- Panning, effects depth
- Any parameter that can be varied

---

## 8.11 Modulation Routing: Matrix and Hardwired

- **Hardwired:** Each source is connected to a fixed destination (e.g., LFO always to pitch).
- **Patchable:** (Matrix, modular, or digitally assignable) Any source can modulate any destination.
- **Matrix modulation:** Inspired by Oberheim Matrix-12, allows complex routing and modulation assignments via software or UI.

---

## 8.12 Modulation Depth, Summing, and Scaling

- Mod sources are often scaled (depth/amount) and summed at their destination.
- Depth can be positive or negative (inverting modulation).
- Multiple sources may modulate a single destination.
- Summing is done in analog (op-amp summing mixer) or digital (C code).

---

## 8.13 Example: Classic Envelope to Filter Sweep

- ADSR envelope output is scaled and added to filter cutoff CV.
- Depth control sets how much envelope affects the cutoff.
- The result is the classic "wah" or "pluck" sound on each note.

---

## 8.14 Example: LFO to Vibrato

- LFO sine or triangle output is summed with oscillator pitch.
- Controls the vibrato rate (LFO frequency) and depth (scaling factor).

---

## 8.15 Exercise: Envelope and LFO Block Diagram

1. Draw a block diagram of a synth voice showing:
    - Oscillator
    - Envelope generator controlling VCA and VCF
    - LFO modulating oscillator pitch and filter cutoff
    - Manual controls for envelope and LFO parameters

2. For each modulation path, label the source, destination, and depth control.

---

## 8.16 Looking Ahead

The next part of this chapter will cover **digital implementation** of envelopes and LFOs in C, including struct design, algorithms, and how to integrate them into your hybrid synth’s signal flow.

---

**End of Chapter 8, Part 1**

*Next: Chapter 8, Part 2 — Digital Implementation of Envelopes and LFOs in C*