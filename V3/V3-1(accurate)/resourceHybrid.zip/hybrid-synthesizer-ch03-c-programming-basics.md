# Chapter 3: C Programming for Embedded Systems (Basics)

## 3.1 Introduction

C is the language of choice for embedded systems, audio DSP, and performance-critical code. If you want to build your own synth, you must understand C deeply. This chapter will cover the **basics of C programming**, with a focus on how and why it is used for embedded systems and audio. We will build solid foundations—no detail omitted—so you can confidently write, debug, and understand the code your hybrid synth will run.

---

## 3.2 Why C for Synths and Embedded Systems?

- **Speed:** C compiles to fast, efficient machine code. Real-time audio needs this.
- **Portability:** C code runs on PCs, Raspberry Pi, and microcontrollers with little change.
- **Control:** You have direct access to memory, hardware, and can optimize for the smallest or fastest code.
- **Community:** Nearly all audio/DSP and embedded libraries are written in C or C++.

---

## 3.3 Setting Up Your C Environment

### On Linux (Solus/Ubuntu/etc):
- **Compiler:** GCC (`sudo eopkg install gcc` or `sudo apt install build-essential`)
- **Editor:** `vim`, `emacs`, `nano`, or `vscode`
- **Build Tool:** `make`

### On Raspberry Pi:
- Same as above. Raspbian OS usually comes with GCC.

### On Windows:
- Use [MSYS2](https://www.msys2.org/), [MinGW](https://www.mingw-w64.org/), or [WSL](https://learn.microsoft.com/en-us/windows/wsl/)

### On macOS:
- Install Xcode Command Line Tools: `xcode-select --install`

---

## 3.4 Your First C Program

Let's write and run a simple program.

```c name=src/hello_world.c
#include <stdio.h>

int main(void) {
    printf("Hello, Hybrid Synth World!\n");
    return 0;
}
```

**To compile and run:**
```bash
gcc src/hello_world.c -o hello
./hello
```

---

## 3.5 Anatomy of a C Program

- **Header files**: `#include <stdio.h>`
- **Main function**: Entry point: `int main(void) { ... }`
- **Statements**: End with `;`
- **Braces `{}`**: Group code blocks
- **Comments**: `// single line` or `/* multiline */`

---

## 3.6 Variables and Types

C is statically typed. You must declare the type of each variable.

| Type      | Description                  | Example           |
|-----------|-----------------------------|-------------------|
| `int`     | Integer                     | `int x = 5;`      |
| `float`   | Floating point (single)     | `float f = 0.5;`  |
| `double`  | Floating point (double)     | `double d = 2.0;` |
| `char`    | Single character            | `char c = 'A';`   |
| `unsigned`| Unsigned integer            | `unsigned int n;` |

**Example:**

```c
int voices = 8;
float cutoff = 1200.0;
char waveform = 's'; // s = sine, t = triangle, etc.
```

---

## 3.7 Operators

- Arithmetic: `+`, `-`, `*`, `/`, `%`
- Assignment: `=`, `+=`, `-=`, etc.
- Comparison: `==`, `!=`, `<`, `>`, `<=`, `>=`
- Logical: `&&`, `||`, `!`

**Example:**
```c
if (voices > 4 && cutoff < 2000.0) {
    // Do something
}
```

---

## 3.8 Control Structures

### If/Else

```c
if (waveform == 's') {
    printf("Sine wave\n");
} else {
    printf("Other waveform\n");
}
```

### Loops

```c
for (int i = 0; i < voices; ++i) {
    printf("Voice: %d\n", i);
}

int i = 0;
while (i < voices) {
    printf("Voice: %d\n", i);
    i++;
}
```

---

## 3.9 Functions

Functions let you organize and reuse code.  
**Syntax:**
```c
return_type function_name(type arg1, type arg2) {
    // code
    return value;
}
```

**Example:**

```c
float frequency_for_key(int midi_note) {
    return 440.0f * powf(2.0f, (midi_note - 69) / 12.0f);
}
```

---

## 3.10 Arrays

Arrays group variables of the same type.

```c
float envelope[8]; // 8 voice envelopes

envelope[0] = 0.5f;
for (int i = 0; i < 8; i++) {
    envelope[i] = 1.0f;
}
```

---

## 3.11 Pointers (Intro)

A pointer is a variable that holds a memory address.  
**Why important?** Used everywhere in embedded/audio C.

```c
int value = 10;
int *ptr = &value; // ptr stores address of value

printf("Value: %d\n", *ptr); // Dereference pointer
```

We'll explore pointers in depth in the next chapter.

---

## 3.12 Structs (Intro)

Structs group related data together.  
**Example:**

```c
typedef struct {
    float frequency;
    float amplitude;
    char waveform;
} Oscillator;

Oscillator osc1;
osc1.frequency = 440.0f;
osc1.amplitude = 1.0f;
osc1.waveform = 's';
```

---

## 3.13 Header Files and Modular Code

- `.c` files: Implementation
- `.h` files: Interface (declarations)

**Example:**

```c name=include/oscillators.h
#ifndef OSCILLATORS_H
#define OSCILLATORS_H

typedef struct {
    float frequency;
    float amplitude;
    char waveform;
} Oscillator;

void oscillator_init(Oscillator* osc, float freq, char wf);
float oscillator_process(Oscillator* osc);

#endif // OSCILLATORS_H
```

```c name=src/audio/oscillators.c
#include "oscillators.h"

void oscillator_init(Oscillator* osc, float freq, char wf) {
    osc->frequency = freq;
    osc->amplitude = 1.0f;
    osc->waveform = wf;
}

float oscillator_process(Oscillator* osc) {
    // Placeholder: return dummy value
    return osc->amplitude * osc->frequency;
}
```

---

## 3.14 Compiling Multi-File Projects

Use `gcc` to compile multiple files:

```bash
gcc src/main.c src/audio/oscillators.c -Iinclude -o synth
```

Or use a Makefile for larger projects (covered in a later chapter).

---

## 3.15 Best Practices for Embedded C

- **Keep functions short and focused**
- **Use meaningful variable names**
- **Comment WHY, not just WHAT**
- **Avoid global variables when possible**
- **Use `const` for read-only data**
- **Be careful with memory (no garbage collection)**

---

## 3.16 Debugging C Programs

- Use `printf` for simple debugging.
- Use `gdb` (GNU Debugger):  
  Compile with `-g` flag, run `gdb ./synth`.
- Check for warnings:  
  Compile with `-Wall -Wextra`.

---

## 3.17 Exercise: Build a Simple Oscillator Struct

1. Create `include/oscillators.h` and `src/audio/oscillators.c` as above.
2. Write a `main.c` that:
   - Creates an `Oscillator` struct.
   - Initializes it to 440 Hz, 's' (sine wave).
   - Calls `oscillator_process` and prints the result.

3. Compile and run your program.

---

## 3.18 Summary

You now know the basics of C—the bedrock for all synth firmware and audio DSP. Next, we'll dive deep into advanced C topics: pointers, structs, memory management, and more, so you can write efficient, robust code for your hybrid synthesizer.

---

## 3.19 Further Reading

- [The C Programming Language](https://archive.org/details/The_C_Programming_Language_2nd_Edition) by Kernighan & Ritchie
- [Modern C](https://modernc.gforge.inria.fr/) by Jens Gustedt
- [Learn-C.org Interactive Tutorial](https://www.learn-c.org/)

---

**End of Chapter 3**

*Next: Chapter 4 — C Programming (Advanced Topics: Pointers, Structs, Memory)*