# Chapter 4: C Programming (Advanced Topics: Pointers, Structs, Memory)

## 4.1 Introduction

This chapter builds on your C fundamentals with a deep dive into **advanced topics** that are essential for embedded, audio, and synthesizer programming. We will cover pointers, dynamic memory, advanced struct usage, modularity, and memory safety. Mastery of these concepts is critical for building efficient, bug-free synth code that runs on both PC and bare metal.

---

## 4.2 Pointers: The Heart of C

Pointers are variables that store memory addresses. They are used for:
- Efficiently passing data to/from functions
- Dynamic memory management (malloc/free)
- Working with hardware (memory-mapped I/O)
- Handling arrays and buffers

### Declaring and Using Pointers

```c
int value = 42;
int *ptr = &value; // ptr holds the address of value

printf("Address: %p, Value: %d\n", (void*)ptr, *ptr); // Dereference
```

- `*` in declaration: "pointer to"
- `&` gets the address of a variable
- `*` in use: dereferences pointer (gets value pointed to)

---

## 4.3 Pointers and Arrays

Arrays and pointers are closely related in C.

```c
float buffer[128];
float *buf_ptr = buffer; // buffer is pointer to first element

for (int i = 0; i < 128; i++) {
    buf_ptr[i] = 0.0f; // Array indexing with pointer
}
```

**Pointer arithmetic:**
- `buf_ptr + 1` points to the next float
- `*(buf_ptr + i)` is equivalent to `buf_ptr[i]`

---

## 4.4 Pointers to Structs

When you pass structs to functions, use pointers for efficiency.

```c
typedef struct {
    float frequency;
    float amplitude;
} Oscillator;

void set_frequency(Oscillator *osc, float freq) {
    osc->frequency = freq;
}

Oscillator osc1;
set_frequency(&osc1, 440.0f);
```

- Use `->` to access struct fields via a pointer: `osc->frequency`
- Use `.` for direct struct: `osc1.frequency`

---

## 4.5 Dynamic Memory Allocation

Dynamic memory is managed at runtime using:
- `malloc` — allocates memory
- `free` — releases memory

**Example:**
```c
int *array = (int *)malloc(100 * sizeof(int));
if (!array) {
    // Handle out of memory
}
// Use array[0..99]
free(array);
```

### When to use dynamic memory?
- Variable-sized data (waveforms, buffers)
- Linked data structures (lists, trees)
- Only when necessary in embedded code (memory is limited!)

---

## 4.6 Memory Leaks and Safety

**Always free what you malloc!**

Common problems:
- **Leaks:** Forgetting `free()`
- **Dangling pointers:** Using memory after `free()`
- **Double free:** Freeing the same pointer twice

**Example of bug:**
```c
int *x = malloc(sizeof(int));
free(x);
*x = 42; // ERROR: x is dangling!
```

**Best practices:**
- Set pointer to NULL after free: `free(x); x = NULL;`
- Initialize all pointers
- Use static analysis tools (Valgrind, AddressSanitizer)

---

## 4.7 Structs: Advanced Usage

Structs organize complex data. You can nest structs, use arrays of structs, and even have pointers to structs.

**Example: Voice Architecture**

```c
#define MAX_VOICES 8

typedef struct {
    float frequency;
    float phase;
    float amplitude;
} Oscillator;

typedef struct {
    Oscillator osc;
    float envelope;
    int active;
} Voice;

Voice voices[MAX_VOICES];
```

---

## 4.8 Modular Code: Splitting Across Files

Large projects split code into modules:
- `.c` (source file): function definitions
- `.h` (header): declarations and struct definitions

**Example Layout:**
```
src/audio/oscillators.c
include/oscillators.h
```

**Header guard:**
```c
#ifndef OSCILLATORS_H
#define OSCILLATORS_H
// ... contents ...
#endif
```

---

## 4.9 Passing Data Between Modules

Use headers to declare functions and structs needed by other modules:

```c name=include/oscillators.h
#ifndef OSCILLATORS_H
#define OSCILLATORS_H

typedef struct {
    float frequency;
    float amplitude;
    float phase;
} Oscillator;

void oscillator_init(Oscillator *osc, float freq, float amp);
float oscillator_render(Oscillator *osc);

#endif
```

```c name=src/audio/oscillators.c
#include "oscillators.h"

void oscillator_init(Oscillator *osc, float freq, float amp) {
    osc->frequency = freq;
    osc->amplitude = amp;
    osc->phase = 0.0f;
}

float oscillator_render(Oscillator *osc) {
    // Simple sine example
    float sample = osc->amplitude * sinf(osc->phase);
    osc->phase += 2.0f * (float)M_PI * osc->frequency / 44100.0f;
    if (osc->phase > 2.0f * (float)M_PI) osc->phase -= 2.0f * (float)M_PI;
    return sample;
}
```

---

## 4.10 Pointers to Functions (Callbacks)

Function pointers allow you to pass functions as arguments—useful for waveform selection, event callbacks, etc.

```c
typedef float (*WaveformFn)(float phase);

float sine_wave(float phase)   { return sinf(phase); }
float square_wave(float phase) { return phase < M_PI ? 1.0f : -1.0f; }

typedef struct {
    float frequency;
    float phase;
    WaveformFn wave_fn;
} Oscillator;
```

Use as:
```c
Oscillator osc;
osc.wave_fn = sine_wave;
float sample = osc.wave_fn(osc.phase);
```

---

## 4.11 Memory Alignment and Embedded Concerns

- Embedded processors may require variables to be aligned (e.g., 4-byte aligned).
- Use `alignas` or `__attribute__((aligned(N)))` if needed.
- Always prefer static/global allocation on bare metal if possible.

---

## 4.12 const and volatile

- `const`: Variable cannot be changed (read-only)
- `volatile`: Value may change outside program control (e.g., hardware register)

```c
const float PI = 3.14159265f; // Never changes
volatile int *gpio_reg = (int *)0x20200000; // Hardware register
```

---

## 4.13 Unions

Unions let different types share the same memory. Rare for audio, but useful for low-level hardware.

```c
typedef union {
    uint32_t all;
    struct {
        uint8_t byte0, byte1, byte2, byte3;
    };
} Register32;
```

---

## 4.14 Example: Voice Management

```c name=src/audio/voice.c
#include "voice.h"

void voice_init(Voice *voice, float freq) {
    oscillator_init(&voice->osc, freq, 1.0f);
    voice->envelope = 1.0f;
    voice->active = 1;
}

float voice_render(Voice *voice) {
    if (!voice->active) return 0.0f;
    // Envelope and oscillator combined
    return oscillator_render(&voice->osc) * voice->envelope;
}
```

---

## 4.15 Practical Exercise: Dynamic Voice Array

1. Write a function to allocate an array of `Voice` structs dynamically.
2. Write an initialization function for each.
3. Write a cleanup function to free the array.

**Example:**
```c
Voice *alloc_voices(int n) {
    Voice *voices = malloc(n * sizeof(Voice));
    if (!voices) { /* handle error */ }
    for (int i = 0; i < n; i++) {
        voice_init(&voices[i], 440.0f + i * 20.0f);
    }
    return voices;
}

void free_voices(Voice *voices) {
    free(voices);
}
```

---

## 4.16 Debugging Advanced Memory Issues

- Use [Valgrind](https://valgrind.org/): `valgrind ./synth`
- Use compiler sanitizers: `gcc -fsanitize=address -g ...`
- Watch for stack overflows (embedded: limited stack size!)

---

## 4.17 Advanced Exercise: Modular Oscillator Types

1. Define an enum for oscillator types.
2. Use a function pointer to select the correct render function.
3. Test with an array of oscillators of different types.

---

## 4.18 Summary

You now have a working knowledge of advanced C—pointers, structs, modularity, and memory. These skills are the backbone of embedded synth code, giving you the flexibility and control needed for real-time audio.

---

## 4.19 Further Reading

- [Deep C Secrets (David R. Tribble)](https://www.drdobbs.com/cpp/the-deep-c-secrets/184401305)
- [Valgrind Memory Debugger](https://valgrind.org/)
- [C Pointers Explained](https://boredzo.org/pointers/)

---

**End of Chapter 4**

*Next: Chapter 5 — Audio Fundamentals: Digital and Analog Sound*