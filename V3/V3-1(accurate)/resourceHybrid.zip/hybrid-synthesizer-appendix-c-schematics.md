# Appendix C: Schematics and Reference Circuits

---

## C.1 Introduction

This appendix provides key schematics and reference circuits for the major analog and digital blocks described in the main text. These are intended as starting points for your own PCB or breadboard work. Always consult component datasheets and double-check pinouts and values before fabrication.

---

## C.2 DAC Output Buffer and Level Shifter

**Purpose:** Buffer the output of an SPI/I2S DAC for line-level or synth-level use.

```
      [DAC OUT]----[100Ω]----+----[Non-polar 10μF]----[OUT JACK]
                             |
                          [Op-Amp Buffer]
                             |
                           [GND]
```

- Op-amp: TL072, NE5532, or similar (non-inverting buffer)
- Output cap blocks DC offset
- 100Ω protects against shorts

---

## C.3 Analog VCF (State Variable)

**Classic state-variable filter using LM13700 or TL074:**

```
          +V
           |
         [R1]
           |
      +----+----[C1]---+--- Output (BP)
      |         |      |
     [Vin]     [R2]   [C2]
      |         |      |
     [GND]     [IC1]  [IC2]
```

- Replace [IC1], [IC2] with OTA or op-amp integrator stages.
- Feedback paths for resonance.
- See main text for resistor/capacitor values.

---

## C.4 VCA Using LM13700

```
 [Audio In]---[10k]---+---[LM13700 Input]
                     |
                   [10k]
                     |
                   [GND]
 [CV In]----[Summing Node]---[OTA Control Input]
```

- Use resistor network to sum multiple CVs.
- Output buffer with op-amp.

---

## C.5 BBD Analog Chorus/Flanger Core

- BBD chip (MN3207 or PT2399)
- Clock driver (4047 or microcontroller PWM)
- Pre-emphasis and de-emphasis filters before/after BBD
- Mix dry and wet outputs with op-amp summing stage

*See PT2399 datasheet and DIY projects for full example.*

---

## C.6 MIDI Input (DIN) with Opto-Isolator

```
 [MIDI DIN Pin 4]---[220Ω]---+---[6N138 Anode]
                             |
 [MIDI DIN Pin 5]---[220Ω]---+---[6N138 Cathode]
 [6N138 Output]---[10k Pullup]---[To UART RX (Pi)]
 [MIDI DIN Pin 2]---[GND]
```

- Protects Pi from external voltages and ground loops.
- Use 6N138 or H11L1 opto as per MIDI spec.

---

## C.7 Analog Spring Reverb Driver/Recovery

**Driver:**
- Op-amp (e.g. TL071) power amp or small transformer
- Match impedance to spring tank input

**Recovery:**
- High-input impedance op-amp, bandpass filter to remove rumble/hiss

---

## C.8 Power Supply and Rail Splitter

- ±12V rails for analog (VCF, VCA)
- 5V/3.3V for Pi and logic
- Use 7812/7912, or switching modules for efficiency
- Include large caps (1000μF+) and local decoupling (100nF) at each IC

---

## C.9 Output Protection and Mute Circuit

- Output relay or MOSFET to disconnect jack during power-up/down
- TVS diode or Zener clamp for ESD
- LED indicator for mute status

---

## C.10 Example Breadboard Layouts

- Use modular breadboard sections for each block (DAC, VCF, VCA, UI, etc.)
- Keep analog and digital grounds separated until single star ground point
- Short wires, decoupling caps near every IC

---

## C.11 PCB Design Considerations

- Wide power/ground traces for low noise
- Star grounding and analog/digital split
- Shielded traces for sensitive analog paths
- Test points for all major signals

---

## C.12 Reference Resources

- [Eagle/KiCAD project files: See project GitHub repo]
- [Mutable Instruments Schematics](https://mutable-instruments.net/archive/schematics.html)
- [Electrosmash: Classic Effect Circuits](https://www.electrosmash.com/)
- [Open Music Labs: Analog Synth Circuits](http://www.openmusiclabs.com/)

---

**End of Appendix C**

*Next: Appendix D — Glossary of Terms*