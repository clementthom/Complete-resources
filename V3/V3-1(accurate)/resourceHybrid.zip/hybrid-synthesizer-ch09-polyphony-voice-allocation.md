# Chapter 9: Polyphony & Voice Allocation

---

## 9.1 Introduction

Polyphony—playing multiple notes at once—is a defining feature of advanced synthesizers and a core part of your hybrid instrument’s architecture. This chapter explores the theory, strategies, and C implementations for polyphonic voice management, including voice allocation, stealing, and separation of digital and analog paths, as found in legendary synths like the Emulator III, Matrix-12, and Synclavier.

---

## 9.2 What Is a Synthesizer “Voice”?

- A **voice** is a complete signal path: oscillator(s), envelope(s), filter(s), VCA, and routing for a single note.
- Polyphony = multiple voices active simultaneously.
    - 8-voice polyphony = 8 independent voices.
    - 16-voice mono = 16 notes, one at a time.
- Each voice can have its own modulation, parameters, and routing.

---

## 9.3 Types of Polyphony

- **Monophonic:** Only one note/voice at a time (e.g., Minimoog).
- **Polyphonic:** Multiple notes at once (e.g., Oberheim OB-X, E-mu Emulator III).
- **Paraphonic:** Multiple oscillators, but shared filter/amplifier (e.g., Korg Poly-800).

---

## 9.4 Voice Architecture in Classic and Modern Synths

### 9.4.1 Per-Voice Structure

Each voice typically contains:
- One or more oscillators
- Envelope generators (amp, filter)
- Filter (VCF)
- VCA
- Modulation sources (LFO, aftertouch, velocity)

### 9.4.2 Shared vs. Dedicated Circuits

- **Dedicated:** Each voice has its own analog circuits (costly, flexible).
- **Shared:** Digital voices mixed and sent through fewer analog paths (cost-saving, less flexible).

Your hybrid synth will use digital oscillators and envelopes per voice, routed to analog filter/VCA boards.

---

## 9.5 Voice Allocation: Why It Matters

- When you play a note, the synth must decide which voice to assign.
- If all voices are busy, the synth may "steal" an existing voice (voice stealing).
- Good allocation prevents notes from cutting off too soon or sticking.

---

## 9.6 Voice States and Structures in C

### 9.6.1 Voice State Enum

```c name=include/voice.h
typedef enum {
    VOICE_OFF,
    VOICE_ON,
    VOICE_RELEASE,
    VOICE_STEAL_PENDING
} VoiceState;
```

### 9.6.2 Voice Data Structure

```c
typedef struct {
    VoiceState state;
    int midi_note;
    float freq;
    Oscillator osc[NUM_OSC_PER_VOICE];
    Envelope amp_env;
    Envelope filter_env;
    float velocity;
    uint32_t t_start; // Timestamp for allocation logic
} Voice;
```

---

## 9.7 Voice Pool and Polyphony Limit

- The voice pool is an array of Voice structs.
- The number of voices = maximum simultaneous notes (hardware: DACs, analog boards, CPU).
- 8 or 16 voices is typical for hybrid synths.

```c name=include/synth.h
#define MAX_VOICES 8
Voice voices[MAX_VOICES];
```

---

## 9.8 Voice Allocation Algorithms

### 9.8.1 First Free

- Assign the first available voice that is off or in release.
- Simple, but can result in "voice hogging" if a voice never enters release.

### 9.8.2 Oldest Release (Voice Stealing)

- If all voices are active, steal the one in release the longest.
- If none in release, steal the voice that was started the earliest ("oldest" voice).

### 9.8.3 Round Robin

- Rotate through voices in order, regardless of state.
- Good for drum machines, less so for expressive synth parts.

### 9.8.4 Priority/Weighted (Advanced)

- Assign voices based on velocity, channel, or other criteria.
- Used in workstation synths and advanced MIDI rigs.

---

## 9.9 Voice Allocation Example in C

```c name=src/audio/voice.c
int allocate_voice(Voice *voices, int max_voices, int midi_note) {
    // 1. Search for an off voice
    for (int i = 0; i < max_voices; ++i) {
        if (voices[i].state == VOICE_OFF) return i;
    }
    // 2. Search for a voice in release
    for (int i = 0; i < max_voices; ++i) {
        if (voices[i].state == VOICE_RELEASE) return i;
    }
    // 3. Voice stealing: find oldest active voice
    int oldest = 0;
    uint32_t oldest_time = voices[0].t_start;
    for (int i = 1; i < max_voices; ++i) {
        if (voices[i].t_start < oldest_time) {
            oldest = i;
            oldest_time = voices[i].t_start;
        }
    }
    return oldest;
}
```

---

## 9.10 Voice Lifecycle

- **Note On:** Assign voice, initialize oscillator/envelopes, set state = ON
- **Note Off:** Set state = RELEASE, envelope enters release phase
- **Release Complete:** Set state = OFF, ready for reallocation

### 9.10.1 Voice Trigger Example

```c
void note_on(Voice *voices, int max_voices, int midi_note, float velocity, uint32_t timestamp) {
    int v = allocate_voice(voices, max_voices, midi_note);
    voices[v].state = VOICE_ON;
    voices[v].midi_note = midi_note;
    voices[v].freq = midi_note_to_freq(midi_note);
    voices[v].velocity = velocity;
    voices[v].t_start = timestamp;
    envelope_note_on(&voices[v].amp_env);
    envelope_note_on(&voices[v].filter_env);
    // Init oscillators, etc.
}
void note_off(Voice *voices, int max_voices, int midi_note) {
    for (int i = 0; i < max_voices; ++i) {
        if (voices[i].state == VOICE_ON && voices[i].midi_note == midi_note) {
            voices[i].state = VOICE_RELEASE;
            envelope_note_off(&voices[i].amp_env);
            envelope_note_off(&voices[i].filter_env);
        }
    }
}
```

---

## 9.11 Per-Voice Parameter Storage

- Each Voice struct stores its own oscillator phase, envelope state, modulation values, and note info.
- Allows for independently evolving voices, critical for expressive polyphony.

---

## 9.12 Digital and Analog Voice Routing

### 9.12.1 Digital (Oscillator, Envelope, Modulation)

- All digital calculations are performed per voice (oscillator, envelope, etc.).
- Output is summed or routed to DAC channels.

### 9.12.2 Analog (VCF, VCA)

- For true hybrid, each voice’s DAC output can be routed to its own analog filter/VCA board.
- If fewer analog paths than voices, multiplexing or voice sharing is needed.

---

## 9.13 Voice Mixing and Output

- Per-voice outputs are mixed (summed) to stereo or multi-channel outputs.
- Each voice can be panned or spatialized in the mix.
- For analog output, each DAC channel corresponds to a separate voice or summed output.

---

## 9.14 Polyphony on the Raspberry Pi

- Pi 4 is powerful enough for 8–16 voices of digital synthesis at 44.1kHz, 32-bit float.
- For bare metal, real-time scheduling and efficient code critical for glitch-free polyphony.

---

## 9.15 Handling MIDI and Polyphony

- MIDI note-on/off events are mapped to voice allocation/deallocation.
- Velocity, aftertouch, and other MIDI data can be stored per-voice for dynamic modulation.

---

## 9.16 Exercise: Polyphonic Synth Test

1. Implement the voice pool, allocation, and trigger logic in C.
2. Write a test harness (on PC, using PortAudio/MIDI) that:
    - Allocates voices for chords and rapid note sequences.
    - Prints voice allocation, stealing, and release events for debugging.
    - Plays 8-note chords and rapid arpeggios; observe voice management.
3. Prepare your code for porting: keep voice logic in a separate module.

---

## 9.17 Debugging Voice Allocation

- Print/log voice state transitions (ON, RELEASE, OFF).
- Run stress tests: play more notes than available voices.
- Check for stuck notes or voice starvation (never recycled).

---

## 9.18 Further Reading

- [Martin Fay’s Guide: Voice Allocation Algorithms](http://www.martinfay.com/voice_allocation.html)
- [Mutable Instruments: Open-Source Polyphony](https://github.com/pichenettes/eurorack/tree/master/plaits)
- [Sound On Sound: Polyphony in Synths](https://www.soundonsound.com/techniques/polyphony-and-voice-allocation)

---

**End of Chapter 9**

*Next: Chapter 10 — Interfacing Pi 4 with DACs and Analog Circuits*