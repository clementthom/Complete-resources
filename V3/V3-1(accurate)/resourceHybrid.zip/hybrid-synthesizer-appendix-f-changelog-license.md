# Appendix F: Changelog and License

---

## F.1 Changelog

**v1.0 — June 2025**
- First complete release of the Hybrid Synthesizer Construction Book
- Covers theory and practical build of a hybrid (analog/digital) synthesizer
- Includes full workflow: oscillators, filters, VCAs, modulation, effects, UI, patch management, MIDI, testing, calibration, troubleshooting
- Appendices added: BOM, code structure, schematics, glossary, resources, changelog, and license

**v0.9 — May 2025**
- Added detailed effects, output, and polyphonic voice management chapters
- Expanded example code and patch format section

**v0.8 — April 2025**
- Initial draft with core chapters on hybrid synth architecture and major subsystems

---

## F.2 License

This documentation and all included files are released under the **Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)** license.

You are free to:
- **Share** — copy and redistribute the material in any medium or format
- **Adapt** — remix, transform, and build upon the material for any purpose, even commercially

Under the following terms:
- **Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
- **ShareAlike** — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

**Full license text:** [https://creativecommons.org/licenses/by-sa/4.0/](https://creativecommons.org/licenses/by-sa/4.0/)

---

## F.3 Citation

If you use or reference this book in your own work, please cite as:

> Hybrid Synthesizer Construction Book, v1.0 (2025).  
> Clement Thom and contributors.  
> [GitHub Repository URL or DOI if applicable]

---

**End of Appendices and Resource**

Thank you for building, learning, and sharing!