# Chapter 10: Interfacing the Raspberry Pi 4 with DACs and Analog Synth Circuits — Part 2: C Code for DAC Communication and Audio Output

---

## 10.12 Introduction

This part focuses on **practical C code, wiring, and software design patterns** for getting real-time audio out of your Raspberry Pi 4 and into your analog synth circuits. You’ll learn how to communicate with SPI and I2S DACs, implement efficient sample streaming, handle timing, and debug your setup—all with reusable code blocks and best practices for hybrid synth firmware.

---

## 10.13 SPI DAC Communication in C

### 10.13.1 Wiring and Physical Setup

- Connect Pi’s SPI pins to your DAC (e.g., MCP4922):
    - MOSI: GPIO10 (Pin 19)
    - SCLK: GPIO11 (Pin 23)
    - CS:   GPIO8  (Pin 24)
    - GND:  Pi GND to DAC GND
    - VDD:  DAC to 3.3V or 5V (see datasheet)
- Keep wires as short as possible for noise immunity.

### 10.13.2 Enabling SPI on the Pi

```bash
sudo raspi-config  # Interfacing Options > SPI > Enable
sudo reboot
```

### 10.13.3 SPI Library: `spidev` (Linux)

Use the Linux spidev interface for C/C++ SPI communication.

#### Install dependencies:
```bash
sudo apt-get install libspi-dev
```

#### Open and configure SPI device:
```c
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h>
#include <unistd.h>
#include <stdint.h>

#define SPI_DEV "/dev/spidev0.0"
#define SPI_SPEED 10000000  // 10 MHz for fast audio

int spi_fd;

int spi_init() {
    uint8_t mode = 0;
    uint8_t bits = 8;
    uint32_t speed = SPI_SPEED;

    spi_fd = open(SPI_DEV, O_WRONLY);
    if (spi_fd < 0) { perror("SPI open"); return -1; }
    ioctl(spi_fd, SPI_IOC_WR_MODE, &mode);
    ioctl(spi_fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
    ioctl(spi_fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
    return 0;
}
```

---

### 10.13.4 Writing Audio Samples to SPI DAC

For MCP4922 (12-bit, dual channel):

```c
void write_dac(uint16_t left, uint16_t right) {
    uint8_t buf[4];
    // Channel A (left)
    buf[0] = 0x30 | ((left >> 8) & 0x0F);  // 0x30: Write, gain=1x, active, channel A
    buf[1] = left & 0xFF;
    // Channel B (right)
    buf[2] = 0xB0 | ((right >> 8) & 0x0F); // 0xB0: Write, gain=1x, active, channel B
    buf[3] = right & 0xFF;
    write(spi_fd, buf, 4);
}
```

---

### 10.13.5 Audio Output Loop

A simple blocking loop (for proof-of-concept):

```c
#define SAMPLE_RATE 44100

void audio_loop() {
    float t = 0.0f, dt = 1.0f / SAMPLE_RATE;
    while (1) {
        float sample = sinf(2 * M_PI * 440.0f * t); // Test: 440Hz sine
        uint16_t dacval = (uint16_t)((sample + 1.0f) * 2047.5f); // [-1,1] to [0,4095]
        write_dac(dacval, dacval); // Stereo
        t += dt;
        // Simple timing (not precise! See 10.15 for real-time)
    }
}
```

---

## 10.14 I2S DAC Communication

### 10.14.1 I2S Audio DACs on Pi

- Use I2S pins (typically GPIO18 for BCLK, GPIO19 for LRCLK, GPIO21 for DATA).
- Linux and ALSA handle much of the streaming.

### 10.14.2 Using ALSA for Audio Output

- Install ALSA dev libraries:
    ```bash
    sudo apt-get install libasound2-dev
    ```
- Use ALSA PCM API to open, configure, and write samples:

```c
#include <alsa/asoundlib.h>
snd_pcm_t *pcm;
snd_pcm_open(&pcm, "default", SND_PCM_STREAM_PLAYBACK, 0);
snd_pcm_set_params(pcm,
    SND_PCM_FORMAT_FLOAT_LE, SND_PCM_ACCESS_RW_INTERLEAVED,
    2, SAMPLE_RATE, 1, 50000); // 2 channels, 44.1kHz, 50ms latency

float buffer[512 * 2];
for (int i = 0; i < 512; ++i) {
    buffer[2*i+0] = ...; // Left sample
    buffer[2*i+1] = ...; // Right sample
}
snd_pcm_writei(pcm, buffer, 512);
```

- ALSA sends samples to I2S DAC in real time.

---

## 10.15 Real-Time Audio: Timing and Buffering

### 10.15.1 Why Simple Loops Aren’t Enough

- Real-time audio must output samples at exact intervals (e.g., 44,100/sec).
- Timing drift or jitter causes glitches, pops, or stutter.

### 10.15.2 Using Timers for Precise Sample Rate (Bare Metal or Linux)

- Use a hardware or OS timer to trigger output at the required sample rate.
- On Linux, use `nanosleep`, `clock_nanosleep`, or ALSA’s built-in buffering.
- On bare metal, configure a hardware timer interrupt.

### 10.15.3 Double Buffering

- Fill one buffer while the other is being sent to the DAC.
- Swap buffers (ping-pong) for zero-latency handoff.

---

## 10.16 Audio Engine Architecture in C

### 10.16.1 Threaded Audio Output

- Use a dedicated audio thread to output samples.
- Main thread handles UI, MIDI, and parameter changes.

### 10.16.2 Ring Buffers

- Ring (circular) buffer stores audio samples ready for output.
- Producer (synth engine) writes samples; consumer (output thread) reads and sends to DAC.

---

## 10.17 Debugging and Testing Audio Output

- Use an oscilloscope to verify DAC output (check for clean wave shapes, proper voltage).
- Listen for glitches, aliasing, or quantization noise.
- Print/log sample values for debugging.
- Start with slow (1Hz) test signals to verify hardware before running full audio rates.

---

## 10.18 Portability: Preparing for Bare-Metal or RT Linux

- Keep hardware abstraction in a separate `dac.c`/`dac.h` module.
- Use macros or function pointers for switching between SPI, I2S, ALSA, or stub (for PC).
- Avoid dynamic allocation in real-time code paths.

---

## 10.19 Example: Modular DAC Output Module

```c name=include/dac.h
#ifndef DAC_H
#define DAC_H

void dac_init();
void dac_write(uint16_t left, uint16_t right);
void dac_close();

#endif
```

```c name=src/hw/dac_spi.c
#include "dac.h"
// SPI setup/teardown as above
void dac_init() { spi_init(); }
void dac_write(uint16_t l, uint16_t r) { write_dac(l, r); }
void dac_close() { close(spi_fd); }
```
Switch to another backend by swapping out the implementation file.

---

## 10.20 Exercise: Audio Output Test

1. Implement the SPI or I2S output code for your DAC.
2. Output a test tone (sine, saw, triangle) and verify on oscilloscope.
3. Play a short melody or chord progression from your synth engine, listen for correctness and glitches.
4. Try different sample rates and buffer sizes; observe effects on latency and reliability.

---

## 10.21 Further Reading

- [Linux spidev Documentation](https://www.kernel.org/doc/Documentation/spi/spidev)
- [ALSA Library API](https://www.alsa-project.org/alsa-doc/alsa-lib/)
- [Pi I2S Audio: Adafruit Guide](https://learn.adafruit.com/adafruit-i2s-stereo-decoder)
- [Bare-Metal Audio on Pi: Circle Library](https://github.com/rsta2/circle)

---

**End of Chapter 10, Part 2**

*Next: Chapter 10, Part 3 — Advanced Topics: Low-Latency, Multichannel, and Safety Considerations*