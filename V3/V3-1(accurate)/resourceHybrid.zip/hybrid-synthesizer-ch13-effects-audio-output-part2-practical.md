# Chapter 13: Effects, Audio Output, and Final Signal Path — Part 2: Practical Circuits, Digital Effects in C, and Output Stage Design

---

## 13.16 Analog Effects Circuits: Build and Test

### 13.16.1 Spring Reverb Driver and Recovery

- **Driver**: Use a small op-amp power amplifier or transformer to drive the spring tank input (impedance matching).
- **Recovery**: Op-amp preamp for output coil, with high input impedance and noise filtering.
- **Mix**: Blend wet (reverb) and dry signals via resistor network or op-amp mixer.

### 13.16.2 BBD Delay/Chorus

- **MN3207 BBD Example**:
    - Clock driver (e.g., 4047 or microcontroller PWM).
    - Pre-emphasis filter before BBD, de-emphasis after.
    - LFO (triangle or sine) modulates clock for chorus/flanger.
    - Mix dry and wet with op-amp summing stage.

### 13.16.3 Analog Distortion

- **Soft clipping**: Use 1N4148 diodes in the feedback loop of an op-amp for smooth overdrive.
- **Hard clipping**: Diodes to ground after op-amp, or use transistor stages for fuzz.

---

## 13.17 Digital Effects: C Algorithms for the Pi

### 13.17.1 Digital Delay (Echo)

```c name=src/effects/delay.c
#define DELAY_BUF_SIZE 44100 // 1 sec @ 44.1kHz

typedef struct {
    float buffer[DELAY_BUF_SIZE];
    int write_idx;
    int delay_samples;
    float feedback;
    float wet, dry;
} Delay;

void delay_init(Delay *d, int delay_ms, float feedback, float wet, float dry, float sample_rate) {
    d->write_idx = 0;
    d->delay_samples = (int)(sample_rate * delay_ms / 1000.0f);
    d->feedback = feedback;
    d->wet = wet;
    d->dry = dry;
    memset(d->buffer, 0, sizeof(d->buffer));
}

float delay_process(Delay *d, float in) {
    int read_idx = (d->write_idx + DELAY_BUF_SIZE - d->delay_samples) % DELAY_BUF_SIZE;
    float delayed = d->buffer[read_idx];
    float out = d->dry * in + d->wet * delayed;
    d->buffer[d->write_idx] = in + delayed * d->feedback;
    d->write_idx = (d->write_idx + 1) % DELAY_BUF_SIZE;
    return out;
}
```

---

### 13.17.2 Simple Digital Chorus

- Use a short, LFO-modulated delay line.
- Interpolate between buffer samples for smoothness (linear or cubic).

```c name=src/effects/chorus.c
typedef struct {
    float buffer[DELAY_BUF_SIZE];
    int write_idx;
    float rate, depth, phase;
    float wet, dry;
    float sample_rate;
} Chorus;

void chorus_init(Chorus *c, float rate, float depth, float wet, float dry, float sample_rate) {
    c->write_idx = 0;
    c->rate = rate;
    c->depth = depth;
    c->phase = 0.0f;
    c->wet = wet;
    c->dry = dry;
    c->sample_rate = sample_rate;
    memset(c->buffer, 0, sizeof(c->buffer));
}

float chorus_process(Chorus *c, float in) {
    // LFO for modulated delay (e.g., 5ms +/- 3ms)
    float lfo = sinf(2 * M_PI * c->phase) * c->depth + 0.005f; // in seconds
    int delay_samples = (int)(lfo * c->sample_rate);
    int read_idx = (c->write_idx + DELAY_BUF_SIZE - delay_samples) % DELAY_BUF_SIZE;
    float delayed = c->buffer[read_idx];
    float out = c->dry * in + c->wet * delayed;
    c->buffer[c->write_idx] = in;
    c->write_idx = (c->write_idx + 1) % DELAY_BUF_SIZE;
    c->phase += c->rate / c->sample_rate;
    if (c->phase > 1.0f) c->phase -= 1.0f;
    return out;
}
```

---

### 13.17.3 Digital Reverb (Freeverb/Schroeder)

- Use multiple parallel comb filters and serial all-pass filters.
- Open-source Freeverb and other algorithms are available for C/C++.
- For simple “plate” style, a few short delays and all-pass sections suffice.

---

## 13.18 Output Stage: Buffer, Level Shifter, and Protection

### 13.18.1 Op-Amp Output Buffer

- TL072, NE5532, or similar.
- Unity-gain follower (buffer) after DAC or effects out.
- Add series resistor (100–470Ω) for short protection.

### 13.18.2 DC-Blocking Capacitor

- 10–100μF non-polar electrolytic or film cap.
- Prevents DC offset from reaching downstream equipment.

### 13.18.3 Output Level Adjustment

- Use trimmer potentiometer or fixed resistor divider to set output to standard line or synth level.

### 13.18.4 Balanced Output (optional)

- Use DRV134/INA134 chip or transformer for balanced line out.
- Reduces hum and improves compatibility with pro gear.

---

### 13.18.5 Headphone Driver

- Use dedicated headphone amp IC or op-amp with sufficient current drive.
- Include mute relay if possible.

---

## 13.19 Complete Output Block Example

```circuit
[DAC or Effects Out] → [Op-Amp Buffer] → [DC-Block Cap] → [Output Jack]
                                 |
                        [Series Resistor]
                                 |
[Optional: Transformer/DRV134 for balanced output]
```

---

## 13.20 Breadboarding and Testing the Output Stage

1. Build op-amp buffer on breadboard.
2. Connect to function generator for test signal (or synth output).
3. Connect oscilloscope to output jack; verify clean, undistorted signal.
4. Test with headphones and line-in to a mixer/interface.
5. Check for DC offset, excessive noise, or hum.

---

## 13.21 Integrating Effects and Output Into Your Synth

- Effects code runs per voice or on mixed output, depending on architecture.
- Analog effects may be per-voice (expensive) or on summed output.
- Output buffer is always last in the chain before external connection.

---

## 13.22 Exercise: Build and Test a Full Effects/Output Path

1. Implement digital delay and chorus algorithms in your synth’s C code.
2. Patch output through analog buffer to mixer/speakers.
3. Add analog spring reverb or BBD delay (optional, for hybrid flavor).
4. Test dry/wet blend, output level, and noise/hum rejection.
5. Measure output level and impedance; verify meets target spec.

---

## 13.23 Debugging, Safety, and Maintenance

- Always power up with volume down; watch for pops/clicks.
- Use dummy loads (resistor) for headphone/line testing before live gear.
- Document voltage, current, and thermal limits for all output stages.
- Periodically clean output jacks and check all solder joints.

---

## 13.24 Further Reading

- [Open Music Labs: Analog Effects Projects](http://www.openmusiclabs.com/)
- [Valhalla DSP: Reverb Algorithms](https://valhalladsp.com/)
- [Electrosmash: BBD Analysis](https://www.electrosmash.com/bucket-brigade-device)
- [TI: Audio Op-Amp Guide](https://www.ti.com/lit/an/sboa092a/sboa092a.pdf)

---

**End of Chapter 13**

*Next: Chapter 14 — Testing, Calibration, and Troubleshooting*