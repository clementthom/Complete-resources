# Chapter 2: Project Management & Git/GitHub Basics

## 2.1 Introduction

Before you write your first line of C code or assemble your first circuit, you need a way to organize, track, and share your work. In professional and hobbyist environments alike, **project management** and **version control** are essential skills. This chapter is a deep, practical guide to managing your hybrid synthesizer project with Git and GitHub, from the ground up.

---

## 2.2 What is Project Management for Makers?

Project management is more than just making to-do lists. For engineering projects, it means:

- **Organizing files and documentation**
- **Tracking progress and changes**
- **Collaborating with others (or your future self)**
- **Planning features and bugfixes**
- **Ensuring you can always roll back to something that worked**

### Key Concepts:
- **Version control:** Track changes to your files over time.
- **Issues and milestones:** Plan features, bugs, and releases.
- **Documentation:** Keep all knowledge in one place.
- **Open source:** Share your work, invite feedback, and contribute to others.

---

## 2.3 Why Git?

**Git** is the world's most popular version control system. It lets you:
- Save snapshots of your project (commits)
- Branch off to try new features without breaking your main code
- Merge changes from others (or your own experiments)
- Go back in time to recover working states
- Work offline, then sync with remote repositories

**GitHub** provides a website to host your code, track issues, and collaborate.

---

## 2.4 Initial Project Structure

Here is a suggested directory structure for your hybrid synth project:

```
hybrid-synth/
├── README.md
├── LICENSE
├── .gitignore
├── src/
│   ├── main.c
│   ├── audio/
│   │   ├── oscillators.c
│   │   ├── envelopes.c
│   │   └── filters.c
│   ├── hardware/
│   │   ├── dac.c
│   │   └── gpio.c
│   └── ui/
│       └── ui.c
├── include/
│   ├── oscillators.h
│   ├── envelopes.h
│   ├── filters.h
│   ├── dac.h
│   ├── gpio.h
│   └── ui.h
├── tests/
│   └── test_oscillators.c
├── docs/
│   └── architecture.md
├── kicad/
│   ├── filter_board/
│   └── vca_board/
└── Makefile
```

**Explanation:**
- `src/` — All source code (.c files), grouped by function
- `include/` — All header files (.h files)
- `tests/` — Unit tests and test code
- `docs/` — Documentation, specifications
- `kicad/` — Electronics design files
- `README.md` — Overview of the project
- `LICENSE` — Your chosen open source license
- `.gitignore` — Files/directories to ignore in Git
- `Makefile` — Build instructions

---

## 2.5 Installing Git

On Linux (Solus or others):

```bash
sudo eopkg install git    # On Solus
# or
sudo apt install git      # On Debian/Ubuntu
```

On macOS:

```bash
brew install git
```

On Windows:  
Download from [git-scm.com](https://git-scm.com/).

---

## 2.6 Creating Your First Git Repository

1. **Open a terminal and navigate to your project folder:**

```bash
mkdir ~/hybrid-synth
cd ~/hybrid-synth
```

2. **Initialize git:**

```bash
git init
```

3. **Create a README file and commit it:**

```bash
echo "# Hybrid Synthesizer Project" > README.md
git add README.md
git commit -m "Initial commit: Add README"
```

4. **Add your directory structure:**

```bash
mkdir src include tests docs kicad
touch src/main.c Makefile LICENSE .gitignore
git add .
git commit -m "Add project structure"
```

---

## 2.7 Making and Recording Changes

**Workflow:**
- Edit your files
- Check what's changed: `git status`
- Add files to the next commit: `git add <file>`
- Save a snapshot: `git commit -m "Describe your change"`

**Example:**

```bash
nano src/main.c # Edit your main program
git status
git add src/main.c
git commit -m "Add empty main.c"
```

---

## 2.8 Ignoring Files

Create a `.gitignore` file to avoid saving build artifacts, OS files, etc.

```
# .gitignore
*.o
*.out
*.swp
build/
*.kicad_pcb-bak
```

Commit it:

```bash
git add .gitignore
git commit -m "Add .gitignore"
```

---

## 2.9 Branching: Safe Experimentation

Branches are parallel versions of your project.

- **Create a branch:**  
  `git checkout -b oscillator-feature`

- **Switch back:**  
  `git checkout main`

- **Merge when ready:**  
  `git checkout main`  
  `git merge oscillator-feature`

---

## 2.10 Collaborating with GitHub

1. **Create a GitHub account:**  
   [github.com](https://github.com/)

2. **Create a new repository:**  
   Use the GitHub web interface, name it `hybrid-synth`.

3. **Connect your local repo:**

```bash
git remote add origin https://github.com/<yourusername>/hybrid-synth.git
git push -u origin main
```

4. **Pushing changes:**

```bash
git push
```

5. **Pulling changes:**

```bash
git pull
```

---

## 2.11 Issues, Milestones, and Project Boards

- **Issues:** Track bugs, tasks, and feature requests.
- **Milestones:** Group issues into releases.
- **Project boards:** Visualize progress (Kanban-style).

**Example Issue:**
```
Title: Implement Sine Oscillator
Description: Write and test a basic sine wave oscillator in C. Output via PortAudio.
```

---

## 2.12 README and Documentation

A good `README.md` should include:

- Project description and goals
- How to build and run the code
- Dependencies
- Licensing
- How to contribute

**Example snippet:**

````markdown
# Hybrid Synthesizer

This project is a modern hybrid synthesizer inspired by the Synclavier, Fairlight, and others. It uses digital oscillators (on Raspberry Pi 4/PC) and analog audio processing (custom filter/amp boards).

## Building

Requirements: gcc, make, PortAudio

```bash
make
```