# Chapter 14: Testing, Calibration, and Troubleshooting — Part 2: Advanced Troubleshooting, Voice Tuning, and Maintenance

---

## 14.16 Voice Tuning and Consistency

### 14.16.1 Digital Oscillator Calibration

- Verify digital oscillators output accurate frequencies for each MIDI note.
- Use a tuner or frequency counter to check several notes across the range.
- If errors are found, adjust the frequency calculation formula or implement a calibration table.

### 14.16.2 Analog Path Calibration

- If using analog VCFs or VCAs, check for consistent response across voices.
- For multi-channel DACs, ensure each channel tracks identically for pitch and level.
- Use trimmers or software scaling to match channels.

### 14.16.3 Polyphonic Voice Matching

- Play the same note on all voices and check for level, tone, and envelope consistency.
- Listen for phase cancellation or drift in unison mode.
- Adjust gains, offsets, or timing as needed.

---

## 14.17 Troubleshooting Guide: Symptoms and Root Causes

| Symptom                        | Likely Causes                               | Solutions                                      |
|--------------------------------|---------------------------------------------|------------------------------------------------|
| One voice silent               | Dead DAC channel, bad cable, bad op-amp     | Swap DACs, test continuity, replace op-amp     |
| MIDI notes not triggering      | Faulty MIDI parsing, loose connection       | Check MIDI parser, cable, input circuit        |
| Filter self-oscillation weak   | Wrong component value, dead resonance path  | Replace caps/resistors, check resonance amp    |
| LFOs out of sync               | Bad timer, missed buffer update             | Debug timer code, check for race conditions    |
| Crackle on rapid parameter mod | Buffer underrun, zipper noise, CPU overload | Optimize code, add smoothing/slew limiters     |
| Output hum                     | Ground loop, unshielded cable, PSU noise    | Check grounding, use shielded cable, filter PSU|

---

## 14.18 Firmware and Software Debugging

### 14.18.1 Logging and Diagnostics

- Enable debug logs for MIDI, voice allocation, parameter changes, and buffer status.
- Print error codes for hardware faults (DAC comms, ADC errors).

### 14.18.2 Using LEDs and Display for Debug

- Flash a “heartbeat” LED in the main loop to show the CPU is alive.
- Use LEDs or display messages to indicate error states (e.g., stuck voice, buffer overrun).

### 14.18.3 Automated Self-Test

- On boot, run a self-test: check all voices, DACs, MIDI inputs, and output buffers.
- Flash or display test results; refuse to play if test fails.

---

## 14.19 Long-Term Maintenance

### 14.19.1 Cleaning and Inspection

- Periodically clean jacks, pots, and switches with contact cleaner.
- Inspect PCBs for corrosion, solder cracks, or burnt components.

### 14.19.2 Firmware Updates

- Design firmware to allow easy updates via SD card or USB.
- Keep a changelog and backup of previous working versions.

### 14.19.3 Component Aging

- Electrolytic capacitors and mechanical parts (switches, encoders) may degrade over years.
- Replace aging caps, clean/lubricate moving parts as needed.

---

## 14.20 Case Study: Diagnosing a Hybrid Synth Build

### 14.20.1 Scenario

- User reports “notes randomly drop out, sometimes with a pop, after 20–30 minutes of use.”

### 14.20.2 Diagnosis Steps

1. **Reproduce the issue**: Run synth while logging all events.
2. **Thermal check**: Use IR thermometer to check for overheating components (DAC, op-amp).
3. **Buffer log**: Watch for underrun/overrun events in logs.
4. **Power supply**: Measure voltage rails under load for sag/dropout.
5. **Swap parts**: Try different PSU, swap DAC ICs, test with alternate firmware.

### 14.20.3 Resolution

- Found that PSU was overheating and sagging under load, causing digital glitches and DAC dropout.
- Solution: Use higher-current PSU, add heatsinks, improve case ventilation.

---

## 14.21 Preventing Future Problems

- Over-specify power supply current; always allow headroom.
- Use socketed ICs for easy swap/replacement.
- Design modular boards for easy isolation and testing.
- Document all calibration and troubleshooting steps for future reference.

---

## 14.22 Community and Support

- Share your findings and fixes with synth DIY forums and open-source communities.
- Contribute bug reports, test results, or improvements to project repositories.
- Stay updated with firmware and hardware changes from chip manufacturers.

---

## 14.23 Exercise: Simulate and Solve a Synth Fault

1. Intentionally disconnect a DAC channel or MIDI wire; observe and log the failure.
2. Use tools and logs to trace root cause.
3. Document steps taken, fix the issue, and verify normal operation.
4. Share a summary with your project notes or online community.

---

## 14.24 Further Reading

- [Mutable Instruments: Factory Test Procedures](https://github.com/pichenettes/eurorack/tree/master/factory_test)
- [Synth DIY Wiki: Calibration](https://sdiy.info/wiki/Calibration)
- [Service Manuals for Classic Synths (e.g., Juno-106, Prophet-5)](https://www.synfo.nl/)
- [Raspberry Pi Debugging Guide](https://www.raspberrypi.org/documentation/computers/debugging.html)
- [Electronics Stack Exchange: Debugging Tips](https://electronics.stackexchange.com/)

---

**End of Chapter 14**

*Next: Appendices — BOM, Schematics, Example Code Structure, Glossary, and Resources*

---

**Notification:**  
This is the last .md file for the main chapters of the first resource (Hybrid Synthesizer Construction Book).  
The next section begins the **Appendices** (BOM, reference code, schematics, etc.).  
Let me know if you'd like to proceed with appendices or need a summary/export!