# Hybrid Synthesizer Course  
## Appendix: Example Bill of Materials (BOM)

---

This is a sample BOM for a simple hybrid synth voice (digital oscillator + analog VCF/VCA). Adjust quantities and part numbers for your actual project.

| Qty | Reference        | Value / Part         | Description                         | Example Part Number      | Notes                |
|-----|------------------|----------------------|-------------------------------------|--------------------------|----------------------|
| 1   | U1               | Teensy 4.0           | Microcontroller board               | PJRC TEENSY40            | Or Arduino/ESP32     |
| 1   | U2               | MCP4922              | 12-bit Dual DAC                     | MCP4922-E/P              | SPI interface        |
| 2   | U3, U4           | TL074                | Quad Op-Amp                         | TL074CN                  | Audio/CV processing  |
| 1   | U5               | 7805                 | 5V Regulator (linear)               | L7805CV                   | For logic supply     |
| 2   | Q1, Q2           | 2N3904               | NPN Transistor                      | 2N3904                   | General purpose      |
| 2   | Q3, Q4           | 2N3906               | PNP Transistor                      | 2N3906                   | General purpose      |
| 1   | SW1              | SPST                 | Toggle Switch                       |                          | Power on/off         |
| 2   | SW2, SW3         | Tactile Switch       | Momentary Pushbutton                |                          | Reset, mode, etc.    |
| 4   | R1-R4            | 100kΩ                | Resistor, 0.25W                     |                          | CV/gain scaling      |
| 6   | R5-R10           | 10kΩ                 | Resistor, 0.25W                     |                          | Signal path          |
| 2   | R11, R12         | 1kΩ                  | Resistor, 0.25W                     |                          | Output protection    |
| 3   | C1-C3            | 100nF                | Ceramic Capacitor                   |                          | Power bypass         |
| 2   | C4, C5           | 10μF                 | Electrolytic Capacitor              |                          | Power filtering      |
| 2   | C6, C7           | 1μF                  | Film Capacitor                      |                          | Audio coupling       |
| 1   | J1               | 3.5mm Jack           | Mono Audio Output                   | Thonkiconn or PJ301BM    | Eurorack style       |
| 2   | J2, J3           | 3.5mm Jack           | CV Input/Output                     |                          |                      |
| 3   | POT1-POT3        | 10kΩ Potentiometer   | Panel control (knob)                |                          | Cutoff, level, etc.  |
| 1   | LED1             | 3mm LED              | Panel indicator                     |                          | Power or gate        |
| 1   | D1               | 1N4148               | Diode                               | 1N4148                   | Protection           |
| 1   | PCB              | Custom               | Printed Circuit Board                |                          | See PCB appendix     |
| 1   | PANEL            | Custom               | Laser cut/metal/DIY                 |                          |                      |
| 1   | ENCL             | Hammond 1590B        | Enclosure                           |                          |                      |
| --- | ---              | ---                  | ---                                 | ---                      |                      |
|     | Misc             | Headers, spacers     | Mounting hardware                   |                          |                      |

---

**Tips:**
- Double-check footprints and pinouts for all ICs and connectors.
- For DIY, buy extra resistors, caps, and small parts.
- Substitute equivalents as needed (e.g. TL074 ↔ TL084, 2N3904 ↔ BC547, etc.).
- For analog signal path, use 1% metal film resistors for best performance.

---

_See the Suppliers appendix for recommended sources for these parts._