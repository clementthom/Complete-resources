# Hybrid Synthesizer Course  
## Chapter 6, Part 2: Analog Filters (VCF), CV Interfacing, and Full Hybrid Modulation

---

### Table of Contents

1. Analog Filter Types and Topologies (VCF Overview)
2. Designing and Building a Simple VCF (Low-Pass, State-Variable, OTA)
3. Digital CV Generation: DAC, PWM, and Multiplexing
4. Interfacing Digital Envelopes and LFOs with Analog Circuits
5. Scaling and Protecting Analog Inputs/Outputs
6. Hybrid Modulation: Mixing Digital and Analog CVs
7. Calibration and Tuning (V/Oct and Hz/V)
8. Hands-On: CV Output from a Pi or Microcontroller
9. Audio and CV Routing — Patch Bay and Matrix Concepts
10. Exercises

---

## 1. Analog Filter Types and Topologies (VCF Overview)

### **VCF (Voltage-Controlled Filter):**
- Shapes the harmonic content of the sound
- Most common: **Low-pass VCF** (removes high frequencies)
- Other types: High-pass, band-pass, notch, multimode

### **Classic Topologies:**
- **RC Ladder:** Simple but not voltage controlled
- **Transistor Ladder (Moog):** Classic analog sound, steep slope (24dB/oct)
- **State Variable:** Flexible, multiple outputs (LP, HP, BP, Notch)
- **OTA-based (e.g., LM13700):** Easy voltage control, compact, found in many synths

### **Block Diagram:**
```
[DIGITAL OSC] -> [DAC] -> [VCF] -> [VCA] -> OUTPUT
                        ^
             [CV from DAC, PWM, or Digital Envelope]
```

---

## 2. Designing and Building a Simple VCF (Low-Pass, State-Variable, OTA)

### **A. Moog Ladder (Transistor Ladder):**
- Iconic, fat sound
- Uses matched transistors or transistor arrays

### **B. State Variable Filter:**
- Uses op-amps, integrators, and OTA/VCA for voltage control
- Output: LP, BP, HP simultaneously

### **C. OTA-Based Low-Pass Filter:**
- Uses LM13700/CA3080 or SSI2164 for voltage control
- Easy to build, voltage controls cutoff via a control current

### **Example: State Variable VCF Schematic (Simplified):**
- Integrator stages for resonance/feedback
- Cutoff controlled by OTA gain (CV from DAC or PWM)

---

## 3. Digital CV Generation: DAC, PWM, and Multiplexing

### **A. DAC (Digital-to-Analog Converter):**
- Best quality, true continuous voltage
- Use for critical CVs (filter cutoff, VCA gain)
- 8, 12, 16-bit DACs common (e.g., MCP4725, PCM5102, audio HATs)

### **B. PWM (Pulse-Width Modulation):**
- Cheap, easy (any Pi or microcontroller)
- Low-pass filtered PWM output becomes a "DC" voltage
- Not as accurate or fast as DAC, but fine for LFO, envelope, etc.

### **C. Multiplexing:**
- Use one DAC/PWM channel to control multiple destinations via analog switches or sample & hold circuits

### **C Example: PWM Output on Pi (pseudo-code)**
```c
// Set Pi GPIO as PWM output, set duty cycle to desired CV level
set_pwm_duty_cycle(gpio_pin, value); // value = 0..255 or 0..1023
```

---

## 4. Interfacing Digital Envelopes and LFOs with Analog Circuits

- Calculate envelope/LFO in C (as floating-point)
- Scale and convert to voltage range (e.g., 0–5V or -5V–+5V)
- Output via DAC or filtered PWM
- Buffer with op-amp for low impedance and drive capability

### **Example:**
```c
float env = envelope_process(&env_gen); // 0..1
uint16_t dac_val = (uint16_t)(env * 4095); // 12-bit DAC
dac_write(dac_val);
```

- For bipolar CV (-5V..+5V): scale and offset in code or buffer circuit

---

## 5. Scaling and Protecting Analog Inputs/Outputs

- Use resistor dividers and op-amp buffers for scaling voltages up/down
- Clamp/limit input voltages to protect Pi/microcontroller inputs (diodes, resistors)
- Filter noise with RC low-pass (especially for PWM-based CV)

### **Protection Example:**
- Series resistor (1k–10k) + clamping diodes (Schottky to rails) + op-amp buffer

---

## 6. Hybrid Modulation: Mixing Digital and Analog CVs

**Hybrid modulation** lets you:
- Use digital LFOs/envelopes to modulate analog hardware (VCF, VCA, etc.)
- Accept analog CVs (from pedals, modular synths) into your digital code

### **Summing CVs:**
- Mix signals in analog (summing op-amp) or digital (sum then output via DAC/PWM)
- Can implement "modulation matrix" in code, output result as a single or multiple CVs

---

## 7. Calibration and Tuning (V/Oct and Hz/V)

- Most analog synths use 1V/octave or Hz/volt scaling for pitch and cutoff control
- **Calibration:** Use trimmers in analog circuit, or scale digitally in code
- Store calibration values in EEPROM or flash for repeatability

### **Pitch CV Calculation Example (1V/oct):**
```c
// MIDI note to voltage (1V/oct, C0 = 0V)
float cv = (float)(midi_note - 60) / 12.0f; // C4 (MIDI 60) = 0V
uint16_t dac_val = (uint16_t)(cv * (4095.0f / 5.0f)); // for 5V full scale, 12-bit DAC
dac_write(dac_val);
```

---

## 8. Hands-On: CV Output from a Pi or Microcontroller

### **A. DAC Output (e.g., MCP4725 via I2C):**
```c
#include "i2c_dac.h"
float lfo = lfo_process(&my_lfo); // -1..+1
float cv = 2.5f + 2.5f * lfo; // convert to 0–5V
uint16_t dac_val = (uint16_t)(cv * (4095.0f / 5.0f));
dac_write(dac_val); // send to DAC
```

### **B. PWM Output:**
- Configure GPIO as PWM
- Set duty cycle proportional to desired voltage
- Filter output with RC or op-amp buffer

### **C. Testing:**
- Connect CV output to scope or analog synth input
- Adjust code and scaling for correct range and response

---

## 9. Audio and CV Routing — Patch Bay and Matrix Concepts

- Use patch bays (physical jacks) to allow user connection of CV/audio paths
- Digital modulation matrix in code enables flexible routing
  - E.g., assign LFO to VCF cutoff, envelope to VCA, MIDI aftertouch to filter, etc.

### **Simple Routing Example:**
- User selects source and destination in UI
- Code assigns modulation source to DAC output for analog control

---

## 10. Exercises

1. **Design a state-variable VCF, draw schematic, and list potential op-amp chips to use.**
2. **Write C code to output an LFO as a control voltage via a DAC.**
3. **Simulate a PWM-based envelope output in C, and analyze output smoothing with different RC filters.**
4. **Calibrate a 1V/octave pitch CV output using a Pi and a 12-bit DAC; measure actual voltages with a multimeter.**
5. **Combine digital and analog modulation: sum a digital envelope and an external analog CV, and use the result to control filter cutoff.**
6. **Implement a basic modulation matrix in C that routes LFO, envelope, or MIDI to any CV output.**

---

**End of Chapter 6, Part 2**  
*Next: Real-world case studies, hybrid voice allocation, and building a full playable synth with digital control and analog sound!*