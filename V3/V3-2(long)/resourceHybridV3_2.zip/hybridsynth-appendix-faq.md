# Hybrid Synthesizer Course  
## Appendix: Frequently Asked Questions (FAQ)

---

### Do I need to know electronics to build a hybrid synth?

**No prior expertise is required, but basic familiarity with electronics (reading schematics, using a multimeter, soldering) is highly recommended.** The course provides step-by-step guidance and links to beginner resources.

---

### Can I use Arduino or Raspberry Pi for my hybrid synth?

**Yes.** Both Arduino (and compatible boards like Teensy) and Raspberry Pi are popular platforms for hybrid and digital synths. The course covers examples for both.

---

### What is the difference between analog, digital, and hybrid synthesizers?

- **Analog synths** use analog circuits (op-amps, transistors) for sound generation and processing.
- **Digital synths** generate/process sound using code (DSP) and microcontrollers.
- **Hybrid synths** combine both—often analog filters/VCAs with digital oscillators, control, or effects.

---

### How do I get MIDI and CV working together?

The course includes dedicated chapters on MIDI and CV integration. In general:
- Use a microcontroller with both analog (CV) inputs/outputs and MIDI (serial/USB).
- Use DAC/ADC chips for voltage conversion.
- Pay attention to voltage ranges and protection.

---

### How can I avoid damaging my components?

- Double-check all wiring before powering up.
- Use current-limited bench power or a “smoke stopper” on first power-up.
- Follow the safety appendix for best practices.

---

### Can I modify the example projects for my own needs?

**Absolutely!** The course encourages experimentation. All examples are open source and adaptable—try new controls, code, or hardware and share your results with the community.

---

### Where can I get help if I get stuck?

- See the Troubleshooting appendix.
- Search or post questions on forums listed in the Resources appendix.
- Share code, photos, and error messages to get better help.

---

### What’s the best way to learn more?

- Build and experiment as much as possible.
- Read recommended books and online articles.
- Get involved in the synth DIY community—everyone started as a beginner!

---

**If your question isn’t answered here, check the online course resources or ask in the community forums.**