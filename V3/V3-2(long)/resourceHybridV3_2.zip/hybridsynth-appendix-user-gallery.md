# Hybrid Synthesizer Course  
## Appendix: Community Builds & User Gallery

---

### About This Gallery

This section celebrates the creativity and diversity of synth builders who have followed or adapted this course. If you’d like your build featured, share pictures, schematics, or links in the community forum or submit a pull request!

---

### Featured Builds

#### 1. [Your Name or Alias] — “Hybrid Dream”  
*Description:*  
A compact desktop synth with a Teensy-based digital oscillator, analog LPG, and capacitive touch controls.  
*Special features:* OLED screen, USB MIDI, wood enclosure.

![Your Photo Here](image-placeholder.jpg)

---

#### 2. [Another User] — “Euro Hybrider”  
*Description:*  
Eurorack module with a Raspberry Pi Pico for wavetable synthesis and a classic OTA-based VCF.  
*Special features:* Panel art, patch memory, MIDI over USB.

![Your Photo Here](image-placeholder.jpg)

---

#### 3. [Community Member] — “Minimalist Voice”  
*Description:*  
Breadboarded synth voice, Arduino Nano, MCP4921 DAC, TL074 filter, and hand-wired panel.  
*Special features:* Simple, cheap, great for learning.

![Your Photo Here](image-placeholder.jpg)

---

### How to Submit Your Build

- **Via Pull Request:**  
  Fork the course repository, add your build (photos, description, credits) to this file, and make a pull request.
- **Via Forum:**  
  Post your build in the “User Gallery” thread (see Resources appendix for forum links).
- **Via Email/Contact:**  
  Reach out to the course maintainer (see Credits appendix).

---

### Tips for a Great Submission

- Include at least one clear photo (finished build or in-progress).
- Describe what makes your build unique or how you modified the design.
- Share any lessons learned, favorite features, or challenges overcome.
- Provide links to code, schematics, or demo videos if available.

---

**Let’s inspire each other—your project may be the spark for someone else’s synth adventure!**