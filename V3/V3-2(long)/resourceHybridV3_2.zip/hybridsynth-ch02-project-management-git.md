# Hybrid Synthesizer Course  
## Chapter 2: Project Management, Git, Directory Structure, and Collaboration

---

### Table of Contents

1. Why Project Management Matters
2. Overview of Development Workflow
3. Introduction to Version Control
4. Git Basics: Setup, Commits, Branches
5. Using GitHub for Collaboration
6. Structuring Your Project Directory
7. README and Documentation Best Practices
8. Collaboration Strategies: Issues, Pull Requests, Reviews
9. Tracking Progress: Milestones and Kanban Boards
10. Code Quality: Formatting, Comments, and Style
11. Example Workflows and Common Pitfalls
12. Exercises
13. Appendix: Git Command Cheat Sheet

---

## 1. Why Project Management Matters

Building a synthesizer—especially one as ambitious as this—requires more than just writing code and wiring circuits. Good project management ensures:

- You don’t lose your work.
- Changes can be tracked, reverted, or shared.
- The project grows in an organized, maintainable way.
- Collaboration is smooth, even if you work alone at first.

**You’ll learn:**  
- How to use tools professionals rely on (git, GitHub, Kanban, documentation).
- How to set up your project so you can scale and invite collaborators.
- How to avoid “spaghetti code” and hardware chaos.

---

## 2. Overview of Development Workflow

**Typical steps in a modern project:**

1. **Plan:** Brainstorm ideas, requirements, specs.
2. **Organize:** Set up directory, repository, and tools.
3. **Develop:** Write code, design hardware, test as you go.
4. **Commit:** Save progress in small, meaningful steps.
5. **Review:** Check for errors, ask for feedback (or self-review).
6. **Integrate:** Merge changes into the main project.
7. **Document:** Keep notes and instructions updated.
8. **Iterate:** Repeat!

---

## 3. Introduction to Version Control

**What is version control?**  
A system that tracks changes to your files over time, so you can recall specific versions, collaborate, and avoid disasters.

**The most popular system:**  
- **Git** (created by Linus Torvalds, used by nearly all open source projects)
- **GitHub** (web platform for sharing, reviewing, and collaborating)

---

## 4. Git Basics: Setup, Commits, Branches

### **Install git (if not already):**

```sh
sudo eopkg install git
```

### **Configure git (required for tracking your name):**

```sh
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

### **Initialize your repo (if not done):**

```sh
mkdir hybrid-synth
cd hybrid-synth
git init
```

### **Making your first commit:**

```sh
echo "# Hybrid Synthesizer Project" > README.md
git add README.md
git commit -m "Initial commit: README"
```

### **Adding files:**

```sh
touch src/main.c
git add src/main.c
git commit -m "Add main.c"
```

### **Branching (work on features without breaking main)**

```sh
git checkout -b feature/oscillators
# Work on new code
git add src/oscillators.c src/oscillators.h
git commit -m "Add initial oscillator code"
git checkout master
git merge feature/oscillators
```

---

## 5. Using GitHub for Collaboration

### **Create a remote repository:**

1. Go to [https://github.com/](https://github.com/) and create a new repo (e.g., `hybrid-synth`).
2. Link your local repo:

```sh
git remote add origin https://github.com/yourusername/hybrid-synth.git
git push -u origin master
```

### **Cloning (if you join an existing project):**

```sh
git clone https://github.com/otheruser/someproject.git
```

### **Push/Pull:**

```sh
git push          # Upload your work
git pull          # Download latest changes
```

---

## 6. Structuring Your Project Directory

A clean structure helps everyone (including future-you).  
Here’s a recommended layout, explained:

```
hybrid-synth/
├── README.md
├── LICENSE
├── .gitignore
├── src/
│   ├── main.c
│   ├── oscillators.c/h
│   ├── envelopes.c/h
│   ├── filters.c/h
│   ├── vca.c/h
│   ├── audioio.c/h
│   ├── polyphony.c/h
│   ├── midi.c/h
│   ├── ui.c/h
├── hardware/
│   ├── vcf-board.kicad_pcb
│   ├── vca-board.kicad_pcb
│   ├── spice/
│   └── bill-of-materials.md
├── docs/
│   ├── hybridsynth-ch01-intro.md
│   └── hybridsynth-ch02-project-management-git.md
├── tests/
│   ├── test_oscillators.c
│   ├── test_filters.c
│   └── test_vca.c
└── Makefile
```

**.gitignore Example:**  
Prevents build files, binaries, and temp files from cluttering the repo.

```
# .gitignore
*.o
*.out
*.elf
*.bin
*.wav
*.log
build/
hardware/spice/*.raw
```

---

## 7. README and Documentation Best Practices

**README.md** is your project’s front page.

**What to include:**
- **Project name and short description**
- **How to build and run (on PC and Pi)**
- **Directory structure explained**
- **How to contribute**
- **License (MIT, GPL, etc.)**
- **Links to external documentation**

**Sample README.md:**

```markdown
# Hybrid Synthesizer

A hybrid digital-analog synthesizer inspired by Synclavier, Emulator III, PPG, and more.

## Features
- 8 stereo (16 mono) polyphony
- Digital oscillators (Pi 4/DAC)
- Full analog filter/VCA path
- Modular C code

## Getting Started

```sh
gcc -o synth src/main.c
./synth
```

## Directory Structure

- src/: C source files
- hardware/: KiCAD, SPICE, and BOM
- docs/: Course chapters and notes
- tests/: Unit and integration tests

## License

MIT License. See LICENSE file.
```

---

## 8. Collaboration Strategies: Issues, Pull Requests, Reviews

**GitHub Issues:**  
Track bugs, to-dos, feature ideas.

**Pull Requests (PRs):**  
Propose changes. PRs are reviewed before merging, allowing feedback and discussion.

**Example workflow:**

- Open an **issue**:  
  “Add variable duty cycle to oscillator waveforms.”

- Create a **feature branch**:  
  `feature/osc-duty-cycle`

- Push changes, open a **pull request**:  
  Review with collaborators, discuss code, suggest improvements.

- **Merge**: After review, integrate changes to main branch.

---

## 9. Tracking Progress: Milestones and Kanban Boards

**Milestones:**  
Group related issues (e.g., “MVP Synth”, “Analog Board Rev 1”).

**GitHub Projects (Kanban):**  
Visualize progress:  
- **To Do** (design VCF board, implement envelopes)
- **In Progress** (test oscillator code)
- **Done** (main.c, README.md)

---

## 10. Code Quality: Formatting, Comments, and Style

**Why it matters:**  
Readable, consistent code prevents bugs and helps others (and you) understand your work.

### **Formatting:**
- Indent with 4 spaces (no tabs)
- One statement per line
- Functions no longer than 50 lines if possible

### **Comments:**
- Every function: what it does, inputs, outputs
- Every file: high-level overview at top
- “TODO” comments: mark unfinished work

**Example:**

```c
// oscillators.c
// Implements digital oscillators for the hybrid synth
//
// Functions:
//  - osc_init()
//  - osc_process()
//  - osc_set_duty_cycle()
//

#include "oscillators.h"

/**
 * Initialize oscillator.
 * @param osc Oscillator struct pointer
 * @param type Type (sine, square, etc.)
 */
void osc_init(Oscillator *osc, OscType type) {
    // ...
}
```

### **Style Guide:**  
- Use `snake_case` for variables and functions: `osc_set_duty_cycle`
- Use `CamelCase` for structs and types: `Oscillator`
- Limit global variables

---

## 11. Example Workflows and Common Pitfalls

**1. Working on a new feature:**

```sh
git checkout -b feature/oscillator-pulse
# edit src/oscillators.c src/oscillators.h
git add src/oscillators.c src/oscillators.h
git commit -m "Add pulse oscillator with variable duty cycle"
git push origin feature/oscillator-pulse
# Open Pull Request on GitHub
```

**2. Merging changes from main:**

```sh
git checkout master
git pull
git checkout feature/oscillator-pulse
git merge master
```

**Pitfalls:**
- **Forgetting to pull:** Always `git pull` before pushing changes.
- **Merge conflicts:** If two people edit the same lines, you must resolve conflicts manually.
- **Losing work:** Always commit often! Small commits are safer than huge, rare ones.

---

## 12. Exercises

1. **Set up your repository**:  
   Create the project directory, initialize git, and push to GitHub.

2. **Create a new branch**:  
   Make a branch called `feature/readme-update`, update your README, and merge it back.

3. **Open an Issue**:  
   On GitHub, open an issue titled “Analog VCF board: choose filter topology.”

4. **Document a file**:  
   Add a file header and function comments to `src/main.c`.

5. **Review a Pull Request**:  
   (If working with others) Open a PR and leave comments or suggestions.

---

## 13. Appendix: Git Command Cheat Sheet

| Command                       | What it does                         |
|-------------------------------|--------------------------------------|
| git init                      | Start a new repo                     |
| git clone URL                 | Copy a remote repo                   |
| git status                    | Show changed/unstaged files          |
| git add FILE                  | Stage file for commit                |
| git commit -m "message"       | Save staged changes                  |
| git log                       | Show commit history                  |
| git branch                    | List branches                        |
| git checkout -b new-branch    | Create and switch to new branch      |
| git merge branch              | Merge branch into current            |
| git pull                      | Download and merge from remote       |
| git push                      | Upload your work                     |
| git remote add origin URL     | Link to remote repo                  |

---

**End of Chapter 2**

*You are now ready to build, document, and collaborate like a pro.  
Next up: C Programming for Embedded Systems, from basics to advanced features you’ll need for your synth!*