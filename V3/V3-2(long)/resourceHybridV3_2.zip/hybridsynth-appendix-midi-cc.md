# Hybrid Synthesizer Course  
## Appendix: Common MIDI CC Numbers for Synth Control

---

| CC # | Name                 | Typical Use in Synths          |
|------|----------------------|-------------------------------|
| 1    | Modulation Wheel     | LFO depth, vibrato, filter    |
| 2    | Breath Controller    | Expression, effects           |
| 4    | Foot Controller      | Volume, wah, filter, etc.     |
| 5    | Portamento Time      | Glide between notes           |
| 7    | Channel Volume       | Master volume                 |
| 10   | Pan                  | Stereo position               |
| 11   | Expression           | Extra volume/dynamics         |
| 64   | Sustain Pedal        | Hold notes                    |
| 65   | Portamento On/Off    | Enable/disable glide          |
| 71   | Resonance (Timbre)   | Filter resonance/Q            |
| 72   | Release Time         | Envelope release              |
| 73   | Attack Time          | Envelope attack               |
| 74   | Filter Cutoff        | Main filter frequency         |
| 75   | Decay Time           | Envelope decay                |
| 76   | Vibrato Rate         | LFO speed                     |
| 77   | Vibrato Depth        | LFO amount                    |
| 78   | Vibrato Delay        | LFO fade-in                   |
| 91   | Reverb Level         | FX send                       |
| 93   | Chorus Level         | FX send                       |
| 120  | All Sound Off        | Emergency kill switch         |
| 123  | All Notes Off        | Emergency kill switch         |

---

- **MIDI CCs 0–31:** Standard, defined by MIDI spec
- **MIDI CCs 32–63:** Often used for LSB (high-res), or assignable
- **MIDI CCs 64–95:** Switches, effects, additional controls
- **MIDI CCs 102–119:** General-purpose/assignable (many synths use these for custom routings)
- **MIDI CCs 120–127:** Channel mode messages (special functions)

**Tip:**  
You can assign any CC to any parameter in your synth, but using the standard ones above helps with compatibility and user familiarity.

---