# Hybrid Synthesizer Course  
## Chapter 1: Introduction, Inspirations, and Project Overview

---

### Table of Contents

1. Introduction: Why Build a Hybrid Synthesizer?
2. Inspirations: Synclavier, Emulator III, PPG, DX1, Matrix12, OBX, Fairlight
3. What Makes a Hybrid Synthesizer Special?
4. Project Vision: Features, Sound, User Experience
5. Hardware/Software Split: Digital vs. Analog
6. Learning Approach: How This Course Works
7. Tools and Setup: What You Need
8. Project Directory Structure & Philosophy
9. Git & GitHub: Your First Steps in Collaboration
10. First Code: "Hello, Synth World!" in C
11. Exercises
12. Next Steps

---

## 1. Introduction: Why Build a Hybrid Synthesizer?

Welcome to your journey into the world of hybrids: instruments that combine the best of **digital precision** with the **warmth of analog electronics**.

**Why hybrid?**  
- Digital gives flexibility, precise control, and advanced features.
- Analog gives warmth, color, and "magic" that's hard to fake.
- Many legendary synths—Synclavier, Emulator III, PPG, Matrix12, OBX, DX1, Fairlight—are hybrid or have features you’ll want to combine.

This course will walk you from total beginner to expert, teaching you not just how to assemble, but how to *design* and *understand* every part of your own hybrid synthesizer.

---

## 2. Inspirations: Legendary Synths and Workstations

Each of these classic machines brought something revolutionary. Let’s see what we can learn from them:

| Name           | Year | Core Tech       | Unique Features                              |
|----------------|------|----------------|----------------------------------------------|
| Synclavier     | 1977 | FM/Additive    | Digital oscillators, analog output, sequencer|
| Fairlight III  | 1985 | Sampling       | Page R sequencer, digital/analog mix         |
| Emulator III   | 1987 | Sampling       | Warm analog filters and VCAs                 |
| PPG Wave 2.3   | 1984 | Wavetable      | Digital oscillator, analog filters           |
| PPG Realiser   | 1986 | Digital/Hybrid | Real-time DSP, touch display                 |
| DX1            | 1983 | FM Synthesis   | Advanced control, digital clarity            |
| Matrix12/OBX   | 1985 | Analog         | Huge analog sound, powerful modulation       |

**What to take from these:**
- **Voice-based modularity:** Each sound is made of independent “voices” (oscillator → filter → VCA).
- **Separation of digital & analog:** Digital for precision, analog for warmth.
- **Fast workflow:** Hardware UI, no lag, tactile controls.
- **Monochrome/limited color UI:** Focus on function, not visual flashiness.
- **Flexible routing/modulation:** The more you can modulate, the richer the sound.

---

## 3. What Makes a Hybrid Synthesizer Special?

**Definition:**  
A hybrid synthesizer uses digital electronics for sound generation and analog circuits for processing, filtering, amplifying.

**Your project:**  
- **Oscillators:** Digital (Pi 4, DACs)
- **Analog processing:** Filters, VCAs, mixing (custom boards, discrete/IC, simulated in SPICE, designed in KiCAD)
- **Polyphony:** 8 stereo (16 mono) voices
- **User interface:** Monochrome, touch, hardware buttons/knobs
- **Modular code:** Each hardware block = a `.c`/`.h` pair
- **Flexible, fast, extensible:** C code, hardware can be improved over time

---

## 4. Project Vision: Features, Sound, User Experience

### **Features**
- 8 stereo (16 mono) polyphonic digital oscillators
- Per-voice analog VCF and VCA (custom, “warm” boards)
- Envelope, LFO, modulation matrix
- MIDI input
- Simple, fast UI (monochrome/touch)
- All code in C, portable from PC (PortAudio) to Pi 4 (baremetal/Linux)
- Boards designed in KiCAD, simulated in SPICE

### **Sound**
- “As rich and full as Synclavier/Emulator III/Matrix12”
- True analog path for filters and amplifiers
- No “sterile” modern hybrid sound

### **User Experience**
- Immediate, hands-on, no menus-in-menus
- Tactile, like classic workstations

---

## 5. Hardware/Software Split: Digital vs. Analog

**Digital:**
- Oscillator engine (Pi 4, DACs)
- Envelopes, LFOs (generated in C)
- Polyphony, voice allocation
- UI logic, MIDI parsing

**Analog:**
- VCF (Voltage-Controlled Filter, e.g., SSM2044, AS3320, or custom discrete)
- VCA (Voltage-Controlled Amplifier, e.g., THAT2180 or custom)
- Mixing, output stage
- Board design in KiCAD, analog simulation in SPICE

**Hardware Topology Example Diagram:**

```
[UI]        [MIDI]
  |             |
  |             |
  V             V
[Pi4] --Digital--> [DAC] ---> [VCF] ---> [VCA] ---> [Mixer] ---> [Output]
     (osc, env, LFO)    (one chain per voice; analog boards)
```

---

## 6. Learning Approach: How This Course Works

- **Step by step:** You’ll learn, then do, then build.
- **No skipped basics:** Even “obvious” stuff is explained.
- **All code in C:** From first “Hello World” to embedded voice engines.
- **Hardware covered:** Analog circuits, board design, SPICE/KiCAD basics.
- **Testing:** All code runs on your PC (Solus Linux) first, then on your Pi.
- **Project management:** Learn git, directory structure, and how to work with others.

---

## 7. Tools and Setup: What You Need

- **Linux PC (Solus recommended)**
- **GCC** (C compiler, `sudo eopkg install gcc`)
- **PortAudio** (for audio on PC, `sudo eopkg install portaudio-devel`)
- **git** (`sudo eopkg install git`)
- **Text editor/IDE:** VSCode, Geany, Vim, etc.
- **Raspberry Pi 4** (for deployment)
- **I2S or SPI DAC** (PCM5102, MCP4922, or similar)
- **Breadboard, analog parts:** Op-amps (TL074, NE5532), resistors, capacitors, SSM2044/AS3320/THAT2180 (or equivalents)
- **KiCAD** (board design, https://kicad.org/)
- **SPICE** (simulation, e.g., ngspice or built-in to KiCAD)
- **Multimeter, oscilloscope** (optional, but highly recommended)

---

## 8. Project Directory Structure & Philosophy

Here’s a suggested structure, explained in detail:

```
hybrid-synth/
├── README.md
├── src/
│   ├── main.c              # Main entry point
│   ├── oscillators.c/h     # Digital oscillator code
│   ├── envelopes.c/h       # Envelope/LFO code
│   ├── polyphony.c/h       # Voice allocation logic
│   ├── audioio.c/h         # Audio output (PortAudio/DAC)
│   ├── filters.c/h         # Filter control (for analog board)
│   ├── vca.c/h             # VCA control (for analog board)
│   ├── midi.c/h            # MIDI input parsing
│   ├── ui.c/h              # UI (hardware/touchscreen)
├── hardware/
│   ├── vcf-board.kicad_pcb # KiCAD PCB for analog filter
│   ├── vca-board.kicad_pcb # KiCAD PCB for analog VCA
│   ├── spice/              # SPICE simulation files
│   └── bill-of-materials.md
├── docs/
│   ├── hybridsynth-ch01-intro.md  # This file!
├── tests/
│   ├── test_oscillators.c
│   ├── test_filters.c
│   └── test_vca.c
└── Makefile
```

**Philosophy:**  
Each major hardware block = its own `.c`/`.h` pair.  
Every analog board has a KiCAD project and SPICE simulation.  
All code is tested *first* on PC, then ported to Pi.

---

## 9. Git & GitHub: Your First Steps

### 1. Install git

```sh
sudo eopkg install git
```

### 2. Create and initialize your project

```sh
mkdir hybrid-synth
cd hybrid-synth
git init
```

### 3. Make your first commit

```sh
echo "# Hybrid Synthesizer Project" > README.md
git add README.md
git commit -m "Initial commit: README"
```

### 4. Create the directory structure

```sh
mkdir src hardware docs tests
touch src/main.c docs/hybridsynth-ch01-intro.md
git add .
git commit -m "Project structure and main.c added"
```

### 5. Push to GitHub

- Create a new repo on GitHub (e.g., `hybrid-synth`)
- Link it:
```sh
git remote add origin https://github.com/YOURUSERNAME/hybrid-synth.git
git push -u origin master
```

---

## 10. First Code: "Hello, Synth World!" in C

Let’s create and explain your very first C program for this project.

```c name=src/main.c
#include <stdio.h>

int main(void) {
    printf("Hybrid Synthesizer Project: Hello, Synth World!\n");
    return 0;
}
```

**Explanation:**
- `#include <stdio.h>` — Pulls in the Standard IO library for `printf`.
- `int main(void)` — Main function, entry point.
- `printf(...)` — Prints a message to your terminal.
- `return 0;` — Exits successfully.

**To compile and run:**

```sh
gcc -Wall -o synth main.c
./synth
```

You should see:  
`Hybrid Synthesizer Project: Hello, Synth World!`

---

## 11. Exercises

**1. Research**  
Find a schematic of the SSM2044 or AS3320 analog filter chip online.  
Write (in your own notes) what makes it different from a digital filter.

**2. Setup**  
Install all required software: GCC, git, PortAudio, KiCAD, and an editor.

**3. Directory**  
Create the full project directory as above. Commit your empty files.

**4. Reflection**  
Write what excites you most about analog vs. digital synths.

---

## 12. Next Steps

In the next chapter, you will learn all about project management, how to use git/GitHub for serious work, and how to structure your code and hardware to make collaboration (and your own future work) painless and efficient.

---

**End of Chapter 1**  
*The next chapter will start from this foundation, going deeper into organizing your work, collaborating, and preparing for the real code and hardware design.*

---

```c name=src/main.c
#include <stdio.h>

int main(void) {
    printf("Hybrid Synthesizer Project: Hello, Synth World!\n");
    return 0;
}
```