# Hybrid Synthesizer Course  
## Appendix: Credits & Acknowledgements

---

### Course Author

- **[Your Name Here]**  
  Synth enthusiast, educator, and lifelong tinkerer.

---

### Contributors

- **[Contributor 1]** — Feedback and beta testing
- **[Contributor 2]** — Example code, troubleshooting tips
- **[Contributor 3]** — Community moderation, translation

---

### Special Thanks

- To the global **Synth DIY** community for sharing knowledge, inspiration, and encouragement.
- To open source hardware and software creators whose work makes this course possible.
- To everyone who asks questions, shares builds, and helps others learn.

---

### Open Source & Licensing

- All course content is released under the **Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)** license, unless noted otherwise.
- Example code is released under the **MIT License** or as specified in individual files.

---

### Contact

- For questions, feedback, or to add your name to the credits, please open an issue or pull request in the course repository.
- You can also reach out via the forums listed in the Resources appendix.

---

**Thank you for being part of the hybrid synth builder community!**