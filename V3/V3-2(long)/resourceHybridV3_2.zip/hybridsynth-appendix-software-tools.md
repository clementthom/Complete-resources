# Hybrid Synthesizer Course  
## Appendix: Software Tools for Hybrid Synth Development

---

### Circuit & PCB Design

- **KiCad** — Free/open-source PCB CAD software, widely used for synth DIY.
- **Eagle** — Popular PCB tool (free for hobbyists, limited board size).
- **EasyEDA** — Web-based circuit and PCB editor, integrates with JLCPCB.
- **Fritzing** — Great for breadboard diagrams and simple PCBs.

---

### Code Development & Debugging

- **Arduino IDE / PlatformIO** — For writing and uploading code to Arduino, Teensy, and ESP32 boards.
- **Visual Studio Code** — Excellent general-purpose code editor with extensions for C/C++, Python, PlatformIO, and more.
- **Teensyduino** — Add-on for the Arduino IDE for Teensy boards.
- **Serial Monitor / CoolTerm** — For debugging serial output from microcontrollers.

---

### Audio & Signal Analysis

- **Audacity** — Free audio editor for recording, analyzing, and editing synth sounds.
- **Spear / Sonic Visualiser** — Spectral and waveform analysis for evaluating sound and tuning.
- **Oszillos Mega Scope (plugin)** — Real-time oscilloscope VST for DAWs.

---

### Simulation & Prototyping

- **LTspice** — Free analog circuit simulator for testing filter/amp designs.
- **Falstad Circuit Simulator** — Easy-to-use browser-based circuit simulator.

---

### MIDI & CV Utilities

- **MIDI-OX (Windows)** — MIDI monitoring, routing, and testing tool.
- **Hairless MIDI<->Serial Bridge** — For connecting microcontroller serial MIDI to computer MIDI ports.
- **CV Tools (Ableton Live)** — Modular synth integration and CV generation from DAW.

---

### Version Control & Collaboration

- **Git / GitHub / GitLab** — Essential for managing code, design files, and collaborating.

---

### Graphics & Documentation

- **Inkscape** — Free vector graphics editor (great for panel design).
- **GIMP** — Free raster graphics editor (good for images and textures).
- **Markdown editors** — Typora, Obsidian, VS Code, or GitHub’s built-in editor for course notes and documentation.

---

**Tip:**  
Most tools are available cross-platform (Windows, macOS, Linux), and many have strong communities or tutorials.  
Consider starting with free/open-source tools before investing in paid software.

---