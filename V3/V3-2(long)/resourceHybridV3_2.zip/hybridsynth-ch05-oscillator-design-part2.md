# Hybrid Synthesizer Course  
## Chapter 5, Part 2: Advanced Oscillator Techniques — Bandlimiting, BLEP/PolyBLEP, and High-Fidelity Digital Synthesis

---

### Table of Contents

1. Why Bandlimiting Matters: Aliasing and Digital Synthesis
2. Bandlimited Lookup Tables (BL-LUTs): Principles and Practice
3. BLEP and PolyBLEP: Efficient Bandlimited Edges
4. Oversampling and Filtering: Reducing Aliasing Further
5. Practical: Implementing PolyBLEP Oscillators in C
6. Extending Duty Cycle Modulation with PolyBLEP
7. Performance Considerations: CPU vs. Quality
8. Testing and Measuring Aliasing
9. Exercises

---

## 1. Why Bandlimiting Matters: Aliasing and Digital Synthesis

**Aliasing Recap:**  
Hard-edged waveforms (square, saw, pulse) have infinite harmonics. When these harmonics exceed the Nyquist frequency (half the sample rate), they fold back as inharmonic "alias" tones.

- **Naive digital oscillators** sound buzzy, metallic, or "digital" at high pitches.
- **Bandlimited oscillators** only generate harmonics below Nyquist, sounding smoother and more analog-like.

---

## 2. Bandlimited Lookup Tables (BL-LUTs): Principles and Practice

### **Concept:**
- Precompute tables for each pitch, containing only harmonics below Nyquist.
- For each note, select the proper BL-LUT and read/interpolate from it.

**Pros:**  
- High quality, low aliasing
- Fast on embedded if tables fit in memory

**Cons:**  
- Many tables (one per note/octave), large memory footprint
- Not trivial to generate tables

### **C Example (simplified):**

```c
#define LUT_SIZE 2048
float sine_lut[LUT_SIZE];

void init_sine_lut() {
    for (int i = 0; i < LUT_SIZE; i++) {
        sine_lut[i] = sinf(2.0f * M_PI * i / LUT_SIZE);
    }
}

float lut_read(float phase) {
    // phase: 0..1
    int idx = (int)(phase * LUT_SIZE) % LUT_SIZE;
    return sine_lut[idx];
}
```

- For BL-LUTs of saw/square, use Fourier series up to N harmonics (N set so N*freq < Nyquist).

---

## 3. BLEP and PolyBLEP: Efficient Bandlimited Edges

### **BLEP (BandLimited Step):**  
A mathematically-generated correction function to smooth out the discontinuity ("step") at waveform edges.

- Add or subtract a short, precomputed "BLEP" waveform at each discontinuity (zero-crossing, edge, or duty cycle transition).
- **PolyBLEP** is a simplified, efficient version for real-time synthesis.

**Advantages:**  
- No need for huge tables
- Works well for variable duty cycle (PWM), FM, sync, etc.
- Easy to implement and fast enough for real-time synthesis

---

### **PolyBLEP: How It Works**

- Whenever a discontinuity (edge) occurs in the phase accumulator, blend in a small correction.
- Correction is local in time (polyBLEP = Polynomial BLEP).

**PolyBLEP Function:**  
(See [PolyBLEP paper by Tale](https://www.kvraudio.com/forum/viewtopic.php?t=375517) for background.)

```c
// t = phase, dt = phase increment (frequency/sample_rate)
static inline float poly_blep(float t, float dt) {
    if (t < dt) {
        t /= dt;
        return t + t - t * t - 1.0f;
    } else if (t > 1.0f - dt) {
        t = (t - 1.0f) / dt;
        return t * t + t + t + 1.0f;
    } else {
        return 0.0f;
    }
}
```

---

## 4. Oversampling and Filtering: Reducing Aliasing Further

### **Oversampling:**  
- Generate audio at a higher sample rate (e.g., 4x or 8x your target)
- Apply a low-pass filter
- Downsample to the target rate

**Pros:**  
- Very effective at reducing aliasing
- Works for all oscillator types

**Cons:**  
- CPU intensive (especially on embedded)
- Adds complexity

---

## 5. Practical: Implementing PolyBLEP Oscillators in C

### **polyblep_oscillator.h:**
```c name=src/polyblep_oscillator.h
#ifndef POLYBLEP_OSCILLATOR_H
#define POLYBLEP_OSCILLATOR_H

typedef enum {
    PB_OSC_SAW,
    PB_OSC_SQUARE,
    PB_OSC_PULSE
} PB_OscType;

typedef struct {
    PB_OscType type;
    float frequency;
    float phase;
    float duty_cycle; // For square/pulse
    float last_output; // For DC correction, etc.
} PB_Oscillator;

void pb_osc_init(PB_Oscillator *osc, PB_OscType type, float freq, float duty);
void pb_osc_set_frequency(PB_Oscillator *osc, float freq);
void pb_osc_set_duty_cycle(PB_Oscillator *osc, float duty);
float pb_osc_process(PB_Oscillator *osc);

#endif
```

---

### **polyblep_oscillator.c:**
```c name=src/polyblep_oscillator.c
#include "polyblep_oscillator.h"
#include <math.h>

#define SAMPLE_RATE 48000.0f

static inline float poly_blep(float t, float dt) {
    if (t < dt) {
        t /= dt;
        return t + t - t * t - 1.0f;
    } else if (t > 1.0f - dt) {
        t = (t - 1.0f) / dt;
        return t * t + t + t + 1.0f;
    } else {
        return 0.0f;
    }
}

void pb_osc_init(PB_Oscillator *osc, PB_OscType type, float freq, float duty) {
    osc->type = type;
    osc->frequency = freq;
    osc->phase = 0.0f;
    osc->duty_cycle = duty;
    osc->last_output = 0.0f;
}

void pb_osc_set_frequency(PB_Oscillator *osc, float freq) {
    osc->frequency = freq;
}

void pb_osc_set_duty_cycle(PB_Oscillator *osc, float duty) {
    if (duty < 0.01f) duty = 0.01f;
    if (duty > 0.99f) duty = 0.99f;
    osc->duty_cycle = duty;
}

// PolyBLEP sawtooth
static float pb_saw(PB_Oscillator *osc, float dt) {
    float t = osc->phase;
    float out = 2.0f * t - 1.0f;
    out -= poly_blep(t, dt);
    return out;
}

// PolyBLEP square/pulse (with duty cycle)
static float pb_square(PB_Oscillator *osc, float dt) {
    float t = osc->phase;
    float duty = osc->duty_cycle;
    float out = (t < duty) ? 1.0f : -1.0f;
    // Rising edge at 0.0
    out += poly_blep(t, dt);
    // Falling edge at duty cycle
    float t2 = fmodf(t - duty + 1.0f, 1.0f); // wrap-around for pulse edge
    out -= poly_blep(t2, dt);
    return out;
}

float pb_osc_process(PB_Oscillator *osc) {
    float dt = osc->frequency / SAMPLE_RATE;
    float sample = 0.0f;

    switch (osc->type) {
        case PB_OSC_SAW:
            sample = pb_saw(osc, dt);
            break;
        case PB_OSC_SQUARE:
        case PB_OSC_PULSE:
            sample = pb_square(osc, dt);
            break;
    }

    osc->phase += dt;
    if (osc->phase >= 1.0f) osc->phase -= 1.0f;

    osc->last_output = sample;
    return sample;
}
```

---

## 6. Extending Duty Cycle Modulation with PolyBLEP

**PWM with PolyBLEP:**  
- Just as with the naive method, you can modulate `duty_cycle` in real time.
- PolyBLEP ensures the pulse edges are bandlimited, so even rapid PWM sounds smooth and clean.

**Example:**
```c
// LFO-driven PWM
float lfo = sinf(2.0f * M_PI * lfo_phase);
pb_osc_set_duty_cycle(&my_osc, 0.5f + 0.25f * lfo); // 25%-75% PWM
```

---

## 7. Performance Considerations: CPU vs. Quality

- PolyBLEP is almost as fast as naive oscillators, but vastly superior in sound.
- Oversampling and BL-LUTs are more CPU/memory hungry.
- For most synths, PolyBLEP is the best compromise for real-time, multi-voice operation on embedded or PC.

---

## 8. Testing and Measuring Aliasing

- Render a high-pitch (e.g., 8 kHz) saw or square wave with both naive and PolyBLEP methods.
- Plot or listen for inharmonic "alias" tones — PolyBLEP should sound much cleaner.
- Use Audacity or a spectrum analyzer to view harmonics.

**Example:**
```c
// Render and save 8kHz saw with both methods, compare in Audacity
```

---

## 9. Exercises

1. **Implement PolyBLEP PWM:**  
   Modulate the duty cycle from 10% to 90% and listen for aliasing artifacts.

2. **Compare naive and PolyBLEP at high pitch:**  
   Save 1024 samples of each at 8 kHz and plot their spectra.

3. **Try oversampling:**  
   Render a waveform at 192kHz, low-pass filter, then downsample to 48kHz. Is it cleaner?

4. **Memory check:**  
   Estimate RAM usage for BL-LUTs for 128 notes × 1024 samples × 4 bytes/sample.

5. **CPU profiling:**  
   Use `time` or a profiler to compare the speed of different oscillator methods.

---

**End of Chapter 5, Part 2**  
*Next: Combining digital oscillators with analog signal paths — connecting your Pi or PC-generated audio to real analog filters, VCAs, and hardware!*