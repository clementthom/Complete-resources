# Hybrid Synthesizer Course  
## Chapter 3, Part 1: C Programming for Embedded Systems — The Basics

---

### Table of Contents

1. Why C for Synths and Embedded?
2. Setting Up: Compilers, Editors, First Build
3. Anatomy of a C Program
4. Variables, Data Types, and Arithmetic
5. Control Structures: If, Loops, and Blocks
6. Functions: Declaring, Defining, Using
7. Header Files: Why and How
8. Modular Design: Breaking Up Your Synth Code
9. Hands-on: Your First Modular C Synth Stubs
10. Exercises

---

## 1. Why C for Synths and Embedded?

C is the language of choice for hardware, embedded systems, and real-time audio because:
- **Speed:** C compiles to fast, efficient machine code.
- **Control:** You manage memory and hardware directly.
- **Portability:** C runs on PCs, microcontrollers, Raspberry Pi, and more.
- **Ecosystem:** All major audio libraries, DSP code, and embedded frameworks use C.

The legendary synths you admire? Their digital brains were almost always written in C (or even assembly).

---

## 2. Setting Up: Compilers, Editors, First Build

### **Install GCC:**
On Solus Linux:
```sh
sudo eopkg install gcc
```

### **Text Editors:**
- **VSCode** (GUI, powerful)
- **Geany** (lightweight, good for C)
- **Vim/Nano** (terminal-based)

### **Writing and Compiling Your First Program:**

Create `src/main.c`:

```c name=src/main.c
#include <stdio.h>

int main(void) {
    printf("Welcome to the Hybrid Synthesizer world!\n");
    return 0;
}
```

Compile and run:
```sh
cd src
gcc -Wall -o synth main.c
./synth
```

Output:
```
Welcome to the Hybrid Synthesizer world!
```

---

## 3. Anatomy of a C Program

Let's break down the basic structure:

```c
#include <stdio.h>   // Preprocessor directive: includes the Standard IO library

int main(void) {     // Main function: where your program starts
    printf("Hello!\n"); // Function call: prints a string
    return 0;           // Return value: 0 means success
}
```

**Key points:**
- All code is inside functions (usually `main` at first).
- Every statement ends with a semicolon `;`.
- Curly braces `{}` mark blocks of code.

---

## 4. Variables, Data Types, and Arithmetic

### **Basic Types:**

| Type      | Bytes | Example      | Range / Use         |
|-----------|-------|--------------|---------------------|
| int       | 4     | int x = 42;  | -2B to +2B          |
| float     | 4     | float y=3.14;| Decimals, ~7 digits |
| double    | 8     | double z=1.0;| More precision      |
| char      | 1     | char c='A';  | Single letter/byte  |

### **Declaring Variables:**

```c
int voices = 8;
float freq = 440.0;
char mode = 'M';
```

### **Arithmetic:**

```c
int sum = 2 + 2;           // 4
float half = 5.0 / 2.0;    // 2.5
int polyphony = voices * 2; // 16
```

**Order of Operations:**  
Standard math rules apply. Use parentheses to group.

---

## 5. Control Structures: If, Loops, and Blocks

### **If Statements:**

```c
if (freq > 1000.0) {
    printf("High frequency!\n");
} else {
    printf("Normal frequency.\n");
}
```

### **For Loops:**

```c
for (int i = 0; i < voices; i++) {
    printf("Voice %d active\n", i);
}
```

### **While Loops:**

```c
int count = 0;
while (count < 5) {
    printf("Count: %d\n", count++);
}
```

### **Blocks:**
Curly braces `{}` group multiple statements.

---

## 6. Functions: Declaring, Defining, Using

**Functions** let you organize code into reusable pieces.

```c
// Declaration (prototype)
void say_hello(void);

// Definition
void say_hello(void) {
    printf("Hello from a function!\n");
}

// Usage
int main(void) {
    say_hello(); // Call the function
    return 0;
}
```

**Parameters and Return Values:**

```c
float add(float a, float b) {
    return a + b;
}

int main(void) {
    float sum = add(2.0, 3.5);
    printf("Sum: %f\n", sum);
    return 0;
}
```

---

## 7. Header Files: Why and How

Header files (`.h`) declare functions, types, and constants for sharing between `.c` files.

### **Example:**

```c name=src/oscillators.h
#ifndef OSCILLATORS_H
#define OSCILLATORS_H

// Enum for oscillator types
typedef enum {
    OSC_SINE,
    OSC_SQUARE,
    OSC_TRIANGLE,
    OSC_SAW,
    OSC_PULSE
} OscType;

// Oscillator struct
typedef struct {
    OscType type;
    float frequency;
    float duty_cycle; // For square/pulse
    float phase;
} Oscillator;

// Function prototypes
void osc_init(Oscillator* osc, OscType type, float freq, float duty);
float osc_process(Oscillator* osc);

#endif // OSCILLATORS_H
```

**Explanation:**
- `#ifndef ... #define ... #endif` prevents double inclusion.
- Enums for types, structs for state.
- Function prototypes let other files use oscillator functions.

---

## 8. Modular Design: Breaking Up Your Synth Code

A real synth project is too big for one file.  
Break up by hardware block or logical function.

**Example Directory:**

```
src/
├── main.c
├── oscillators.c
├── oscillators.h
├── envelopes.c
├── envelopes.h
```

### **oscillators.c Example:**

```c name=src/oscillators.c
#include "oscillators.h"
#include <math.h> // For sinf(), M_PI

#define SAMPLE_RATE 48000.0f

void osc_init(Oscillator* osc, OscType type, float freq, float duty) {
    osc->type = type;
    osc->frequency = freq;
    osc->duty_cycle = duty;
    osc->phase = 0.0f;
}

float osc_process(Oscillator* osc) {
    float out = 0.0f;
    osc->phase += osc->frequency / SAMPLE_RATE;
    if (osc->phase >= 1.0f) osc->phase -= 1.0f;

    switch (osc->type) {
        case OSC_SINE:
            out = sinf(2.0f * M_PI * osc->phase);
            break;
        case OSC_SQUARE:
            out = (osc->phase < osc->duty_cycle) ? 1.0f : -1.0f;
            break;
        case OSC_TRIANGLE:
            out = 2.0f * fabsf(2.0f * osc->phase - 1.0f) - 1.0f;
            break;
        case OSC_SAW:
            out = 2.0f * osc->phase - 1.0f;
            break;
        case OSC_PULSE:
            out = (osc->phase < osc->duty_cycle) ? 1.0f : -1.0f;
            break;
    }
    return out;
}
```

**Notice:**  
- Uses the duty cycle for square/pulse waves.
- You can later modulate `osc->duty_cycle` for PWM sounds!

---

## 9. Hands-on: Your First Modular C Synth Stubs

### **Putting it all together:**

```c name=src/main.c
#include <stdio.h>
#include "oscillators.h"

int main(void) {
    Oscillator osc1;
    osc_init(&osc1, OSC_SQUARE, 440.0f, 0.5f); // 50% duty cycle

    for (int i = 0; i < 10; i++) {
        float sample = osc_process(&osc1);
        printf("Sample %d: %f\n", i, sample);
    }
    return 0;
}
```

**What this does:**  
- Initializes a square wave oscillator at 440 Hz with 50% duty.
- Generates 10 samples and prints them (you’ll output to audio soon).

---

## 10. Exercises

1. **Compile and run the above code. Try changing the oscillator type and duty cycle.**
2. **Add another oscillator (triangle or saw). Print its output.**
3. **Modify the code so the oscillator frequency sweeps from 220 Hz to 880 Hz. Print samples.**
4. **Write your own function to reset an oscillator’s phase to zero.**
5. **Read about the difference between `float` and `double` in C. When would you use each?**

---

**End of Chapter 3, Part 1.**  
*Part 2 will cover pointers, memory, structs in detail, and how to use them for more advanced synth code (such as dynamic voice arrays and memory management).*