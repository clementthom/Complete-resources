# Hybrid Synthesizer Course  
## Chapter 3, Part 4: Embedded C — Portability, Bare-Metal Considerations, and Hardware Interfacing

---

### Table of Contents

1. From Desktop to Embedded: Code Portability Principles
2. Fixed-Point vs. Floating Point: Why It Matters for Synths
3. Bare-Metal Programming Basics (Raspberry Pi)
4. Memory-Mapped I/O: Controlling Hardware from C
5. Timing and Delays: Accurate Clocks Without OS
6. Interrupts: Responding to Hardware Events
7. Cross-Compiling: Building PC Code for the Pi
8. C Project Templates for Embedded Synths
9. Hands-on: Simulating Embedded Constraints on PC
10. Exercises

---

## 1. From Desktop to Embedded: Code Portability Principles

Not all code written for a PC will run efficiently (or at all) on embedded hardware.  
**Key portability concepts:**
- Avoid assuming availability of standard libraries (`stdio.h`, `math.h`, etc.)
- Use fixed-width data types: `uint8_t`, `int16_t` from `<stdint.h>`.
- Minimize dynamic memory (`malloc`/`free`)—prefer static allocation.
- Use conditional compilation (`#ifdef`) for platform-specific code.

**Example:**

```c
#ifdef TARGET_PI
// Use hardware-specific code
#else
// Use PC code (e.g., PortAudio)
#endif
```

---

## 2. Fixed-Point vs. Floating Point: Why It Matters for Synths

### **Floating Point:**
- Easy to use (`float`, `double`)
- May be slow or unsupported on some microcontrollers
- Great for rapid prototyping on PC

### **Fixed-Point:**
- Represents fractions using integers (e.g., Q15 = 1 sign, 15 fractional bits)
- Faster, predictable on embedded hardware
- More complex to implement, but essential for high-performance synths

**Example (Q15 conversion):**
```c
// Convert float [-1.0, 1.0) to Q15 int16_t
int16_t float_to_q15(float x) {
    if (x > 0.999969) x = 0.999969; // avoid overflow
    if (x < -1.0f) x = -1.0f;
    return (int16_t)(x * 32767);
}

// Convert Q15 int16_t to float
float q15_to_float(int16_t x) {
    return ((float)x) / 32767.0f;
}
```

---

## 3. Bare-Metal Programming Basics (Raspberry Pi)

### **Bare-metal** means running without an OS:  
- Direct control of CPU, memory, peripherals
- No `malloc`, no file system, no `printf` (unless you write your own UART code!)
- Must set up stack, reset vectors, and hardware initialization yourself

**Resources:**  
- [Baking Pi](https://www.cl.cam.ac.uk/projects/raspberrypi/tutorials/os/) — University of Cambridge tutorial
- [Circle](https://github.com/rsta2/circle) — C++ bare-metal framework for Pi

---

## 4. Memory-Mapped I/O: Controlling Hardware from C

All hardware on the Pi is controlled by reading/writing specific memory addresses.

**Example:**  
To toggle a GPIO pin (simplified):

```c
#define GPIO_BASE 0x20200000
#define GPFSEL1   (*(volatile unsigned int*)(GPIO_BASE + 0x04))
#define GPSET0    (*(volatile unsigned int*)(GPIO_BASE + 0x1C))
#define GPCLR0    (*(volatile unsigned int*)(GPIO_BASE + 0x28))

void gpio_set_output(int pin) {
    GPFSEL1 |= (1 << ((pin % 10) * 3));
}

void gpio_write(int pin, int value) {
    if (value)
        GPSET0 = (1 << pin);
    else
        GPCLR0 = (1 << pin);
}
```

- `volatile` tells the compiler these addresses can change at any time (i.e., they’re hardware registers).

---

## 5. Timing and Delays: Accurate Clocks Without OS

### **Busy-wait Loops:**  
Inefficient, but simple for short delays.

```c
void delay_cycles(volatile unsigned int count) {
    while (count--) { __asm__("nop"); }
}
```

### **Hardware Timers:**  
Use Pi’s hardware timer registers for precise timing.

```c
#define TIMER_BASE 0x20003000
#define TIMER_CLO  (*(volatile unsigned int*)(TIMER_BASE + 0x04))

void delay_us(unsigned int us) {
    unsigned int start = TIMER_CLO;
    while ((TIMER_CLO - start) < us) ;
}
```

---

## 6. Interrupts: Responding to Hardware Events

Embedded systems often use **interrupts** to handle events (e.g., MIDI input, audio buffer ready).

### **Concept:**
- Register an Interrupt Service Routine (ISR) for a hardware event.
- When event occurs, CPU jumps to your ISR code.

### **Code Sketch:**
```c
void __attribute__((interrupt("IRQ"))) my_isr(void) {
    // Handle event (e.g., fill audio buffer)
}
```

**Note:**  
Exact syntax and setup depends on your toolchain and Pi model.

---

## 7. Cross-Compiling: Building PC Code for the Pi

You will need a **cross-compiler** to build ARM executables from your PC.

### **Install cross-compiler (on Ubuntu/Debian, adapt for Solus):**

```sh
sudo apt install gcc-arm-none-eabi
```

### **Compiling:**
```sh
arm-none-eabi-gcc -mcpu=cortex-a7 -mfpu=neon-vfpv4 -nostdlib -o synth.elf main.c
```
- `-nostdlib`: no standard library (bare-metal)
- Add linker script, startup code as needed for real bare-metal builds

### **For Linux on Pi:**
- Use regular GCC, but target ARM (`arm-linux-gnueabihf-gcc`)

---

## 8. C Project Templates for Embedded Synths

You’ll need:
- A `main.c` with minimal setup (stack, init, loop)
- Platform-specific driver code (`audio.c`, `gpio.c`, etc.)
- Synth engine code (`oscillators.c`, `filters.c`, …)

**Minimal bare-metal main:**
```c
void main(void) {
    // Initialize hardware
    // Infinite synthesis loop
    while (1) {
        // Fill buffer, output to DAC
    }
}
```

---

## 9. Hands-on: Simulating Embedded Constraints on PC

You can simulate “embedded” constraints:
- Avoid dynamic allocation
- Use integer math where possible
- Write your own delay/timer functions (simulate with nanosleep on PC)
- Use `#ifdef` to stub out hardware functions

**Example:**
```c
#ifdef TARGET_EMBEDDED
void delay_ms(unsigned int ms) {
    // Hardware timer code
}
#else
#include <unistd.h>
void delay_ms(unsigned int ms) {
    usleep(ms * 1000);
}
#endif
```

---

## 10. Exercises

1. **Modify your oscillator code to use only `int16_t` and fixed-point math.**
2. **Write a function that outputs a square wave to a “virtual” GPIO pin (on PC, print 1/0).**
3. **Simulate a timer interrupt by calling a callback function at regular intervals using PC code.**
4. **Set up a cross-compilation toolchain for your Raspberry Pi. Build a “Hello, World!” binary for ARM.**
5. **Write documentation in your README explaining the differences between your PC and embedded code.**
6. **Research: What are the pros and cons of using an RTOS (Real-Time Operating System) versus bare-metal?**

---

**End of Chapter 3, Part 4**  
*Next: Integrating Analog and Digital — How to control DACs, design audio interfaces, and connect your C code to real analog synth hardware!*