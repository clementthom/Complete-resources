# Hybrid Synthesizer Course  
## Appendix: Troubleshooting Guide

---

### No Sound Output

- **Check power rails:** Confirm all required voltages are present and stable.
- **Verify audio path:** Use an oscilloscope or audio probe to trace the signal from oscillator to output.
- **Mute switches or VCAs:** Ensure VCAs are open and mute switches are off.
- **Check cables and jacks:** Confirm connections and look for shorts or broken wires.

---

### Synth Won’t Respond to MIDI or CV

- **MIDI:** Check cable orientation and MIDI channel. Use a MIDI monitor to confirm data is being received.
- **CV:** Verify correct voltage range and polarity. Test with a known-good CV source.
- **Microcontroller:** Confirm firmware is loaded and running (try serial debug output).

---

### Tuning/Tracking Problems

- **Scale trimmer:** Adjust for correct V/oct or Hz/V response.
- **Offset trimmer:** Set correct base frequency.
- **Component values:** Recheck resistor/capacitor values in CV summing or scaling circuits.
- **Temperature drift:** Allow warm-up time; use tempco resistors if needed.

---

### Unstable or Noisy Sound

- **Grounding:** Ensure all modules share a common ground.
- **Power supply:** Check for ripple, replace noisy wall-warts.
- **Shielding:** Keep digital and analog grounds separated where possible.
- **Cable routing:** Don’t run audio lines parallel to power or digital lines.

---

### Microcontroller/Software Issues

- **Serial output:** Use debugging prints to check firmware status.
- **Firmware upload:** Double-check board and port selection in your IDE.
- **Hangs/crashes:** Comment out code sections or use a minimal sketch to isolate issues.
- **Boot issues:** Power-cycle the board and disconnect/reconnect USB.

---

### General Debugging Tips

- **Start simple:** Test one module at a time before integrating.
- **Swap components:** Use known-good parts to isolate faults.
- **Take breaks:** Fresh eyes catch mistakes you might miss.
- **Ask for help:** Forums and communities can often spot issues quickly.

---

**A systematic approach and patience are your best tools. Nearly every synth builder has faced these problems—don’t get discouraged!**