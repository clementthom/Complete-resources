# Hybrid Synthesizer Course  
## Appendix: License and Usage

---

### Copyright and Usage

This course content is provided under the [Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)](https://creativecommons.org/licenses/by-sa/4.0/) license.

You are free to:

- **Share** — copy and redistribute the material in any medium or format
- **Adapt** — remix, transform, and build upon the material for any purpose, even commercially

Under the following terms:

- **Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
- **ShareAlike** — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

---

### Third-Party Code and Content

- Any code snippets marked as "example" or "template" are provided under the same CC BY-SA 4.0 license unless otherwise noted.
- Please check third-party library licenses when integrating with external code or hardware.

---

### Citing and Sharing

If you use or adapt this course for your own project, class, or documentation, please credit the original author(s) and provide a link to the source repository or website if available.

---

**Happy hacking, building, and synthesizing!**