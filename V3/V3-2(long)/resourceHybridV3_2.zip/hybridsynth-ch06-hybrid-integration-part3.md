# Hybrid Synthesizer Course  
## Chapter 6, Part 3: Voice Allocation, Polyphony, and Real-Time Hybrid Performance

---

### Table of Contents

1. Voice Allocation in Hybrid Synths: Concepts and Strategies
2. Digital Voice Management: Algorithms and Data Structures in C
3. Analog Signal Path for Polyphony: Mixing, Summing, and VCAs
4. Handling Note Priority, Stealing, and Retriggering
5. Hybrid Envelope and LFO Assignment (Per-Voice and Global)
6. Real-Time Performance: Latency, Timing, and Buffering
7. Hands-On: Implementing Voice Allocation in C
8. Hybrid Synth Playability: MIDI Input, Control, and Feedback
9. Debugging and Analyzing Polyphonic Audio
10. Exercises

---

## 1. Voice Allocation in Hybrid Synths: Concepts and Strategies

A **voice** is a complete signal path (oscillator, envelope, VCA, filter) for a single note.

- **Monophonic:** 1 voice (all notes share the same signal path)
- **Polyphonic:** Multiple voices (each note can have its own signal path)

**Strategies:**
- **Round-robin:** Assign new notes to next available voice in order
- **First free:** Use first idle voice (most efficient, simplest)
- **Note priority:** Oldest, newest, highest/lowest note
- **Voice stealing:** When all voices are busy, “steal” a voice (usually the quietest or oldest)

---

## 2. Digital Voice Management: Algorithms and Data Structures in C

### **Voice Struct Example:**
```c
typedef struct {
    Oscillator osc;
    Envelope env;
    int midi_note;
    int active;
    uint32_t start_time; // For priority/stealing
} Voice;
```

### **Voice Allocation Algorithm:**
```c
int find_free_voice(Voice *voices, int n) {
    for (int i = 0; i < n; i++)
        if (!voices[i].active)
            return i;
    // No free voice, steal the oldest
    int oldest = 0;
    for (int i = 1; i < n; i++)
        if (voices[i].start_time < voices[oldest].start_time)
            oldest = i;
    return oldest;
}
```

- On note-on: allocate voice, set params, mark active, set start_time
- On note-off: release envelope, mark inactive when finished

---

## 3. Analog Signal Path for Polyphony: Mixing, Summing, and VCAs

- **Digital polyphony:** Multiple voices mixed in code, output to DAC
- **Analog polyphony:** Each voice has its own analog path, then summed (rare outside of high-end or modular synths)

**Most hybrid synths:**
- Digitally mix all voices, output a single stereo/mono stream via DAC
- Use analog VCF/VCA for final timbre and dynamics

---

## 4. Handling Note Priority, Stealing, and Retriggering

- **Note priority:** Decide which notes are kept when polyphony limit is reached
- **Voice stealing:** Fade out or immediately cut the “stolen” voice
- **Retriggering:** If a voice is stolen for the same note, retrigger envelope/oscillator

### **C Example:**
```c
void note_on(uint8_t midi_note, Voice *voices, int num_voices, uint32_t time) {
    int v = find_free_voice(voices, num_voices);
    voice_start(&voices[v], midi_note, time);
}
```

---

## 5. Hybrid Envelope and LFO Assignment (Per-Voice and Global)

- **Per-voice:** Each note has its own envelope/LFO (for independent articulation)
- **Global:** Shared LFO/envelope for all voices (e.g., filter LFO, global pitch)
- **Hybrid:** Mix per-voice and global modulation for expressive sounds

---

## 6. Real-Time Performance: Latency, Timing, and Buffering

- **Buffer size:** Small = low latency, high CPU; Large = high latency, lower CPU
- **MIDI input:** Process as soon as received; keep MIDI-to-sound latency <10ms for best feel
- **DAC update rate:** Must match sample rate; avoid jitter/glitches with consistent timing

---

## 7. Hands-On: Implementing Voice Allocation in C

### **Voice Array and Management:**
```c
#define MAX_VOICES 8
Voice voices[MAX_VOICES];

void handle_note_on(uint8_t midi_note, uint32_t now) {
    int v = find_free_voice(voices, MAX_VOICES);
    voice_start(&voices[v], midi_note, now);
}

void handle_note_off(uint8_t midi_note) {
    for (int i = 0; i < MAX_VOICES; i++)
        if (voices[i].active && voices[i].midi_note == midi_note)
            voice_release(&voices[i]);
}
```

---

## 8. Hybrid Synth Playability: MIDI Input, Control, and Feedback

- **MIDI input:** Use USB MIDI, serial MIDI, or software MIDI parsing (e.g., ALSA on Linux)
- **Velocity, aftertouch, controllers:** Map to envelopes, filter cutoff, PWM, etc.
- **Feedback:** LEDs, screen, or serial output for debugging/playability

---

## 9. Debugging and Analyzing Polyphonic Audio

- **Oscilloscope:** Check for correct envelope shapes, polyphonic summing/glitches
- **Software (Audacity, DAW):** Record and analyze output
- **Debug prints:** Show voice allocation, MIDI events, envelope states

---

## 10. Exercises

1. **Implement a round-robin voice allocator in C.**
2. **Simulate “note stealing” by playing more notes than available voices; print which voices are being stolen.**
3. **Add per-voice LFOs and envelopes; compare to global modulation.**
4. **Measure latency from MIDI note-on to audible sound; try different buffer sizes.**
5. **Record a polyphonic performance and analyze voice usage in your code’s debug output.**
6. **Design a simple UI (text or graphical) that shows voice allocation in real time.**

---

**End of Chapter 6, Part 3**  
*Next: Final integration — putting together your hybrid synth, real-time controls, and performance-ready features!*

---

**You will be notified when you reach the last `.md` file in the course.**