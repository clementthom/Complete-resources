# Hybrid Synthesizer Course  
## Appendix: Resources & Further Reading

---

### Books

- **Make: Analog Synthesizers** by Ray Wilson  
  (Beginner-friendly, covers both analog and hybrid approaches)
- **Handmade Electronic Music** by Nicolas Collins  
  (Great for creative circuits and experimental ideas)
- **Electronic Music: Systems, Techniques, and Controls** by Allen Strange  
  (Classic synth text, covers theory and practical circuits)
- **Electronic Music Circuits** by Barry Klein  
  (Circuit designs and explanations for DIYers)

---

### Key Websites & Forums

- **Electro-Music** — [electro-music.com](https://www.electro-music.com/)
- **Mod Wiggler (formerly Muff Wiggler)** — [modwiggler.com](https://www.modwiggler.com/forum/)
- **Synth DIY Wiki** — [sdiy.info](https://sdiy.info/)
- **Arduino Forum** — [forum.arduino.cc](https://forum.arduino.cc/)
- **Teensy Audio Library** — [pjrc.com/teensy/td_libs_Audio.html](https://www.pjrc.com/teensy/td_libs_Audio.html)
- **Mutable Instruments GitHub** — [github.com/pichenettes/eurorack](https://github.com/pichenettes/eurorack)
- **Music From Outer Space** — [musicfromouterspace.com](http://musicfromouterspace.com/)

---

### Video Tutorials & Channels

- **Look Mum No Computer** — [YouTube](https://www.youtube.com/c/lookmumnocomputer)
- **Moritz Klein** — [YouTube](https://www.youtube.com/c/MoritzKleinTech)
- **Sam Battle (LMNC)** — Creative synth builds and explanations
- **Notes & Volts** — [YouTube](https://www.youtube.com/c/Notesandvolts)
- **Synth DIY Guy** — [YouTube](https://www.youtube.com/c/SynthDIYGuy)

---

### Open Source Projects

- **Mutable Instruments** — [github.com/pichenettes/eurorack](https://github.com/pichenettes/eurorack)
- **Music Thing Modular** — [github.com/TomWhitwell/MTM](https://github.com/TomWhitwell/MTM)
- **Teensy Audio Library Examples** — [github.com/PaulStoffregen/Audio](https://github.com/PaulStoffregen/Audio)

---

### Glossaries & Reference

- **Synth DIY Wiki Glossary** — [sdiy.info/wiki/Glossary](https://sdiy.info/wiki/Glossary)
- **MIDI Association** — [midi.org](https://www.midi.org/)

---

### Inspiration & Community

- **r/synthdiy** on Reddit — [reddit.com/r/synthdiy](https://www.reddit.com/r/synthdiy/)
- **Discord servers:**  
  Search for “synth DIY” or “modular synth” communities.

---

**Keep exploring—there’s always something new to learn in the world of hybrid and DIY synthesis!**