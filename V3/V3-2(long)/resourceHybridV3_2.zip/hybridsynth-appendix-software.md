# Hybrid Synthesizer Course  
## Appendix: Useful Software Tools

---

### Audio & DSP Development

- **Audacity** — Free audio editor and recorder ([audacityteam.org](https://www.audacityteam.org/))
- **Pure Data (Pd)** — Visual programming for sound ([puredata.info](https://puredata.info/))
- **SuperCollider** — Audio synthesis and algorithmic composition ([supercollider.github.io](https://supercollider.github.io/))
- **Sonic Pi** — Live coding music synth ([sonic-pi.net](https://sonic-pi.net/))
- **VCV Rack** — Virtual modular synthesizer ([vcvrack.com](https://vcvrack.com/))

---

### Electronics & Hardware Design

- **KiCad** — Open source PCB design ([kicad.org](https://kicad.org/))
- **Fritzing** — Circuit prototyping and breadboard diagrams ([fritzing.org](https://fritzing.org/))
- **LTspice** — Analog circuit simulator ([analog.com/en/design-center/design-tools-and-calculators/ltspice-simulator.html](https://www.analog.com/en/design-center/design-tools-and-calculators/ltspice-simulator.html))
- **EasyEDA** — Online PCB and schematic tool ([easyeda.com](https://easyeda.com/))

---

### Microcontroller & Embedded

- **Arduino IDE** — For Arduino, Teensy, ESP ([arduino.cc](https://www.arduino.cc/))
- **PlatformIO** — Cross-platform embedded development ([platformio.org](https://platformio.org/))
- **Teensyduino** — Add-on for Arduino IDE ([pjrc.com/teensy/teensyduino.html](https://www.pjrc.com/teensy/teensyduino.html))
- **Raspberry Pi Imager** — For SD card setup ([raspberrypi.com/software/](https://www.raspberrypi.com/software/))

---

### Code & Collaboration

- **Visual Studio Code** — Powerful code editor ([code.visualstudio.com](https://code.visualstudio.com/))
- **Git** — Version control ([git-scm.com](https://git-scm.com/))
- **GitHub** — Project hosting and collaboration ([github.com](https://github.com/))

---

### Utilities

- **Serial Monitor** — Built into Arduino IDE or use [CoolTerm](https://freeware.the-meiers.org/) / [PuTTY](https://www.putty.org/)
- **MIDI-OX** — MIDI monitoring (Windows) ([midiox.com](https://www.midiox.com/))
- **Pocket MIDI** — MIDI monitor (Mac/Win) ([mountainutilities.eu/pocketmidi](https://www.mountainutilities.eu/pocketmidi))
- **Logic Analyzers** — Saleae Logic software ([saleae.com](https://www.saleae.com/))

---

**Refer to each chapter for recommended tools for specific tasks.**