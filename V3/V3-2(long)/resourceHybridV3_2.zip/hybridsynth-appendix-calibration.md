# Hybrid Synthesizer Course  
## Appendix: Calibration & Tuning Procedures

---

### Why Calibration Matters

Proper calibration ensures your hybrid synth is in tune, tracks accurately, and responds consistently to CV and MIDI. Analog and hybrid instruments may drift or vary due to component tolerances.

---

### Calibration Tools Needed

- Multimeter (for DC voltage checks)
- Frequency counter or tuner (hardware or software, e.g. smartphone app)
- Oscilloscope (optional, but very helpful)
- Small screwdriver (for trimmers)

---

### Typical Calibration Steps

#### 1. Power Supply Check

- **Verify all power rails** (e.g. +12V, -12V, +5V) are present and stable before adjusting anything else.
- Check for excessive ripple or noise.

#### 2. Offset (Zero/Reference) Adjustment

- Set all controls (pitch, cutoff, etc.) to their minimum or center positions.
- Adjust offset trimmers so output voltages (or oscillator pitch) are at their intended base value (e.g. 0V or C note).

#### 3. V/Octave or Scale Trimming

- Apply a known CV (e.g. 0V, then 1.000V) to the oscillator’s CV input.
- Measure output pitch or frequency.
- Adjust the “scale” trimmer so that a 1V increase results in a pitch increase of exactly one octave.
- Repeat for several octaves to ensure linearity.

#### 4. Filter Cutoff & Resonance

- With no CV applied, set filter cutoff to minimum.
- Adjust filter offset trimmer so the cutoff frequency is as low as possible without oscillation.
- For self-oscillating filters, use a tuner to set the resonance trimmer so the filter oscillates in tune with a reference note.

#### 5. VCA Calibration

- Apply maximum CV to the VCA and measure output level.
- Adjust gain trimmer for desired maximum output (avoid clipping).
- Set minimum CV and ensure the VCA fully mutes the signal.

---

### MIDI to CV Calibration

- Send middle C from your MIDI controller; measure the CV output (should be 0V or 1V, depending on your standard).
- Send an octave higher; adjust scaling so the output increases by exactly 1V.
- Use built-in calibration routines if your firmware supports it.

---

### Calibration Tips

- Allow the synth to warm up for 10-15 minutes before calibrating.
- Use 1% or better resistors in precision circuits.
- Document your calibration settings for future reference or repairs.
- If your synth has digital auto-calibration, follow the instructions in the firmware documentation.

---

**Accurate calibration is the key to a musical, reliable instrument. Take your time—good tuning pays off every time you play!**