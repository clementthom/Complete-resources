# Hybrid Synthesizer Course  
## Chapter 6, Part 4: Real-Time Control, User Interface, and Performance Features

---

### Table of Contents

1. Real-Time Control in Hybrid Synths: What and Why
2. UI Options: Hardware, Software, and Hybrid Approaches
3. MIDI Integration: USB, DIN, and Host/Device Modes
4. Parameter Mapping: Assigning Controls to Sound Engines
5. Smoothing, Debouncing, and Interpolation for Live Control
6. Displaying Status: LEDs, LCDs, OLEDs, and GUIs
7. Preset Management: Saving, Loading, and Morphing Patches
8. Hands-On: Basic UI Implementation in C (Buttons, Encoders, MIDI)
9. Live Performance Considerations: Latency, Feedback, Safety
10. Exercises

---

## 1. Real-Time Control in Hybrid Synths: What and Why

- **Real-time control** is essential for expressive performance.
- Includes: knobs, sliders, mod wheels, aftertouch, pedals, MIDI CCs, touchscreens, OSC, and more.
- Enables parameter sweeps, dynamic modulation, and live tweaking.

---

## 2. UI Options: Hardware, Software, and Hybrid Approaches

### **Hardware Controls:**
- Pots, encoders, sliders, buttons, switches, joysticks, touch sensors.
- Read via ADC, GPIO, I2C/SPI expanders.

### **Software UI:**
- On-screen controls (LCD, OLED, touchscreen, PC GUI, web)
- Useful for deep editing, patch management, and visualization.

### **Hybrid UI:**
- Combine hardware for tactile immediacy and software for depth.

**Design Tip:**  
- Prioritize critical, performance-time controls in hardware.
- Use menus/screens for setup, advanced options, and patch editing.

---

## 3. MIDI Integration: USB, DIN, and Host/Device Modes

### **MIDI Inputs:**
- **DIN:** Classic 5-pin, opto-isolated, simple UART protocol.
- **USB MIDI:** Modern, flexible, can be host (Pi/PC) or device (controller).
- **Software MIDI:** ALSA, JACK, virtual ports on PC/Linux.

### **Implementation:**
- Use libraries (e.g., RtMidi, ALSA MIDI, TinyUSB) on Pi/PC.
- Parse MIDI Note, CC, Pitch Bend, Aftertouch, Program Change.

### **C Example: Parsing MIDI Note On/Off**
```c
void handle_midi(uint8_t *msg) {
    uint8_t status = msg[0] & 0xF0;
    uint8_t note = msg[1];
    uint8_t vel = msg[2];
    if (status == 0x90 && vel > 0) note_on(note, vel);
    else if ((status == 0x80) || (status == 0x90 && vel == 0)) note_off(note);
}
```

---

## 4. Parameter Mapping: Assigning Controls to Sound Engines

- **Direct mapping:** One control, one parameter
- **Matrix mapping:** Any control can modulate any parameter (see modulation matrix)
- **Macros:** One control affects multiple parameters for expressive morphs
- **MIDI Learn:** User assigns MIDI CCs to parameters on the fly

**Example Data Structure:**
```c
typedef struct {
    uint8_t control_id;
    uint8_t target_param;
    float amount;
} ControlMapping;
```

---

## 5. Smoothing, Debouncing, and Interpolation for Live Control

- **Debouncing:** Prevents noise from physical switches/buttons.
- **Smoothing:** Prevents “zipper noise” or abrupt jumps in sound from pots/encoders.
- **Interpolation:** Linear/exponential smoothing for smooth parameter changes.

**Simple Smoothing in C:**
```c
float smooth(float prev, float input, float smoothing) {
    return prev + (input - prev) * smoothing;
}
// smoothing: 0.0 = no smoothing, 1.0 = instant jump
```

---

## 6. Displaying Status: LEDs, LCDs, OLEDs, and GUIs

- **LEDs:** Indicate activity, status, or modulation amount
- **Character LCDs:** Cheap, simple (HD44780, I2C/SPI)
- **OLEDs/TFTs:** Graphical, beautiful, more code/hardware required
- **PC GUI/Web UI:** Use for deep editing, patch librarian

**Example:**
- Show current patch, parameter values, or even waveform visualization

---

## 7. Preset Management: Saving, Loading, and Morphing Patches

- **Presets:** Store all parameter values for instant recall
- **Morphing:** Interpolate between two (or more) presets for evolving sounds
- **Storage:** SD card, EEPROM, flash, or file system

**C Example:**
```c
typedef struct {
    float params[NUM_PARAMS];
} Preset;

void save_preset(Preset *preset, const char *filename);
void load_preset(Preset *preset, const char *filename);
```

---

## 8. Hands-On: Basic UI Implementation in C (Buttons, Encoders, MIDI)

### **Reading a Button (GPIO):**
```c
int read_button(int gpio_pin) {
    // Platform-specific code: return 1 if pressed, 0 if not
}
```

### **Reading a Pot (ADC):**
```c
int read_pot(int adc_channel) {
    // Return value 0..1023 (10-bit ADC)
}
```

### **Encoder Example:**
- Use interrupts or polling to detect rotary encoder movement; increment/decrement parameter value.

### **MIDI Assignment:**
- Assign MIDI CC to a parameter, update value on receiving new data.

---

## 9. Live Performance Considerations: Latency, Feedback, Safety

- **Keep latency low:** <10ms from control move to sound change
- **Visual feedback:** LEDs, displays, or GUI to reassure performer
- **Safety:** Clamp parameter ranges, avoid digital overloads
- **Fail gracefully:** If control is unplugged or signal lost, keep making music!

---

## 10. Exercises

1. **Design a control panel for your synth with at least 6 hardware controls. List what each does.**
2. **Write C code to read a pot/encoder and map its value smoothly to oscillator frequency or filter cutoff.**
3. **Implement debouncing for a button input and test with rapid presses.**
4. **Set up basic preset save/load functionality; verify that parameter changes persist.**
5. **Connect a MIDI controller and map its mod wheel to filter cutoff.**
6. **Build a simple UI (hardware or software) to display the current patch name and parameter values.**

---

**End of Chapter 6, Part 4**  
*Next: Final project assembly, debugging, and bringing your hybrid synth to life for a real-world jam!*

---

**You will be notified when you reach the last `.md` file in the course.**