# Hybrid Synthesizer Course  
## Appendix: Parts Suppliers & Shopping Tips

---

### Recommended Suppliers

- **Mouser Electronics** — [mouser.com](https://www.mouser.com/)  
  Wide selection, global shipping, good for ICs, passives, and connectors.

- **Digi-Key** — [digikey.com](https://www.digikey.com/)  
  Huge stock, fast shipping, ideal for semiconductors and microcontrollers.

- **Tayda Electronics** — [taydaelectronics.com](https://www.taydaelectronics.com/)  
  Great prices for small components, pots, jacks, and stripboard.

- **Thonk** — [thonk.co.uk](https://www.thonk.co.uk/)  
  Eurorack hardware, knobs, panels, and synth-specific parts.

- **Adafruit** — [adafruit.com](https://www.adafruit.com/)  
  Good for microcontrollers, displays, sensors, and prototyping gear.

- **SparkFun** — [sparkfun.com](https://www.sparkfun.com/)  
  Similar to Adafruit, plus kits and learning resources.

- **PJRC** — [pjrc.com](https://www.pjrc.com/)  
  Official distributor for Teensy boards and audio shields.

- **AliExpress** — [aliexpress.com](https://www.aliexpress.com/)  
  Cheap bulk hardware, but watch for quality and shipping times.

- **Amazon / eBay**  
  Useful for enclosures, tools, and generic parts.

---

### PCB & Panel Fabrication

- **JLCPCB** — [jlcpcb.com](https://jlcpcb.com/)
- **PCBWay** — [pcbway.com](https://www.pcbway.com/)
- **Osh Park** — [oshpark.com](https://oshpark.com/)

---

### Shopping Tips

- **Double-check footprints and specs** before ordering (especially ICs and connectors).
- **Order spares** of cheap, easy-to-lose parts (resistors, capacitors, headers).
- **Watch for minimum order quantities** and shipping fees.
- **Combine orders** with friends or group buys to save on shipping.
- **Compare prices** across suppliers for expensive chips or hard-to-find parts.
- **For obsolete or rare parts:**  
  Try local electronics shops, synth forums, or the Synth DIY Facebook group.

---

**Always verify part numbers and compatibility with your design before checkout!**