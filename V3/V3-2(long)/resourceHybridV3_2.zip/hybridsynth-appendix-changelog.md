# Hybrid Synthesizer Course  
## Appendix: Changelog & Version History

---

### v1.0 (2025-06-22)
- Initial public release.
- Complete course content and all appendices:
    - FAQ
    - Troubleshooting
    - Example BOM
    - Parts Suppliers
    - Software Tools
    - Calibration & Tuning
    - Glossary
    - Resources
    - User Gallery
    - Credits

---

### How to Contribute to the Changelog

- For every major update, add a new dated entry at the top.
- Summarize key changes, new sections, or important fixes.
- For minor typo fixes or formatting, batch them under a single line (e.g. “Minor corrections.”).

---

### Planned Updates

- Add more user-contributed builds to the Gallery.
- Expand the “Digital Control” and “Advanced Modulation” chapters.
- Translate course materials into additional languages.
- Add more video walkthroughs and code examples.

---

_See the course repository for the latest updates and version tags._