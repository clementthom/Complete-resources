# Hybrid Synthesizer Course  
## Appendix: Safety & Best Practices

---

### Electrical Safety

- **Double-check power connections** before powering up—reverse polarity or short circuits can destroy components.
- **Never work on a powered circuit** unless you are certain it is safe.
- **Use a fused power supply** and check fuse ratings for your project.
- **Be mindful of mains voltage!**  
  Most synth builds use low-voltage DC supplies, but if you must interface with AC/mains, use proper insulated enclosures and consult an expert.

---

### Soldering & Assembly

- **Work in a well-ventilated area** when soldering.
- **Wash hands** after soldering or handling leaded components.
- **Wear eye protection** when clipping leads or using power tools.
- **Secure your workpiece**—use a vise or helping hands for stability.

---

### Handling Components

- **Observe anti-static precautions** with ICs and MOSFETs (use an anti-static wrist strap if possible).
- **Don’t force components into breadboards or sockets**—check pin alignment.
- **Store small parts in labeled containers** to avoid mix-ups and loss.

---

### Testing & Debugging

- **Power up slowly** with a current-limited supply or use a “smoke stopper” for first tests.
- **Measure voltages before inserting expensive ICs**.
- **If you smell burning or see smoke,** disconnect power immediately and inspect your circuit.

---

### Fire & Burn Hazards

- **Keep flammable materials away** from soldering irons and hot equipment.
- **Let soldering irons cool** completely before storage.
- **Do not leave powered circuits unattended** during testing.

---

### General Best Practices

- **Keep your workspace tidy**—clutter leads to mistakes and accidents.
- **Label wires, connectors, and boards**—especially in modular or complex builds.
- **Document your work:** take photos, keep notes, and mark up schematics as you go.
- **Take breaks:** fatigue increases mistakes and reduces safety.

---

**Safety first! A careful approach ensures your synth-building journey is productive, fun, and injury-free.**