# Hybrid Synthesizer Course  
## Chapter 4: Digital Audio Fundamentals for Synthesis

---

### Table of Contents

1. What is Digital Audio?
2. Sampling: Theory and Practice
3. Bit Depth: Resolution and Dynamic Range
4. Aliasing and Anti-Aliasing
5. Nyquist Theorem and Practical Implications
6. Digital Audio Formats: PCM, WAV, and Beyond
7. Audio Buffers and Block Processing
8. DAC (Digital-to-Analog Converter) Fundamentals
9. Clocking, Jitter, and Latency
10. Hands-on: Generating and Saving Audio Files in C
11. Exercises

---

## 1. What is Digital Audio?

**Digital audio** is the representation of sound as a series of numbers. Unlike analog audio, which is a continuous electrical signal, digital audio samples that signal at regular intervals (the sample rate) and quantizes each sample to a finite set of possible values (bit depth).

**Why digital audio in synths?**
- Precise, repeatable control over waveforms and processing
- Easy to store, manipulate, and transmit
- Portable between devices/platforms

---

## 2. Sampling: Theory and Practice

### **Sampling Rate**

- **Definition:** The number of times per second an analog audio signal is measured (sampled).
- **Common values:** 44,100 Hz (CD), 48,000 Hz (pro audio), 96,000 Hz (high-res)
- **Each "sample" is a single numerical value representing the audio at that instant.**

**Example:**  
At 48,000 Hz, you get 48,000 samples per second.

### **C Example:**
```c
#define SAMPLE_RATE 48000

for (int n = 0; n < SAMPLE_RATE; n++) {
    float t = (float)n / SAMPLE_RATE;
    float sample = sinf(2.0f * M_PI * 440.0f * t); // 440 Hz sine
    // Store or output sample
}
```

### **Oversampling**

- Processing at higher sample rates (e.g., 192kHz) can reduce artifacts and aliasing.

---

## 3. Bit Depth: Resolution and Dynamic Range

### **Bit Depth**

- Number of bits used to represent each sample.
- **CD audio:** 16 bits (values from -32768 to +32767)
- **Pro audio:** 24 bits (values from -8,388,608 to +8,388,607)
- **Integer or floating-point?**  
  - Most DACs use integer PCM, but modern systems often use floats internally.

**Dynamic Range (dB) ≈ 6.02 × bit depth**

- 16 bits = ~96 dB
- 24 bits = ~144 dB

### **C Example:**
```c
int16_t sample = (int16_t)(sin(2 * M_PI * 440.0 * t) * 32767);
```

---

## 4. Aliasing and Anti-Aliasing

**Aliasing:**  
When a signal contains frequency components above half the sample rate (the Nyquist frequency), those frequencies “fold back” into the audible range as false signals.

- **Prevention:** Never generate or process audio frequencies above Nyquist.
- **Anti-aliasing filter:** A low-pass filter applied before sampling (or after synthesis in digital domain).

**Example:**  
Sample rate = 48kHz → Nyquist = 24kHz  
A digital oscillator generating 30kHz will alias to 18kHz (48-30).

---

## 5. Nyquist Theorem and Practical Implications

**Nyquist theorem:**  
To faithfully represent a frequency, the sample rate must be at least twice that frequency.

- Highest reproducible frequency: sample rate / 2
- All frequencies above this will alias.

**In practice:**  
- Use a sample rate much higher than the highest desired audio frequency.
- Synthesize and filter signals to stay below Nyquist.

---

## 6. Digital Audio Formats: PCM, WAV, and Beyond

- **PCM (Pulse-Code Modulation):** Raw digital audio, uncompressed.
- **WAV:** Standard file format for uncompressed PCM audio.
- **Others:** AIFF, FLAC, MP3 (compressed)

### **WAV Format Structure:**
- Header: Contains metadata (sample rate, bit depth, channels, etc.)
- Data: Audio samples

**Writing a simple WAV file in C:**

```c name=src/write_wav.c
#include <stdio.h>
#include <stdint.h>

void write_wav_header(FILE *f, int sample_rate, int num_samples) {
    // Very basic PCM WAV header for mono 16-bit
    uint32_t datasize = num_samples * 2;
    fwrite("RIFF", 1, 4, f);
    uint32_t size = 36 + datasize;
    fwrite(&size, 4, 1, f);
    fwrite("WAVEfmt ", 1, 8, f);
    uint32_t fmt_size = 16; fwrite(&fmt_size, 4, 1, f);
    uint16_t audio_format = 1; fwrite(&audio_format, 2, 1, f);
    uint16_t num_channels = 1; fwrite(&num_channels, 2, 1, f);
    fwrite(&sample_rate, 4, 1, f);
    uint32_t byte_rate = sample_rate * 2; fwrite(&byte_rate, 4, 1, f);
    uint16_t block_align = 2; fwrite(&block_align, 2, 1, f);
    uint16_t bits_per_sample = 16; fwrite(&bits_per_sample, 2, 1, f);
    fwrite("data", 1, 4, f);
    fwrite(&datasize, 4, 1, f);
}
```

---

## 7. Audio Buffers and Block Processing

Audio is usually processed in **blocks** (e.g., 64, 128, 256 samples) for efficiency.

- **Buffer:** Array of samples processed together
- **Latency:** Larger buffers increase latency; smaller buffers increase CPU load

**C Example:**

```c
#define BLOCK_SIZE 256
float buffer[BLOCK_SIZE];

for (int i = 0; i < BLOCK_SIZE; i++) {
    buffer[i] = osc_process(&osc1);
}
```

---

## 8. DAC (Digital-to-Analog Converter) Fundamentals

A DAC converts digital numbers into analog voltages.

- **Resolution:** Number of bits (8, 12, 16, 24)
- **Speed:** Must keep up with your sample rate (e.g., 48kHz)
- **Interfaces:** I2S, SPI, parallel

**Audio path:**  
`[CPU] -> [DAC] -> [Analog Filter/VCF] -> [Amplifier/VCA] -> [Speaker]`

**Common DAC chips:**  
- PCM5102 (I2S, 24-bit)
- MCP4922 (SPI, 12-bit/dual)

### **Sending data to a DAC (pseudo-code):**

```c
void send_to_dac(int16_t sample) {
    // For SPI DAC, send 2 bytes (MSB first)
    spi_send((sample >> 8) & 0xFF);
    spi_send(sample & 0xFF);
}
```

---

## 9. Clocking, Jitter, and Latency

- **Clock:** Governs sample timing; jitter can cause distortion/noise.
- **Latency:** Delay from input to output (sum of buffer, processing, and hardware delays).
- **Goal:** Minimize jitter and latency for tight, musical response.

---

## 10. Hands-on: Generating and Saving Audio Files in C

### **Generate a 1-second 440 Hz sine wave and save as WAV:**

```c name=src/gen_sine_wav.c
#include <stdio.h>
#include <stdint.h>
#include <math.h>

#define SAMPLE_RATE 48000
#define DURATION 1.0
#define NUM_SAMPLES ((int)(SAMPLE_RATE*DURATION))

void write_wav_header(FILE *f, int sample_rate, int num_samples);

int main() {
    FILE *f = fopen("sine440.wav", "wb");
    if (!f) return 1;
    write_wav_header(f, SAMPLE_RATE, NUM_SAMPLES);
    for (int n = 0; n < NUM_SAMPLES; n++) {
        float t = (float)n / SAMPLE_RATE;
        float s = sinf(2.0f * M_PI * 440.0f * t);
        int16_t sample = (int16_t)(s * 32767);
        fwrite(&sample, 2, 1, f);
    }
    fclose(f);
    return 0;
}

// WAV header code from earlier
void write_wav_header(FILE *f, int sample_rate, int num_samples) {
    uint32_t datasize = num_samples * 2;
    fwrite("RIFF", 1, 4, f);
    uint32_t size = 36 + datasize;
    fwrite(&size, 4, 1, f);
    fwrite("WAVEfmt ", 1, 8, f);
    uint32_t fmt_size = 16; fwrite(&fmt_size, 4, 1, f);
    uint16_t audio_format = 1; fwrite(&audio_format, 2, 1, f);
    uint16_t num_channels = 1; fwrite(&num_channels, 2, 1, f);
    fwrite(&sample_rate, 4, 1, f);
    uint32_t byte_rate = sample_rate * 2; fwrite(&byte_rate, 4, 1, f);
    uint16_t block_align = 2; fwrite(&block_align, 2, 1, f);
    uint16_t bits_per_sample = 16; fwrite(&bits_per_sample, 2, 1, f);
    fwrite("data", 1, 4, f);
    fwrite(&datasize, 4, 1, f);
}
```

**Compile and run:**
```sh
gcc -o gen_sine_wav gen_sine_wav.c -lm
./gen_sine_wav
aplay sine440.wav      # Or use any media player
```

---

## 11. Exercises

1. **Change the code to generate a 2-second triangle wave at 220 Hz.**
2. **Modify the bit depth: save 8-bit samples instead of 16-bit.**
3. **Add a simple linear fade-in and fade-out to the generated wave.**
4. **Implement a low-pass filter in C and apply it to a noisy signal before saving.**
5. **Create a buffer of 1024 samples, fill with a sweep from 100 Hz to 10kHz, and save as WAV.**
6. **Research: What is “dither” and why is it used when reducing bit depth? Try adding dither noise to your samples.**

---

**End of Chapter 4**  
*Next: Oscillator design in depth — theory, digital implementation, and hands-on code for variable-duty-cycle waveforms and more!*