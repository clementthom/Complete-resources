# Hybrid Synthesizer Course  
## Chapter 6, Part 1: Hybrid Integration — Bridging Digital Oscillators with Analog Hardware

---

### Table of Contents

1. Architecture of a Hybrid Synth: Digital and Analog Working Together
2. Overview of Analog Signal Path Elements (VCF, VCA, Mixer)
3. Audio Output from Pi/PC: Line Level, Headphone, Differential
4. DAC Selection and Interfacing: I2S, SPI, Parallel, Audio HATs
5. Digital-to-Analog Conversion: Resolution, Sample Rate, and Filtering
6. Level Shifting, Buffering, and Impedance Matching
7. Anti-Imaging and Reconstruction Filters
8. Hands-On: Connecting a Raspberry Pi (or PC) to Analog Circuits
9. Basic Audio Measurements with a Soundcard or Oscilloscope
10. Exercises

---

## 1. Architecture of a Hybrid Synth: Digital and Analog Working Together

A hybrid synthesizer combines the strengths of digital and analog technology:

- **Digital Domain:**  
  - Oscillators, envelopes, LFOs, digital modulation, sequencing, MIDI, patch memory  
  - Implemented in C on a Raspberry Pi or PC

- **Analog Domain:**  
  - Filters (VCF), amplifiers (VCA), analog mixing, distortion, analog control  
  - Implemented with op-amps, transistors, analog ICs

**Typical Signal Flow:**  
```
[DIGITAL] --> [DAC] --> [VCF] --> [VCA] --> [OUTPUT]
|             |         |         |         |
Oscs       Analog    Analog    Analog   Audio Out
Envelope   Filter    Ampl.    Mixer
```

- The digital section generates audio and control voltages, outputs via DAC.
- The analog section shapes, colors, and amplifies the sound.

---

## 2. Overview of Analog Signal Path Elements (VCF, VCA, Mixer)

### **Voltage-Controlled Filter (VCF):**
- Selectively removes frequencies
- Types: Low-pass, high-pass, band-pass, multi-mode
- Classic chips: SSM2044, CEM3320, LM13700

### **Voltage-Controlled Amplifier (VCA):**
- Controls amplitude via CV
- Chips: CA3080, LM13700, SSI2164

### **Mixer:**
- Combines signals (op-amps as summing amplifiers)

### **Patch Example:**  
```
[DIGITAL OSC] --[DAC]--> [VCF] --> [VCA] --> [AUDIO OUT]
```
- Digital envelopes modulate VCF cutoff and VCA gain via secondary DAC channels or PWM.

---

## 3. Audio Output from Pi/PC: Line Level, Headphone, Differential

### **Line Level:**
- Standard: ~1 Vrms (consumer), ~1.4 Vrms (pro)
- Use a DAC + op-amp buffer to drive line inputs

### **Headphones:**
- Require more current than line outputs
- Use a dedicated headphone amplifier IC or op-amp buffer

### **Differential Output:**
- Balanced outputs for pro audio, less noise over long cables
- Use op-amp circuits or transformer balancing

### **Typical Output Schematic:**  
- DAC out → simple RC low-pass filter → op-amp buffer → output jack (1/4", RCA, etc.)

---

## 4. DAC Selection and Interfacing: I2S, SPI, Parallel, Audio HATs

### **I2S (Inter-IC Sound):**
- Standard for high-quality audio; many DACs support it
- Raspberry Pi has built-in I2S (requires config)

### **SPI:**
- Simpler protocol, lower bandwidth; good for mono or control voltages (CV)

### **Parallel:**
- Rare now, but extremely fast; used in vintage gear

### **Audio HATs:**  
- Pi "HATs" (Hardware Attached on Top) often include high-quality DACs with I2S input
- Examples: HiFiBerry, IQAudio, JustBoom

### **DAC Selection Criteria:**
- Resolution (bits): 12, 16, 24, 32-bit
- Sample rate: 44.1kHz, 48kHz, or higher
- SNR/THD: Lower noise, less distortion
- Interface compatibility (I2S/SPI)
- Availability and support

---

## 5. Digital-to-Analog Conversion: Resolution, Sample Rate, and Filtering

### **Resolution:**
- Determines dynamic range, noise floor
- 12-bit: Basic, audible quantization noise
- 16-bit: CD quality
- 24-bit: Pro audio, very low noise

### **Sample Rate:**
- Should be at least 2x highest audio frequency (see Nyquist)
- 44.1kHz, 48kHz standard
- Higher rates (96kHz, 192kHz) allow for easier filtering

### **Filtering:**
- **Reconstruction filter** (analog low-pass) required after DAC to remove "images"
- Simple RC or active low-pass (op-amp) often sufficient for DIY

---

## 6. Level Shifting, Buffering, and Impedance Matching

### **Why Buffer?**
- DACs often can't drive headphones or line inputs directly
- Buffer with a unity-gain op-amp circuit

### **Level Shifting:**
- Some DACs output 0–Vref (unipolar); audio is usually centered around 0V (bipolar)
- Use an op-amp circuit to shift voltage center as needed

### **Impedance Matching:**
- Ensures maximal power transfer and minimal distortion
- Audio output: low output impedance (buffered), high input impedance at receiving device

**Op-Amp Buffer Example:**
```c
// Schematic (not C code)
[DAC OUT]--||--[+input op-amp]----[OUT]
//         C1
// C1 blocks DC, op-amp buffers and recenters signal
```

---

## 7. Anti-Imaging and Reconstruction Filters

- Digital audio output via DAC contains images (ultrasonic "copies" of the audio spectrum)
- **Anti-Imaging Filter:**  
  - Analog low-pass filter, cutoff just above audio range (~20kHz)
  - Removes ultrasonic components, prevents aliasing in downstream analog stages

- **Simple RC Filter Calculation:**
  - f_c = 1 / (2πRC)
  - For 20kHz cutoff, R = 1kΩ, C ≈ 8nF

---

## 8. Hands-On: Connecting a Raspberry Pi (or PC) to Analog Circuits

### **A. Using the Pi's Built-In Audio (PWM):**
- Lower quality, but no extra hardware needed
- Enable via raspi-config or config.txt

### **B. Using an I2S DAC (e.g., PCM5102, HiFiBerry):**
1. **Connect DAC to Pi GPIO (I2S pins)**
2. **Enable I2S via config.txt:**
    ```
    dtparam=audio=off
    dtoverlay=hifiberry-dac
    ```
3. **Test with aplay:**
    ```sh
    aplay -D default /usr/share/sounds/alsa/Front_Center.wav
    ```

### **C. PC Audio Output:**
- Use onboard soundcard or USB DAC for prototyping
- 3.5mm line out or USB audio interface

### **D. Output Level/Buffering Circuit:**
- DAC output → RC filter → op-amp buffer → audio jack

---

## 9. Basic Audio Measurements with a Soundcard or Oscilloscope

- **Oscilloscope:** View and verify waveform shape, level, DC offset, and noise
- **Soundcard + Software (Audacity, REW, TrueRTA):**  
  - Measure frequency response, distortion, and noise
  - Record and analyze test signals (sine, square, noise)
- **Multimeter:** Basic DC checks (offset, output swing)

---

## 10. Exercises

1. **Draw a complete block diagram of your planned hybrid synth, including digital and analog sections.**
2. **Choose a DAC for your project. Justify your choice based on bit depth, sample rate, and I2S/SPI interface.**
3. **Design a simple RC output filter for your DAC with a 20kHz cutoff. Calculate R/C values.**
4. **Connect your Pi or PC audio out to an op-amp buffer and measure the output on a scope or PC soundcard.**
5. **Record a digitally generated square wave after passing through your analog filter. Compare to the digital version.**
6. **Research: What are the advantages of balanced (differential) outputs in synth hardware?**

---

**End of Chapter 6, Part 1**  
*Next: Analog filter (VCF) design, interfacing digital control (CV) with analog circuits, and integrating envelopes and LFOs for full hybrid synthesis!*