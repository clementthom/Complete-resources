# Hybrid Synthesizer Course  
## Appendix: Glossary of Key Terms

---

### Analog
A system or signal that varies continuously, as opposed to digital which is discrete. In synths, analog usually refers to circuits using voltages to represent sound and control signals.

---

### CV (Control Voltage)
A continuous voltage (typically 0–5V or ±5V/±12V) used to control parameters in analog synthesizers, such as pitch, filter cutoff, and amplitude.

---

### DAC / ADC
- **DAC (Digital-to-Analog Converter):** Converts digital data into a continuous analog voltage or current.
- **ADC (Analog-to-Digital Converter):** Converts analog signals into digital data for processing by microcontrollers or computers.

---

### Envelope Generator
A circuit or algorithm that produces a time-varying control voltage, typically with Attack, Decay, Sustain, Release (ADSR) stages, to shape the amplitude or timbre of a sound.

---

### Eurorack
A popular modular synthesizer format using 3U-tall modules and standardized power/connector schemes.

---

### Firmware
Software programmed into a microcontroller or digital synth module, controlling its operation and features.

---

### MIDI (Musical Instrument Digital Interface)
A standard protocol for communication between electronic instruments, computers, and controllers.

---

### Oscillator
A circuit or algorithm that generates periodic waveforms (sine, square, sawtooth, triangle) as the basic sound source in a synthesizer.

---

### Patch
A specific configuration of modules, signals, or settings to create a particular sound or effect.

---

### PCB (Printed Circuit Board)
A board used to mechanically support and electrically connect electronic components.

---

### Resonance (Q)
A parameter of filters that emphasizes frequencies near the cutoff frequency, often producing a whistling or ringing sound.

---

### VCA (Voltage Controlled Amplifier)
An amplifier whose gain (output level) is controlled by a voltage input, used to shape the amplitude of audio or CV signals.

---

### VCF (Voltage Controlled Filter)
A filter whose cutoff frequency is controlled by a voltage input.

---

### VCO (Voltage Controlled Oscillator)
An oscillator whose frequency is controlled by a voltage input.

---

### Waveform
The shape of an audio signal in the time domain (e.g., sine, triangle, square, sawtooth).

---

**See the Resources appendix for links to deeper explanations and community glossaries.**