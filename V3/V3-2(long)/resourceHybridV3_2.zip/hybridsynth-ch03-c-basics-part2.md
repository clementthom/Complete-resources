# Hybrid Synthesizer Course  
## Chapter 3, Part 2: C Programming for Embedded Systems — Pointers, Memory, and Structs

---

### Table of Contents

1. Memory Layout and the Stack vs. Heap
2. Pointers: What, Why, and How
3. Arrays and Pointer Arithmetic
4. Dynamic Memory Management with malloc/free
5. Structs: Grouping Data for Synth Voices/Modules
6. Passing Data: By Value vs. By Reference
7. Modular Synthesis in C: Using Structs and Pointers
8. Practical: Dynamic Voice Array for Polyphony
9. Hands-on Coding Examples
10. Exercises

---

## 1. Memory Layout and the Stack vs. Heap

- **Stack:**  
  Fast, small, managed automatically (for local variables, function calls).
- **Heap:**  
  Large, but you must manage it (with `malloc`/`free`). Needed for dynamic or large objects.

**Example:**  
Local variables are on the stack:
```c
void foo() {
    int x = 5; // on the stack
}
```
Dynamic allocation uses the heap:
```c
int* arr = malloc(100 * sizeof(int)); // on the heap
// Don't forget to free(arr) later!
```

---

## 2. Pointers: What, Why, and How

Pointers are variables that store *addresses* of other variables.

### **Declaring and Using Pointers:**
```c
int x = 42;
int* ptr = &x;    // ptr points to x

printf("%d\n", *ptr); // prints 42
```

- `&x` = address of x
- `*ptr` = value pointed to (dereference)

### **Why use pointers?**
- Access and modify data in functions (pass "by reference").
- Work with arrays and dynamic memory.
- Essential for hardware and embedded code (direct memory access).

---

## 3. Arrays and Pointer Arithmetic

Arrays are contiguous blocks of memory.  
Pointers can be used to step through arrays.

```c
float freqs[5] = {110.0, 220.0, 440.0, 880.0, 1760.0};
float* pf = freqs;

for (int i = 0; i < 5; i++) {
    printf("freq[%d]=%f\n", i, *(pf + i));
}
```

- `freqs` is the address of the first element.
- `*(pf + i)` accesses element `i`.

---

## 4. Dynamic Memory Management with malloc/free

For variable-size data (such as a user-settable number of synth voices), use dynamic allocation.

### **Allocating:**
```c
int* buffer = malloc(256 * sizeof(int)); // 256 ints on the heap
if (!buffer) { /* check for allocation failure */ }
```

### **Using:**
```c
buffer[0] = 123;
```

### **Freeing:**
```c
free(buffer);
buffer = NULL;
```

**Always free what you malloc!**

---

## 5. Structs: Grouping Data for Synth Voices/Modules

Structs let you combine related pieces of data.

### **Oscillator struct:**
```c
typedef struct {
    float frequency;
    float phase;
    float duty_cycle;
} Oscillator;
```

### **Voice struct (for polyphony):**
```c
typedef struct {
    Oscillator osc;
    float envelope;
    int is_active;
} Voice;
```

---

## 6. Passing Data: By Value vs. By Reference

By default, C functions receive *copies* of arguments (by value).

### **By Value:**
```c
void set_freq(float freq) {
    freq = 880.0; // only changes local copy
}
```

### **By Reference:**
```c
void set_freq_ptr(float* freq_ptr) {
    *freq_ptr = 880.0; // changes original variable
}

float f = 440.0;
set_freq_ptr(&f); // f is now 880.0
```

**Use pointers for structs to avoid copying large data and to modify in-place.**

---

## 7. Modular Synthesis in C: Using Structs and Pointers

You can model each synth module as a struct, and wire them together with pointers.

**Example:**

```c name=src/voice.h
#ifndef VOICE_H
#define VOICE_H

#include "oscillators.h"

typedef struct {
    Oscillator osc;
    float envelope;
    int is_active;
} Voice;

// Voice functions
void voice_init(Voice* v, OscType type, float freq, float duty);
float voice_process(Voice* v);

#endif // VOICE_H
```

```c name=src/voice.c
#include "voice.h"

void voice_init(Voice* v, OscType type, float freq, float duty) {
    osc_init(&v->osc, type, freq, duty);
    v->envelope = 1.0f; // placeholder
    v->is_active = 0;
}

float voice_process(Voice* v) {
    if (!v->is_active) return 0.0f;
    return osc_process(&v->osc) * v->envelope;
}
```

---

## 8. Practical: Dynamic Voice Array for Polyphony

To support user-selectable polyphony:
- Allocate an array of voices at runtime.
- Process each voice in a loop.
- Turn voices on/off as notes are played.

### **Example:**

```c name=src/main.c
#include <stdio.h>
#include <stdlib.h>
#include "voice.h"

#define MAX_POLYPHONY 16

int main(void) {
    int num_voices = 8;
    Voice* voices = malloc(num_voices * sizeof(Voice));

    // Initialize voices
    for (int i = 0; i < num_voices; i++) {
        voice_init(&voices[i], OSC_SQUARE, 220.0f * (i + 1), 0.5f);
        voices[i].is_active = 1;
    }

    // Process and print first 5 samples of each voice
    for (int i = 0; i < num_voices; i++) {
        printf("Voice %d samples: ", i);
        for (int s = 0; s < 5; s++) {
            float sample = voice_process(&voices[i]);
            printf("%f ", sample);
        }
        printf("\n");
    }

    free(voices); // Don't forget!
    return 0;
}
```

---

## 9. Hands-on Coding Examples

### **Accessing and Modifying Structs via Pointers:**

```c
Voice v;
voice_init(&v, OSC_PULSE, 330.0f, 0.25f);
v.is_active = 1;
float samp = voice_process(&v);
```

### **Array of Structs:**

```c
Voice poly[8];
for (int i = 0; i < 8; i++) {
    voice_init(&poly[i], OSC_SAW, 110.0f * (i + 1), 0.5f);
}
```

### **Dynamic Allocation:**

```c
Voice* voices = malloc(16 * sizeof(Voice));
if (!voices) { printf("Allocation failed!\n"); return 1; }
for (int i = 0; i < 16; i++) {
    voice_init(&voices[i], OSC_TRIANGLE, 55.0f * (i + 1), 0.5f);
}
free(voices);
```

---

## 10. Exercises

1. **Create a struct for an envelope generator** (with attack, decay, sustain, release, current_value, state).
2. **Write an envelope_init and envelope_process function.**
3. **Modify the Voice struct to include your envelope generator; update voice_process to multiply output by env value.**
4. **Allocate an array of 8 envelopes dynamically; initialize and process them in a loop.**
5. **Write a function that takes a pointer to a Voice and toggles its is_active flag.**
6. **Experiment:** Try to process 128 voices—does your PC handle it? What about a Raspberry Pi? (You’ll see why efficient code matters!)

---

**End of Chapter 3, Part 2**  
*Next: Advanced use of pointers, memory management, and error handling in embedded C, and prepping your code for real-time audio!*