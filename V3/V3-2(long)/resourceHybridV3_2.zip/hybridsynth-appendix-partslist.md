# Hybrid Synthesizer Course  
## Appendix: Sample Parts List (BOM)

---

### Core Components

| Part                        | Example/Spec                | Notes                               |
|-----------------------------|-----------------------------|-------------------------------------|
| Microcontroller/CPU         | Teensy 4.1 / Raspberry Pi   | For DSP and control                 |
| DAC (Audio Output)          | PCM5102, CS4344, MCP4922    | I2S or SPI, as required             |
| ADC (CV Input)              | MCP3208, built-in MCU ADC   | For reading pots, CVs               |
| Op-Amps                     | TL072, TL074, NE5532        | Audio buffer, mixer, filter         |
| Voltage Regulators          | 7805, 7812, 1117-3.3        | 5V, 3.3V, 12V as needed             |
| Potentiometers (Pots)       | 10k, 50k, linear/log        | For panel controls                  |
| Switches/Buttons            | SPST, tactile, toggle       | UI and patching                     |
| LEDs                        | 3mm, 5mm, RGB               | Panel indicators                    |
| Rotary Encoder              | EC11, Alps                  | For menu navigation, tuning         |
| OLED/Display                | SSD1306, ILI9341            | For UI, patch info                  |
| Audio Jacks                 | 3.5mm mono/stereo           | In/out, CV, gate                    |
| MIDI Jack                   | 5-pin DIN, TRS              | MIDI input/output                   |
| PCB/Perfboard               | FR4, breadboard             | Prototyping or final build          |
| Enclosure/Panel             | Aluminum, acrylic, 3D print | Custom or off-the-shelf             |

---

### Passive Components

| Part                | Example Value           | Purpose                       |
|---------------------|------------------------|-------------------------------|
| Resistors           | 1k, 10k, 100k, 220k    | Signal path, pull-ups         |
| Capacitors          | 0.1μF, 1μF, 10μF, 100μF| Power filtering, coupling     |
| Trimmers            | 10k, 20k                | Calibration, tuning           |
| Diodes              | 1N4148, 1N4001         | Protection, rectification     |
| Ferrite Beads       | —                      | Noise filtering               |

---

### Optional/Advanced

| Part                  | Example/Spec        | Notes                           |
|-----------------------|---------------------|---------------------------------|
| Analog VCF IC         | SSM2044, AS3320     | Classic analog filter chips     |
| Digital Potentiometer | MCP41010, DS1803    | Patch memory, parameter recall  |
| Motorized Fader       | Alps, Bourns        | Automation, advanced UI         |
| Bluetooth/WiFi Module | ESP32, HC-05        | Wireless control                |
| SD Card Module        | SPI/SDIO            | Patch and sample storage        |
| Relays                | —                   | Audio routing, switching        |

---

### General Tips

- Double-check pinouts and voltage compatibility.
- Choose audio-grade components for front-end analog paths.
- Prototype on breadboard before soldering final boards.
- Order a few extra of each passive for testing and mistakes.

---

**For detailed schematics, part values, and alternatives, see each chapter’s build section.**