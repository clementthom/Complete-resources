# Chapter 10: MIDI and Control Interface

---

## Table of Contents

1. What is MIDI?
2. MIDI Message Types (Note, CC, Program, SysEx)
3. Hardware MIDI (DIN, USB)
4. Software MIDI (Linux ALSA, PortMIDI)
5. Parsing MIDI Messages in C
6. Mapping MIDI to Synth Parameters
7. Building a Simple MIDI Handler
8. Connecting Keyboards and Controllers
9. Interactive Controls (Knobs, Sliders, Touch)
10. Exercises

---

## 1. What is MIDI?

**MIDI (Musical Instrument Digital Interface)**  
- Digital protocol for music gear (keyboards, synths, computers).
- Carries “events” (note on/off, control changes, pitch bend, program changes).

---

## 2. MIDI Message Types

- **Note On/Off:** Key pressed/released.
- **CC (Control Change):** Knobs/sliders (0–127).
- **Program Change:** Change patch.
- **Pitch Bend:** Wheel, joystick.
- **SysEx:** Device-specific settings.

**Data Format:**  
- Each message is 1–3 bytes.
- Example: Note On = 0x90 (status) + note (0–127) + velocity (0–127).

---

## 3. Hardware MIDI

- **DIN-5:** Classic 5-pin round connector, serial at 31250 baud.
- **USB MIDI:** Modern, plug-and-play.

**Circuit Example:**  
- Optocoupler for MIDI IN (see KiCAD schematic for safe interfacing).

---

## 4. Software MIDI

**Linux ALSA:**  
- Handles MIDI devices, routing, software synths.

**PortMIDI:**  
- Cross-platform library for MIDI in C.

**Install:**
```sh
sudo eopkg install portmidi-devel
```

---

## 5. Parsing MIDI Messages in C

**Read bytes from MIDI port, parse by status byte:**

```c name=src/midi.c
#include <portmidi.h>
#include <stdio.h>

void process_midi(PmEvent event) {
    unsigned char status = event.message & 0xFF;
    unsigned char data1 = (event.message >> 8) & 0xFF;
    unsigned char data2 = (event.message >> 16) & 0xFF;
    if ((status & 0xF0) == 0x90 && data2 > 0) {
        printf("Note ON: %d vel %d\n", data1, data2);
    } else if ((status & 0xF0) == 0x80 || ((status & 0xF0) == 0x90 && data2 == 0)) {
        printf("Note OFF: %d\n", data1);
    }
}
```

---

## 6. Mapping MIDI to Synth Parameters

- Note on → allocate voice, set frequency.
- Note off → release envelope.
- CC 1 (mod wheel) → LFO depth.
- CC 7 (volume) → VCA.
- CC 74 (filter) → filter cutoff.

**Mapping table:**  
Define which CC controls which parameter.

---

## 7. Building a Simple MIDI Handler

- Poll for MIDI input.
- Parse message, call synth functions.

**Example:**
```c
void handle_midi_note_on(int note, int velocity) {
    int voice = allocate_voice(voices, NUM_VOICES, note);
    voices[voice].osc.frequency = midi_note_to_freq(note);
    // Trigger envelope, set velocity, etc.
}
```

**MIDI note to frequency:**
```c
float midi_note_to_freq(int note) {
    return 440.0f * powf(2.0f, (note - 69) / 12.0f);
}
```

---

## 8. Connecting Keyboards and Controllers

- Plug USB MIDI controller into PC or Pi.
- Use PortMIDI or ALSA to receive messages.
- For hardware DIN-5 MIDI IN, use optocoupler circuit and Pi UART.

---

## 9. Interactive Controls

- Map hardware controls (knobs, sliders, touch) to synth parameters.
- For Pi: use GPIO or I2C ADC (e.g., MCP3008) to read analog pots/sliders.
- For touch: use resistive/capacitive touch controllers.

---

## 10. Exercises

1. **Parse and print** all incoming MIDI messages from your controller.
2. **Implement MIDI note-on/off** to play voices in your synth.
3. **Map a CC** (e.g., mod wheel) to LFO depth.
4. **Connect a hardware MIDI input** (DIN or USB) to your Pi and test with a keyboard/controller.

---

**Next Chapter:**  
Building the UI: basic controls, graphical/touch interface, LCDs, and real-time parameter feedback.

---