# Chapter 14: Advanced Topics – Effects, FFT, and Future Expansion

---

## Table of Contents

1. Introduction to Digital Effects
2. Effects Architecture: Insert, Send, and Master
3. Implementing Delay and Reverb in C
4. Chorus, Flanger, and Phaser Algorithms
5. Effects Parameter Modulation and Automation
6. FFT (Fast Fourier Transform): Theory and Practice
7. Real-Time Spectrum Analysis
8. Time-Stretching and Pitch-Shifting
9. Expanding the Hardware: Adding New Boards/Modules
10. Software Expansion: Plugin Architecture, Scripting
11. Integrating Third-Party Audio Libraries
12. Optimization for Embedded/Real-Time Systems
13. Exercises

---

## 1. Introduction to Digital Effects

**Digital effects** expand your synth’s sonic palette:

- Delay, reverb, chorus, flanger, phaser, distortion
- Can be implemented in C, processed in real time on Pi

---

## 2. Effects Architecture: Insert, Send, and Master

- **Insert:** Effect is part of voice chain (per-voice chorus, distortion).
- **Send:** Shared effect, voices can send signal to it (reverb, delay).
- **Master:** Effect applied to the final stereo out (EQ, compressor).

**Typical chain:**
```
Oscillator → Envelope → VCF → VCA → FX Insert → FX Send → Master FX → Output
```

---

## 3. Implementing Delay and Reverb in C

**Delay:** Circular buffer with feedback.

```c name=src/effect_delay.c
#define DELAY_BUF_SIZE 48000 // 1 second at 48kHz
float delay_buf[DELAY_BUF_SIZE];
int delay_pos = 0;

float process_delay(float input, float feedback, float mix) {
    float out = delay_buf[delay_pos];
    delay_buf[delay_pos] = input + feedback * out;
    delay_pos = (delay_pos + 1) % DELAY_BUF_SIZE;
    return input * (1.0f - mix) + out * mix;
}
```

**Reverb:** Use an allpass/comb filter network or a simple “schroeder” reverb.

---

## 4. Chorus, Flanger, and Phaser Algorithms

- **Chorus:** Modulate delay time with LFO, mix dry/wet.
- **Flanger:** Very short delay, deep feedback.
- **Phaser:** Allpass filters modulated in series.

**Example:**
```c
float chorus_lfo = sinf(lfo_phase);
float delay_time = base_delay + depth * chorus_lfo; // modulate
```

---

## 5. Effects Parameter Modulation and Automation

- Allow envelopes/LFOs to control effect parameters (e.g., delay feedback, reverb mix).
- Automate effect changes with sequencer or controller.
- Use MIDI CC for live tweaks.

---

## 6. FFT (Fast Fourier Transform): Theory and Practice

**FFT:** Converts time-domain audio to frequency domain.

- Useful for spectrum analysis, pitch detection, advanced effects.
- Use libraries: [KissFFT](https://github.com/mborgerding/kissfft), [FFTW](http://www.fftw.org/).

**Example:**
```c
#include "kiss_fft.h"
kiss_fft_cfg cfg = kiss_fft_alloc(N, 0, 0, 0);
kiss_fft_cpx in[N], out[N];
// Fill in[] with samples
kiss_fft(cfg, in, out);
```

---

## 7. Real-Time Spectrum Analysis

- Compute FFT on output buffer every N samples.
- Display magnitude spectrum on UI (bargraph, waterfall).
- Useful for debugging and visual feedback.

---

## 8. Time-Stretching and Pitch-Shifting

- Use phase vocoder or granular synthesis techniques.
- More advanced, but possible on Pi 4 for basic cases.

**Libraries:** Rubber Band, SoundTouch.

---

## 9. Expanding the Hardware: Adding New Boards/Modules

- Design modular analog/digital boards (e.g., extra VCF, new effects).
- Use I2C/SPI for digital expansion.
- Use analog CV or digital protocols for module-to-module communication.

---

## 10. Software Expansion: Plugin Architecture, Scripting

- Design your synth to load plugins (dynamically loaded .so/.dll modules).
- Embed scripting (Lua, Python) for advanced modulation, sequencing.

---

## 11. Integrating Third-Party Audio Libraries

- Use open-source DSP libraries for effects, synthesis, MIDI, etc.
- Examples: [JUCE](https://juce.com/), [PortAudio](http://www.portaudio.com/), [LV2](https://lv2plug.in/).

---

## 12. Optimization for Embedded/Real-Time Systems

- Profile code for CPU usage, avoid malloc/free in audio callbacks.
- Use fixed-point math for speed if needed.
- Inline critical DSP routines.
- Use NEON/SIMD for accelerating math-heavy code on Pi.

---

## 13. Exercises

1. **Implement a delay effect** and add controls for time, feedback, and mix.
2. **Add a basic FFT visualization** to your UI.
3. **Experiment with chorus/flanger** on your synth output.
4. **Design a modular expansion header** for new boards.
5. **Profile your effects code** and optimize a bottleneck.

---

**Next Chapter:**  
Troubleshooting, maintenance, and upgrades—best practices for keeping your instrument reliable and evolving.

---