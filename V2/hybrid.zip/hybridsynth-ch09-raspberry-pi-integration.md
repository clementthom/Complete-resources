# Chapter 9: Raspberry Pi Integration – Bare Metal, Linux, and DAC Interfacing

---

## Table of Contents

1. Why Raspberry Pi?
2. Pi Hardware Overview (Pi 4, GPIO, I2C, SPI, I2S)
3. Bare Metal vs. Linux: Pros, Cons, and Use Cases
4. Setting Up a Bare-Metal Pi Project
5. C Toolchains for Pi (Cross-compiling)
6. Interfacing with DACs (SPI/I2S)
7. Porting Your Synth Code to Raspberry Pi
8. Linux Audio on Pi (ALSA, PortAudio)
9. Real-Time Audio Constraints on Embedded Linux
10. Debugging and Testing on Raspberry Pi
11. Exercises

---

## 1. Why Raspberry Pi?

- **Affordable and powerful** for audio DSP.
- **GPIO access:** Connect DACs, buttons, displays.
- **Community support:** Tons of tutorials and libraries.
- **Flexible:** Can run bare-metal code or full Linux.

---

## 2. Pi Hardware Overview

- **Pi 4:** Quad-core ARM, 1–8GB RAM.
- **GPIO:** 40 pins for peripherals (SPI, I2C, I2S, UART, PWM).
- **SPI:** Fast serial, great for many DACs (MCP4922, etc.).
- **I2S:** Digital audio protocol, low-jitter, ideal for audio DACs (PCM5102).
- **I2C:** For slow peripherals (keypads, displays).

---

## 3. Bare Metal vs. Linux

**Bare Metal:**
- Maximum control, minimal latency.
- No OS overhead.
- Must write/init everything yourself.

**Linux:**
- Easy access to drivers, multitasking.
- Higher latency, but easier development.

**Recommendation:**  
- Prototype on Linux, move to bare metal for max performance.

---

## 4. Setting Up a Bare-Metal Pi Project

- Use [circle-stdlib](https://github.com/rsta2/circle) or [ultibo](https://ultibo.org/) for C bare-metal support.
- Write linker scripts, boot code, minimal drivers.
- Use SD card to boot your code.

**Example:**
- Build a “blinky” LED project for first test.
- Set up Makefile for cross-compiling (`arm-none-eabi-gcc`).

---

## 5. C Toolchains for Pi (Cross-compiling)

**Install cross-compiler on PC:**
```sh
sudo eopkg install arm-none-eabi-gcc
```
**Build:**
```sh
arm-none-eabi-gcc -mcpu=cortex-a72 -mfpu=neon-fp-armv8 src/main.c -o kernel.img
```
- Copy `kernel.img` to SD card.

---

## 6. Interfacing with DACs (SPI/I2S)

**SPI DAC Example: MCP4922**
- Connect SCK, MOSI, CS to Pi GPIO.
- Use Pi’s SPI hardware.

**I2S DAC Example: PCM5102**
- Connect BCK, LRCK, DIN.
- Use Pi’s I2S controller.

**C Code Example: SPI Write**
```c name=src/dac.c
#include <bcm2835.h>
void setup_spi() {
    bcm2835_spi_begin();
    bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);
    bcm2835_spi_setDataMode(BCM2835_SPI_MODE0);
    bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_64);
}
void send_sample(uint16_t value) {
    char buf[2] = {value >> 8, value & 0xFF};
    bcm2835_spi_transfern(buf, 2);
}
```
- Use [bcm2835 library](http://www.airspayce.com/mikem/bcm2835/) for Pi GPIO/SPI in Linux.

---

## 7. Porting Your Synth Code to Raspberry Pi

- Reuse your C modules (oscillators, envelopes, voices).
- Replace PortAudio with DAC interface.
- Use a main loop to generate and send audio samples at correct rate.

---

## 8. Linux Audio on Pi (ALSA, PortAudio)

**ALSA:**
- Native Linux sound API; works with HDMI, USB, I2S cards.
- Can use PortAudio on top of ALSA for code compatibility.

**Example:**
- Use PortAudio or ALSA API to output synth audio to Pi’s headphone jack or I2S DAC.

---

## 9. Real-Time Audio Constraints on Embedded Linux

- Use low-latency kernel if possible.
- Use `SCHED_FIFO` priority for audio threads.
- Keep buffer sizes small for low latency.
- Avoid malloc/free in audio callback.

---

## 10. Debugging and Testing on Raspberry Pi

- Use serial output for logs.
- Use LEDs for status/error indicators.
- SSH into Pi for remote debugging.
- Use gdbserver for remote C debugging.

---

## 11. Exercises

1. **Blink an LED** with bare-metal code on Pi.
2. **Send a test waveform** to a DAC and view on oscilloscope.
3. **Port your synth code** to Pi and listen via DAC or audio jack.
4. **Measure latency** and test different buffer sizes.

---

**Next Chapter:**  
MIDI and control interface—MIDI basics, parsing, hardware and software MIDI, connecting keyboards and controllers.

---