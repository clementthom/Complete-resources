# Chapter 12: Calibration, Assembly, and First Sound

---

## Table of Contents

1. Pre-Assembly Checklist
2. Mechanical Assembly: Chassis, Panels, and Mounting Boards
3. Power Supply Design and Safety
4. Wiring and Shielding Best Practices
5. Installing and Connecting Analog Boards
6. Installing and Connecting Digital Boards
7. Initial Power-On: What to Check
8. Analog Calibration: Filters, VCAs, and Audio Path
9. Digital Calibration: DAC Output, Sample Rate, and Tuning
10. UI and Control Calibration
11. Debugging First Boot Issues
12. Measuring Noise, Crosstalk, and Frequency Response
13. Recording and Reviewing the First Sound
14. Maintenance and Upgrades
15. Exercises

---

## 1. Pre-Assembly Checklist

Before assembling your hybrid synth, ensure you have:

- All PCBs (analog and digital) tested
- All components (check BOMs)
- Cables, connectors, and mounting hardware
- Power supply, with correct voltages and current ratings
- Tools: screwdrivers, soldering iron, multimeter, oscilloscope (optional)
- Printed schematics and wiring diagrams

---

## 2. Mechanical Assembly: Chassis, Panels, and Mounting Boards

- Use a metal or heavy-duty plastic chassis for shielding and durability.
- Mount PCBs on standoffs; avoid flexing boards.
- Mount LCD/OLED displays and touch panels flush for easy use.
- Secure power supply away from sensitive audio areas.

**Tip:** Use modular panels for easy upgrades/replacement.

---

## 3. Power Supply Design and Safety

- Separate analog and digital power rails if possible.
- Use linear regulators for analog rails to minimize noise.
- Fuse each rail for safety.
- Ensure proper grounding: star ground or ground planes.

**Warning:** Double-check polarity and voltage before power-up!

---

## 4. Wiring and Shielding Best Practices

- Use twisted pair or shielded cable for audio signals.
- Keep analog and digital wires separate.
- Route power and signal wires at right angles to minimize coupling.
- Use ferrite beads and decoupling capacitors for high-frequency filtering.

---

## 5. Installing and Connecting Analog Boards

- Mount VCF, VCA, output boards securely.
- Connect input and output jacks (audio in/out, control voltage).
- Test each board on the bench before full integration.

---

## 6. Installing and Connecting Digital Boards

- Mount Raspberry Pi on standoffs, with heatsink if needed.
- Connect SPI/I2S DACs with short, shielded cables.
- Use ribbon cables or connectors for reliable board-to-board links.

---

## 7. Initial Power-On: What to Check

- Power up with NO chips installed; check rail voltages.
- Power down, install digital chips (Pi, DAC), check again.
- Power up analog boards with no audio input, check for excessive current draw or heating.
- Ensure no smoke, burning smell, or strange noises.

---

## 8. Analog Calibration: Filters, VCAs, and Audio Path

- Apply test signals (sine/square) to analog inputs; measure output on oscilloscope.
- Adjust trimpots for filter cutoff tracking, resonance, and VCA linearity.
- Verify frequency response matches design (e.g., 24dB/oct slope for VCF).

---

## 9. Digital Calibration: DAC Output, Sample Rate, and Tuning

- Output a 440 Hz sine wave, measure with frequency counter or tuner.
- Adjust sample rate/tuning constants in code if needed.
- Match MIDI A440 pitch to analog output exactly.

---

## 10. UI and Control Calibration

- Check all buttons, encoders, touch points for proper registration.
- Verify on-screen values match hardware settings.
- Adjust software debouncing and touch sensitivity as needed.

---

## 11. Debugging First Boot Issues

- If no sound: check DAC output, code running, power rails, and connections.
- If distorted: check analog path, DAC voltage range, op-amp rails.
- If no UI: check display wiring, contrast/brightness, code initialization.

---

## 12. Measuring Noise, Crosstalk, and Frequency Response

- Use oscilloscope or audio measurement tools (REW, Audio Precision, etc.).
- Look for:
    - Hum/buzz (grounding or power supply issue)
    - HF noise (poor decoupling, ground loops)
    - Channel crosstalk (layout/shielding issue)
- Tweak component values or layout if needed.

---

## 13. Recording and Reviewing the First Sound

- Connect output to audio interface or speakers.
- Test all signal paths: oscillators, envelopes, VCF, VCA.
- Record and analyze: is the sound “warm,” clear, and free of digital artifacts?
- Compare to classic synths for reference.

---

## 14. Maintenance and Upgrades

- Keep schematics, code, and calibration notes up to date.
- Design for easy board replacement and firmware updates.
- Document any modifications or fixes for future reference.

---

## 15. Exercises

1. **Write a checklist** for your own synth’s assembly and calibration.
2. **Simulate** filter response in SPICE, then compare to real hardware.
3. **Measure output noise floor** and document results.
4. **Practice troubleshooting:** Intentionally disconnect a component and diagnose it.

---

**Next Chapter:**  
Sound design, presets, and user experience—how to create and manage sounds, save/load patches, and design a workflow musicians will love.

---