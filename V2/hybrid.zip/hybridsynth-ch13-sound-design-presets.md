# Chapter 13: Sound Design, Presets, and User Experience

---

## Table of Contents

1. What is Sound Design?
2. Classic Hybrid Synth Sound Recipes
3. Patch (Preset) System Architecture
4. Parameter Storage: EEPROM, SD Card, or Flash
5. Designing a Patch Management UI
6. Preset Serialization: Saving and Loading in C
7. Creating Preset Banks and Categories
8. User Workflow: Fast Sound Browsing and Editing
9. Sound Naming and Metadata
10. Advanced: Morphing and Randomizing Presets
11. Protecting Against Data Loss
12. Sharing and Importing Presets
13. Exercises

---

## 1. What is Sound Design?

**Sound design** is the art of creating unique timbres, textures, and musical gestures with your synthesizer.

- Involves tweaking oscillators, filters, envelopes, LFOs, effects, and modulation.
- Relies on both technical knowledge and creative experimentation.

---

## 2. Classic Hybrid Synth Sound Recipes

- **PPG Wave:** Wavetable with moving filter, snappy envelopes.
- **Synclavier FM:** Metallic, evolving digital sounds with analog VCA.
- **Emulator III:** Layered samples with analog filtering for warmth.
- **OBX/Matrix-12:** Lush polysynth pads, complex modulation, rich analog filter sweeps.

**Try Recreating These:**
- Brass: Sawtooth, fast attack, moderate filter cutoff, gentle release.
- Bell: Sine/FM, short decay, high resonance.
- Bass: Square/saw, low filter, punchy envelope.

---

## 3. Patch (Preset) System Architecture

- Each patch stores all parameters needed for a sound (osc, env, filter, mod matrix, etc.).
- Data structure in C:

```c name=src/preset.h
#define WAVEFORM_NAME_LEN 16
typedef struct {
    char name[32];
    int waveform;
    float frequency;
    float cutoff;
    float resonance;
    float env_attack, env_decay, env_sustain, env_release;
    float lfo_rate, lfo_depth;
    // ... add more as needed
} Patch;
```

- Keep patch size small for fast save/load.

---

## 4. Parameter Storage: EEPROM, SD Card, or Flash

**Small systems:** Internal EEPROM or Flash (few KB).
**Larger systems:** SD card (many MB/GB).

**For Raspberry Pi:** Use SD card file I/O.

**Example: Save/Load Patch to File**
```c name=src/preset.c
#include "preset.h"
#include <stdio.h>
void save_patch(const Patch* patch, const char* filename) {
    FILE* f = fopen(filename, "wb");
    fwrite(patch, sizeof(Patch), 1, f);
    fclose(f);
}
int load_patch(Patch* patch, const char* filename) {
    FILE* f = fopen(filename, "rb");
    if (!f) return -1;
    fread(patch, sizeof(Patch), 1, f);
    fclose(f);
    return 0;
}
```

---

## 5. Designing a Patch Management UI

- List of patches: scroll, select, load, save, rename, delete.
- Categories: “Bass,” “Pad,” “Lead,” “FX,” etc.
- “Quick Save” function for fast overwrite.
- “Init Patch” for starting from scratch.

---

## 6. Preset Serialization: Saving and Loading in C

- Use binary or simple text format.
- For more advanced systems, use JSON or XML (see [jansson](https://github.com/akheron/jansson) or [tinyxml2](https://github.com/leethomason/tinyxml2)).

**Binary Pros:** Fast, compact.  
**Text Pros:** Human-readable, easier to edit by hand.

---

## 7. Creating Preset Banks and Categories

- Bank = group of patches (e.g., 128 patches per bank).
- Category = tag or folder (e.g., “Bass”).

**Example Directory Structure:**
```
/presets/
    bank1/
        001-analog_bass.pch
        002-digital_pad.pch
    bank2/
        ...
```

---

## 8. User Workflow: Fast Sound Browsing and Editing

- Use rotary encoder or touch gestures to scroll patches.
- “Audition” mode: play sound briefly while browsing.
- Quick copy/paste and compare for A/B testing.
- Easy access to “favorite” or “recent” patches.

---

## 9. Sound Naming and Metadata

**Patch names:** 16–32 chars, stored in Patch struct.
**Metadata:** Author, creation date, tags.

**Example:**
```c
strncpy(patch->name, "Fat Bass", 32);
strncpy(patch->author, "clementthom", 16);
```

---

## 10. Advanced: Morphing and Randomizing Presets

- **Morphing:** Interpolate between two patches’ parameters for new sounds.
- **Randomize:** Set all parameters to random values (with sensible limits).
- **Undo/Redo:** Keep a patch history stack.

**Example:**
```c name=src/preset.c
void morph_patches(const Patch* a, const Patch* b, float t, Patch* out) {
    out->frequency = a->frequency * (1-t) + b->frequency * t;
    // ...repeat for all parameters
}
```

---

## 11. Protecting Against Data Loss

- Save to temporary file and verify before overwriting.
- Add a “confirm overwrite” prompt in UI.
- Use checksums to detect file corruption.

---

## 12. Sharing and Importing Presets

- Allow import/export to USB drive or SD card.
- Use a standard file format for easy sharing (e.g., .pch, .syx for SysEx).

---

## 13. Exercises

1. **Design a Patch struct** for your synth—what parameters must it store?
2. **Write code to save/load** a patch to file on your PC/Pi.
3. **Add a patch browser** to your UI, allowing the user to load/save/rename patches.
4. **Implement morphing/randomize** for at least two parameters.
5. **Create and document** five classic hybrid synth sounds.

---

**Next Chapter:**  
Advanced topics: digital effects, FFT, time-stretching, and integrating new features into your architecture.

---