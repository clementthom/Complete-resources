# Chapter 3: C Programming – From Zero to Embedded (Part 1)

---

## Table of Contents

1. Why C for Embedded Audio?
2. Setting Up Your C Environment
3. Your First C Program
4. Compiling and Running on Linux
5. Anatomy of a C Program
6. Variables, Types, and Operators
7. Control Flow (if, else, loops)
8. Functions and Modularization
9. Pointers and Arrays (Introduction)
10. Your First Modular Synth Code (`oscillators.c`)
11. Exercises

---

## 1. Why C for Embedded Audio?

- **Speed:** C is close to the hardware, so it's very fast.
- **Control:** You manage memory and timing directly.
- **Portability:** C code can run on your PC, Raspberry Pi, or microcontrollers.
- **Industry Standard:** Most synthesizers, audio gear, and embedded devices use C (or C++).

---

## 2. Setting Up Your C Environment

**On Solus Linux:**
- Install GCC (GNU Compiler Collection):
  ```sh
  sudo eopkg install gcc
  ```
- Editor: Use VSCode, Geany, Vim, or your favorite.

**Test with:**
```sh
gcc --version
```
Should print your GCC version.

---

## 3. Your First C Program

Create `src/main.c`:

```c name=src/main.c
#include <stdio.h>

int main() {
    printf("Hello, Hybrid Synth World!\n");
    return 0;
}
```

---

## 4. Compiling and Running on Linux

From the project root:

```sh
gcc src/main.c -o synth
./synth
```

Output:
```
Hello, Hybrid Synth World!
```

---

## 5. Anatomy of a C Program

Key components:

- **Headers:**  
  ```c
  #include <stdio.h>
  ```
  Brings in standard input/output functions.

- **main function:**  
  ```c
  int main() { ... }
  ```
  Entry point for your program.

- **Statements and Expressions:**  
  End with `;`  
  E.g., `int x = 5;`

---

## 6. Variables, Types, and Operators

### Variables

- **int:** Integer
- **float:** Floating-point
- **char:** Character
- **double:** Double-precision float

### Example

```c
int voices = 8;
float freq = 440.0;
char mode = 'A';
```

### Operators

- `+`, `-`, `*`, `/` (math)
- `==`, `!=`, `<`, `>` (comparison)
- `&&`, `||`, `!` (logic)

---

## 7. Control Flow (if, else, loops)

### if, else

```c
if (voices > 8) {
    printf("Too many voices!\n");
} else {
    printf("OK.\n");
}
```

### for loop

```c
for (int i = 0; i < 8; i++) {
    printf("Voice %d\n", i);
}
```

### while loop

```c
int i = 0;
while (i < 8) {
    printf("Voice %d\n", i);
    i++;
}
```

---

## 8. Functions and Modularization

Functions break your code into reusable blocks.

```c
void say_hello() {
    printf("Hello from a function!\n");
}

int add(int a, int b) {
    return a + b;
}

int main() {
    say_hello();
    int sum = add(2, 3);
    printf("2 + 3 = %d\n", sum);
    return 0;
}
```

---

## 9. Pointers and Arrays (Introduction)

Pointers allow you to refer directly to memory.

```c
int value = 10;
int *ptr = &value; // ptr points to value
printf("%d\n", *ptr); // prints 10
```

Arrays hold multiple values:

```c
float freqs[8] = {440.0, 660.0, 880.0, 110.0, 220.0, 330.0, 550.0, 770.0};
for (int i = 0; i < 8; i++) {
    printf("Voice %d freq: %f\n", i, freqs[i]);
}
```

---

## 10. Your First Modular Synth Code

Let’s start a simple oscillator module, split into header and source files:

```c name=src/oscillators.h
#ifndef OSCILLATORS_H
#define OSCILLATORS_H

#define NUM_VOICES 8

void init_oscillators();
float next_sample(int voice, float frequency);

#endif
```

```c name=src/oscillators.c
#include "oscillators.h"
#include <math.h>

static float phase[NUM_VOICES];

void init_oscillators() {
    for (int i = 0; i < NUM_VOICES; i++) {
        phase[i] = 0.0f;
    }
}

float next_sample(int voice, float frequency) {
    float sample = sinf(phase[voice]);
    phase[voice] += 2.0f * 3.14159f * frequency / 48000.0f; // 48kHz sample rate
    if (phase[voice] > 2.0f * 3.14159f) {
        phase[voice] -= 2.0f * 3.14159f;
    }
    return sample;
}
```

---

## 11. Exercises

1. **Write a C program** that prints the frequencies of all 8 voices using an array.
2. **Modify main.c** to call `init_oscillators()` and print the output of `next_sample()` for each voice/frequency.
3. **Experiment:** Change the number of voices and see how the code adapts.

---

**Next Chapter:**  
Part 2 will cover more advanced C (structs, memory management, modularization), and begin integrating audio output to your PC.

---