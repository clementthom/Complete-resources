# Chapter 4: Digital Audio Basics

---

## Table of Contents

1. What is Sound? Analog vs. Digital
2. Fundamentals of Waveforms
3. Sampling Theory and Aliasing
4. Quantization and Bit Depth
5. Digital-to-Analog Conversion (DACs)
6. Audio Sample Rate (Why 44.1kHz? 48kHz? etc.)
7. Audio Buffers and Real-Time Constraints
8. Generating Waveforms in C (Practical)
9. Testing Audio Output with PortAudio
10. Exercises

---

## 1. What is Sound? Analog vs. Digital

**Sound** is a pressure wave transmitted through air.  
**Analog audio** is a continuous signal (voltage) that varies smoothly.  
**Digital audio** represents sound using discrete “samples” — numbers stored in memory.

### Why go digital?

- Flexibility (store, edit, generate)
- Repeatability
- Integration with computers and software
- Polyphony, effects, sequencing

**Hybrid synths** use digital for sound generation, analog for processing (filtering, amplification).

---

## 2. Fundamentals of Waveforms

Basic waveforms:

- **Sine wave:** Pure tone, one frequency.
- **Square wave:** Rich in harmonics, “hollow” sound.
- **Sawtooth wave:** Bright, buzzy, contains all harmonics.
- **Triangle wave:** Softer, strong fundamental, fewer harmonics.

**Waveform shape** is crucial for the character of your instrument.

---

## 3. Sampling Theory and Aliasing

**Sampling** is measuring analog sound at regular intervals.  
- **Sample Rate:** How many times per second you measure (e.g., 44100 Hz = 44,100 times/sec).

**Nyquist Theorem:**  
- To perfectly capture a frequency, you must sample at least twice its frequency (Nyquist rate).
- Max frequency = sample rate / 2

**Aliasing:**  
- If you generate frequencies above Nyquist, they “fold back” and become wrong, unpleasant frequencies.
- Solution: Band-limit your oscillators and/or use anti-aliasing filters.

---

## 4. Quantization and Bit Depth

**Bit Depth:** Number of bits used to store each sample.

- 8-bit: 256 levels (grainy, “lo-fi”)
- 16-bit: 65,536 levels (CD quality)
- 24-bit: 16 million+ levels (pro audio)

**Quantization Error:**  
- Rounding errors when converting from analog to digital.
- More bits = less error = higher fidelity.

---

## 5. Digital-to-Analog Conversion (DACs)

A **DAC** turns digital numbers (samples) into real voltages.  
Examples: MCP4922 (SPI), PCM5102 (I2S).

**Key Concepts:**
- Resolution (bits): 12, 16, 24, etc.
- Sample rate: How fast it can update.
- Output filter: Smooths out the “steps”.

Most synths use a DAC per channel or per voice, followed by an analog low-pass filter ("reconstruction filter").

---

## 6. Audio Sample Rate (Why 44.1kHz? 48kHz? etc.)

- **44.1kHz:** CD, music standard.
- **48kHz:** Video, broadcast.
- **Higher rates:** More headroom but more CPU/memory.

For your project, 44.1kHz or 48kHz is ideal.

---

## 7. Audio Buffers and Real-Time Constraints

- **Buffer:** A chunk of audio samples sent to the DAC (or soundcard) at once.
- **Latency:** Delay between generating and hearing sound (buffer size affects this).
- **Real-Time:** If your code is too slow, sound will glitch (“underrun”).

**Rule:** Always generate output fast enough to keep the buffer full!

---

## 8. Generating Waveforms in C (Practical)

Let’s generate a few basic waveforms in C.

```c name=src/oscillators.c
#include "oscillators.h"
#include <math.h>

#define SAMPLE_RATE 48000.0f
#define TWO_PI 6.2831853f

static float phase[NUM_VOICES];

void init_oscillators() {
    for (int i = 0; i < NUM_VOICES; i++) {
        phase[i] = 0.0f;
    }
}

float next_sine_sample(int voice, float frequency) {
    float sample = sinf(phase[voice]);
    phase[voice] += TWO_PI * frequency / SAMPLE_RATE;
    if (phase[voice] > TWO_PI) phase[voice] -= TWO_PI;
    return sample;
}

float next_square_sample(int voice, float frequency) {
    float sample = (sinf(phase[voice]) >= 0.0f) ? 1.0f : -1.0f;
    phase[voice] += TWO_PI * frequency / SAMPLE_RATE;
    if (phase[voice] > TWO_PI) phase[voice] -= TWO_PI;
    return sample;
}

float next_saw_sample(int voice, float frequency) {
    float value = (phase[voice] / TWO_PI) * 2.0f - 1.0f;
    phase[voice] += TWO_PI * frequency / SAMPLE_RATE;
    if (phase[voice] > TWO_PI) phase[voice] -= TWO_PI;
    return value;
}

float next_triangle_sample(int voice, float frequency) {
    float value = (phase[voice] / TWO_PI) * 2.0f - 1.0f;
    float sample = (value < 0.0f) ? -1.0f + 2.0f * (-value) : 1.0f - 2.0f * (value - 0.5f);
    phase[voice] += TWO_PI * frequency / SAMPLE_RATE;
    if (phase[voice] > TWO_PI) phase[voice] -= TWO_PI;
    return sample;
}
```

---

## 9. Testing Audio Output with PortAudio

PortAudio lets you play sound from your C code on your PC.  
Install:  
```sh
sudo eopkg install portaudio-devel
```

Basic `audioio.c` to play a sine wave:

```c name=src/audioio.c
#include <portaudio.h>
#include <math.h>
#include <stdio.h>
#include "oscillators.h"

#define SAMPLE_RATE 48000
#define FRAMES_PER_BUFFER 64

static float frequency = 440.0f; // A4

static int audio_callback(const void *input, void *output,
                         unsigned long frameCount,
                         const PaStreamCallbackTimeInfo* timeInfo,
                         PaStreamCallbackFlags statusFlags,
                         void *userData) {
    float *out = (float*)output;
    for (unsigned int i = 0; i < frameCount; i++) {
        *out++ = next_sine_sample(0, frequency);
    }
    return paContinue;
}

int main() {
    Pa_Initialize();
    PaStream *stream;
    Pa_OpenDefaultStream(&stream, 0, 1, paFloat32, SAMPLE_RATE, FRAMES_PER_BUFFER, audio_callback, NULL);
    Pa_StartStream(stream);
    printf("Playing 440 Hz sine wave. Press Enter to stop.\n");
    getchar();
    Pa_StopStream(stream);
    Pa_CloseStream(stream);
    Pa_Terminate();
    return 0;
}
```

**To compile:**

```sh
gcc src/audioio.c src/oscillators.c -o audioio -lportaudio -lm
./audioio
```

---

## 10. Exercises

1. **Modify the oscillator code** to play square, saw, or triangle waves instead of sine.
2. **Change the frequency** to sweep from 220 Hz to 880 Hz over time.
3. **Try different sample rates** (44100, 48000, etc.) and listen for artifacts.
4. **Add a second voice** and mix both outputs.

---

**Next Chapter:**  
Analog electronics: creating warm-sounding analog filters, VCAs, and simulating them with KiCAD and SPICE.

---