# Chapter 6: Analog Electronics: Filters, VCAs, and Boards (KiCAD, Simulation)

---

## Table of Contents

1. Analog vs. Digital Processing
2. What is a VCF (Voltage Controlled Filter)?
3. What is a VCA (Voltage Controlled Amplifier)?
4. Famous Analog Circuits (OTA, SSM, CEM, Discrete, etc.)
5. Schematic Capture in KiCAD
6. Simulating Analog Circuits (SPICE)
7. Example: Designing a 24dB/oct Low-Pass VCF
8. Example: Building a Simple VCA
9. Creating PCBs in KiCAD
10. Testing and Debugging Analog Boards
11. Exercises

---

## 1. Analog vs. Digital Processing

- **Analog**: Signal is a voltage, processed by real components (resistors, capacitors, op-amps).
- **Digital**: Signal is numbers, processed by code.
- **Hybrid synths** use digital for oscillators, analog for VCF, VCA, output.

---

## 2. What is a VCF?

**Voltage Controlled Filter**  
Filters (usually low-pass) that can sweep cutoff with a control voltage.

- **24dB/oct (4-pole) ladder filter:** Moog, Roland
- **State-variable filter:** Oberheim/SEM, very flexible

---

## 3. What is a VCA?

**Voltage Controlled Amplifier**  
Amplifies audio, controlled by an envelope or LFO.

Used for shaping the loudness contour of each note.

---

## 4. Famous Analog Circuits

- **OTA (Operational Transconductance Amp):** LM13700, CA3080 (used in many classic synths)
- **SSM2044, CEM3320:** Famous filter chips
- **Discrete:** Transistor ladder, diode ladder (Moog, EMS)
- **VCA ICs:** THAT2180, SSM2164

---

## 5. Schematic Capture in KiCAD

- **KiCAD** is open-source EDA tool for schematics and PCBs.
- Draw your circuit, annotate, assign footprints, prepare for PCB layout.

**Example:**
- Build a simple OTA-based VCF.
- Save as `hardware/analog-filter.sch`.

---

## 6. Simulating Analog Circuits (SPICE)

- **SPICE** simulates circuit behavior.
- KiCAD integrates ngspice for quick simulation.

**Steps:**
1. Add voltage source and output probe to schematic.
2. Choose “Simulate” in KiCAD.
3. Run AC sweep (for filter response) or transient analysis (for envelopes).

---

## 7. Example: Designing a 24dB/oct Low-Pass VCF

- Use 4 cascaded OTA integrators.
- Control cutoff with a CV input.

**Schematic:**  
Save as `hardware/analog-filter.sch.pdf`.

**Simulation:**  
- Sweep cutoff voltage, plot filter response.

---

## 8. Example: Building a Simple VCA

**OTA VCA (LM13700):**
- Audio in → OTA input
- Envelope CV → bias input
- Output → buffer → analog out

Draw and simulate in KiCAD.

---

## 9. Creating PCBs in KiCAD

- After schematic, assign footprints, switch to PCB layout.
- Place parts, route traces, run DRC.
- Export Gerbers for fabrication.

---

## 10. Testing and Debugging Analog Boards

- Breadboard circuits before PCB if possible.
- Use oscilloscope to check signal shape and noise.
- Simulate with SPICE for expected behavior.

---

## 11. Exercises

1. **Draw and simulate** a 12dB/oct state-variable filter in KiCAD.
2. **Simulate** the effect of changing component values on cutoff and resonance.
3. **Design** a simple VCA and test its response to a CV.

---

**Next Chapter:**  
Polyphony, voice management, and hardware emulation.

---