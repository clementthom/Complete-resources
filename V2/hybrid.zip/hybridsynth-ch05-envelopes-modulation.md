# Chapter 5: Envelope Generators and Modulation

---

## Table of Contents

1. What is an Envelope Generator?
2. ADSR Explained (Attack, Decay, Sustain, Release)
3. Implementing Software Envelopes in C
4. LFOs: Low Frequency Oscillators for Modulation
5. Applying Envelopes and LFOs to Oscillators
6. Modulation Routing (Matrix, Hardwired, etc.)
7. Practical: Combining Oscillator, Envelope, and LFO
8. Exercises

---

## 1. What is an Envelope Generator?

An envelope shapes how a parameter (like amplitude or filter cutoff) changes over time—usually in response to a key press.

- **Commonly controls:** Volume (VCA), filter cutoff (VCF), pitch.
- **Stages:** Attack, Decay, Sustain, Release.

---

## 2. ADSR Explained

- **Attack:** Time to rise from 0 to peak
- **Decay:** Time to fall from peak to sustain
- **Sustain:** Level held while key is down
- **Release:** Time to fall to zero after key is released

Graphically:

```
^
|           ____
|          /    \
|         /      \____
|        /            \
|_______/              \________
|  A    D    S      R
```

---

## 3. Implementing Software Envelopes in C

See previous chapter for a simple envelope struct and functions.  
Let’s enhance for more voices and modularity.

**envelopes.h**
```c
#ifndef ENVELOPES_H
#define ENVELOPES_H

typedef enum {
    ENV_IDLE, ENV_ATTACK, ENV_DECAY, ENV_SUSTAIN, ENV_RELEASE
} EnvelopeStage;

typedef struct {
    EnvelopeStage stage;
    float level;
    float attackRate, decayRate, releaseRate;
    float sustainLevel;
} Envelope;

void init_envelope(Envelope* env, float a, float d, float s, float r);
float next_envelope(Envelope* env, int gate);

#endif
```

**main.c (using envelopes)**
```c
#include "oscillators.h"
#include "envelopes.h"

#define NUM_VOICES 8

Oscillator voices[NUM_VOICES];
Envelope envs[NUM_VOICES];

void synth_init() {
    init_oscillators(voices, NUM_VOICES);
    for (int i = 0; i < NUM_VOICES; i++) {
        init_envelope(&envs[i], 0.01f, 0.1f, 0.7f, 0.2f); // fast attack/decay, 0.7 sustain, 0.2 release
    }
}
```

---

## 4. LFOs: Low Frequency Oscillators for Modulation

LFOs modulate parameters slowly (e.g., vibrato, tremolo).

**lfo.h**
```c
#ifndef LFO_H
#define LFO_H

typedef struct {
    float phase;
    float rate;
} LFO;

void init_lfo(LFO* lfo, float rate);
float next_lfo(LFO* lfo);

#endif
```

**lfo.c**
```c
#include "lfo.h"
#include <math.h>

#define LFO_SAMPLE_RATE 48000.0f
#define LFO_TWO_PI 6.2831853f

void init_lfo(LFO* lfo, float rate) {
    lfo->phase = 0.0f;
    lfo->rate = rate;
}

float next_lfo(LFO* lfo) {
    float sample = sinf(lfo->phase);
    lfo->phase += LFO_TWO_PI * lfo->rate / LFO_SAMPLE_RATE;
    if (lfo->phase > LFO_TWO_PI) lfo->phase -= LFO_TWO_PI;
    return sample;
}
```

---

## 5. Applying Envelopes and LFOs to Oscillators

**main.c (voice sample with envelope and LFO)**
```c
float next_voice_sample(Oscillator* osc, Envelope* env, LFO* lfo, int gate) {
    float env_level = next_envelope(env, gate);
    float lfo_mod = next_lfo(lfo);
    float freq_mod = osc->frequency + lfo_mod * 5.0f; // vibrato
    float sample = sinf(osc->phase) * env_level;
    osc->phase += 2.0f * 3.14159f * freq_mod / 48000.0f;
    if (osc->phase > 2.0f * 3.14159f) osc->phase -= 2.0f * 3.14159f;
    return sample;
}
```

---

## 6. Modulation Routing

- **Hardwired:** LFO always modulates pitch, envelope always modulates amplitude.
- **Matrix:** User can route any modulator to any destination (advanced, see later chapters).

---

## 7. Practical: Combining Oscillator, Envelope, and LFO

- Set up arrays of voices, envelopes, and LFOs.
- For each sample, compute output as:
  `output = oscillator * envelope * (1 + LFO)`

---

## 8. Exercises

1. **Experiment:** Change envelope and LFO parameters, listen to how it affects sound.
2. **Implement:** LFO modulation of filter cutoff as well as pitch.
3. **Advanced:** Allow each voice to have its own LFO (polyphonic LFOs).

---

**Next Chapter:**  
Analog electronics: filters, VCAs, and simulating them with KiCAD and SPICE.

---