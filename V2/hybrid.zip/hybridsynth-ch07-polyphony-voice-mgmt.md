# Chapter 7: Polyphony, Voice Management, and Hardware Emulation

---

## Table of Contents

1. What is Polyphony?
2. Voice Allocation Algorithms
3. Managing Voices in Software
4. Hardware Topology Emulation in C
5. Simulating Voice Boards (Like Emulator III)
6. Practical: Implementing a Voice Manager in C
7. Exercises

---

## 1. What is Polyphony?

- **Monophonic:** One note at a time.
- **Polyphonic:** Multiple notes at once (8, 16, 32, …).
- **Hybrid synth:** Each voice is a full chain (oscillator, envelope, VCF, VCA).

---

## 2. Voice Allocation Algorithms

- **Round Robin:** Assign notes to voices in order.
- **Last Note Priority:** Always use the most recent note.
- **Reassign Old:** Steal the oldest or quietest voice.

---

## 3. Managing Voices in Software

- Track state: on/off, note number, frequency, envelope stage.
- Use a struct array for voices.

```c
typedef struct {
    Oscillator osc;
    Envelope env;
    int note;
    int active;
} Voice;

Voice voices[NUM_VOICES];
```

---

## 4. Hardware Topology Emulation in C

- Structure code to reflect real hardware: separate .c/.h for each block (oscillator, envelope, filter, VCA).
- Makes PC-to-Pi porting easier and code clearer.

---

## 5. Simulating Voice Boards (Like Emulator III)

- Each voice can be thought of as a "virtual board," managed in software.
- Actual hardware has separate analog paths—your code should keep each voice's data isolated.

---

## 6. Practical: Implementing a Voice Manager in C

**voice.h**
```c
#ifndef VOICE_H
#define VOICE_H

#include "oscillators.h"
#include "envelopes.h"

typedef struct {
    Oscillator osc;
    Envelope env;
    int note;
    int active;
} Voice;

void init_voices(Voice* voices, int num_voices);
int allocate_voice(Voice* voices, int num_voices, int note);
void release_voice(Voice* voices, int num_voices, int note);

#endif
```

**voice.c**
```c
#include "voice.h"

void init_voices(Voice* voices, int num_voices) {
    for (int i = 0; i < num_voices; i++) {
        voices[i].active = 0;
        voices[i].note = -1;
        init_oscillators(&voices[i].osc, 1);
        init_envelope(&voices[i].env, 0.01f, 0.1f, 0.7f, 0.2f);
    }
}

int allocate_voice(Voice* voices, int num_voices, int note) {
    for (int i = 0; i < num_voices; i++) {
        if (!voices[i].active) {
            voices[i].active = 1;
            voices[i].note = note;
            return i;
        }
    }
    // Steal first voice if all are active
    voices[0].note = note;
    return 0;
}

void release_voice(Voice* voices, int num_voices, int note) {
    for (int i = 0; i < num_voices; i++) {
        if (voices[i].active && voices[i].note == note) {
            voices[i].active = 0;
            voices[i].note = -1;
        }
    }
}
```

---

## 7. Exercises

1. **Implement:** Add voice allocation to your synth—trigger new notes and release them.
2. **Experiment:** Simulate rapid note-on/note-off and print active voice states.
3. **Advanced:** Try round robin, last note priority, or voice stealing.

---

**Next Chapter:**  
Testing on PC: PortAudio, simulations, debugging, and test-driven development for synth code.

---