# Chapter 11: Building the User Interface (UI) – Graphics, Touch, and Real-Time Controls

---

## Table of Contents

1. Introduction: The Role of the UI in Synthesizers
2. UI Inspirations: Synclavier, Fairlight, PPG Realiser
3. Hardware Options for Monochrome/Touch UI
4. LCDs, OLEDs, and Touch Panels: Hardware Integration
5. Display Protocols (SPI, I2C, Parallel, HDMI)
6. UI Code Structure: Model-View-Controller (MVC) for Embedded Systems
7. Drawing Primitives: Lines, Shapes, Fonts in C
8. Building Menus and Parameter Pages
9. Real-Time Parameter Feedback (Knobs, Sliders, Encoders)
10. Handling Touch and Physical Controls
11. Optimizing UI for Real-Time Audio Devices
12. UI State Machine Design
13. Example: Implementing a Basic Parameter Page in C
14. Advanced: Touch Gesture Recognition
15. Testing and Debugging the UI
16. Exercises

---

## 1. Introduction: The Role of the UI in Synthesizers

The user interface (UI) is the bridge between the musician and the instrument.  
In classic workstations and hybrid synths, the UI is often as iconic as the sound engine itself.

- Enables quick sound shaping and performance.
- Provides real-time feedback on parameters, patch names, and system status.
- Inspires creativity with innovative workflows (e.g., Fairlight’s Page R).

---

## 2. UI Inspirations: Synclavier, Fairlight, PPG Realiser

- **Synclavier:** Monochrome CRT, tactile keypad, parameter-driven workflow.
- **Fairlight CMI:** Tablet-style monochrome graphics, stylus/touch, grid sequencer (Page R).
- **PPG Realiser:** Advanced for its time, touch and color graphics, modular visual workflow.

**Key Features to Emulate:**
- Fast parameter access, minimal menu diving.
- Clear, information-rich screen layouts.
- Touch or physical controls with immediate feedback.

---

## 3. Hardware Options for Monochrome/Touch UI

- **Monochrome Graphic LCDs:** e.g., 128x64, 320x240, often SPI or parallel.
- **OLED Displays:** Sharp, fast, high-contrast, often I2C/SPI.
- **Touch Panels:** Resistive (affordable, stylus-friendly) or capacitive (finger, multi-touch).
- **Raspberry Pi HDMI Output:** For advanced graphics, use HDMI displays.
- **Custom Panels:** Combine LCD/OLED with mechanical buttons, rotary encoders, or sliders.

**Tip:** For prototyping, a Pi with HDMI monitor and USB mouse/touchscreen is easiest.

---

## 4. LCDs, OLEDs, and Touch Panels: Hardware Integration

### LCD/OLED Display Wiring

- SPI: MOSI (data), SCK (clock), CS (chip select), RS (register select), RST (reset)
- I2C: SDA (data), SCL (clock)
- Parallel: Many data and control lines, faster but more GPIO required

### Touch Panel Wiring

- **Resistive:** 4 wires (X+, X-, Y+, Y-)
- **Capacitive:** Often I2C/SPI interface, handles touch detection in hardware

**Example:**  
SSD1306 OLED wired to Pi over I2C:
- VCC → 3.3V/5V
- GND → GND
- SDA → Pi SDA
- SCL → Pi SCL

### C Libraries

- For SPI/I2C: [wiringPi](http://wiringpi.com/), [bcm2835](http://www.airspayce.com/mikem/bcm2835/), or Pi’s built-in libraries.
- LCD/OLED drivers: U8g2 (C), Adafruit GFX (C++).

---

## 5. Display Protocols (SPI, I2C, Parallel, HDMI)

| Protocol  | Speed    | Pins | Use Case                  |
|-----------|----------|------|---------------------------|
| SPI       | Fast     | 4-5  | Graphics LCD/OLED         |
| I2C       | Medium   | 2    | Small displays, sensors   |
| Parallel  | Fastest  | 10+  | Large/fast LCDs           |
| HDMI      | Very Fast| N/A  | High-res monitors, Pi     |

**Recommendation:** For Pi, SPI/I2C for embedded displays, HDMI for advanced UI development.

---

## 6. UI Code Structure: Model-View-Controller (MVC) for Embedded Systems

- **Model:** Stores synth and UI state (parameters, patch names, cursor position).
- **View:** Renders graphics based on state.
- **Controller:** Handles input (touch, buttons, encoders).

**Why MVC?**  
- Separation of logic and display makes code maintainable and flexible.

**Example Directory Structure:**

```
src/
├── ui/
│   ├── ui_main.c      # UI state machine & controller
│   ├── ui_draw.c      # Drawing primitives, graphics
│   ├── ui_touch.c     # Touch/physical input handler
│   └── ui.h
```

---

## 7. Drawing Primitives: Lines, Shapes, Fonts in C

Basic drawing functions for monochrome UI:

```c name=src/ui/ui_draw.c
#include "ui.h"

// Framebuffer: 128x64 pixels (example)
uint8_t framebuffer[128 * 8];

void set_pixel(int x, int y) {
    if (x < 0 || x >= 128 || y < 0 || y >= 64) return;
    framebuffer[x + (y / 8) * 128] |= (1 << (y % 8));
}

void draw_line(int x0, int y0, int x1, int y1) {
    // Bresenham's line algorithm
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2;
    while (1) {
        set_pixel(x0, y0);
        if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
```

**Fonts:**  
- Store character bitmaps in arrays.
- Render text by copying glyphs to framebuffer.

---

## 8. Building Menus and Parameter Pages

**State-driven UI:**
- Main menu → parameter page → value edit → save/load
- Store current state/page as an enum

**Example:**

```c name=src/ui/ui_main.c
typedef enum { PAGE_MAIN, PAGE_OSC, PAGE_FILTER, PAGE_ENV, PAGE_SAVE } UiPage;
UiPage current_page = PAGE_MAIN;

void ui_loop() {
    switch (current_page) {
        case PAGE_MAIN:
            draw_main_menu();
            break;
        case PAGE_OSC:
            draw_osc_page();
            break;
        // etc.
    }
}
```

---

## 9. Real-Time Parameter Feedback (Knobs, Sliders, Encoders)

- **Rotary Encoders:** Discrete, infinite rotation, great for parameter changes.
- **Potentiometers:** Direct analog value, use ADC.
- **Sliders:** Like pots, but linear.
- **Touch Sliders:** Use touch panel’s X/Y as continuous controller.

**C code to read an encoder:**

```c name=src/ui/ui_touch.c
// Pseudo code for encoder on GPIO pins A/B
int prev_state = 0, encoder_value = 0;

void update_encoder(int pin_a, int pin_b) {
    int state = (digitalRead(pin_a) << 1) | digitalRead(pin_b);
    if ((prev_state == 0b00 && state == 0b01) ||
        (prev_state == 0b01 && state == 0b11) ||
        (prev_state == 0b11 && state == 0b10) ||
        (prev_state == 0b10 && state == 0b00)) {
        encoder_value++;
    } else if ((prev_state == 0b00 && state == 0b10) ||
               (prev_state == 0b10 && state == 0b11) ||
               (prev_state == 0b11 && state == 0b01) ||
               (prev_state == 0b01 && state == 0b00)) {
        encoder_value--;
    }
    prev_state = state;
}
```

---

## 10. Handling Touch and Physical Controls

- **Touch:** Read X/Y, detect taps, drags, gestures.
- **Physical:** Scan buttons, encoders, sliders at regular intervals (debounce inputs).
- **UI Event Queue:** Use a queue for detected events (button press, knob move, touch event).

**Example Event System:**

```c
typedef enum { EVT_NONE, EVT_TOUCH, EVT_BUTTON, EVT_ENCODER } UiEventType;
typedef struct { UiEventType type; int data1; int data2; } UiEvent;
UiEvent ui_event_queue[16];
int ui_event_head = 0, ui_event_tail = 0;

void post_event(UiEvent evt) {
    ui_event_queue[ui_event_head++] = evt;
    if (ui_event_head >= 16) ui_event_head = 0;
}
```

---

## 11. Optimizing UI for Real-Time Audio Devices

- **Double buffering:** Prepare screen in memory, then update display in one go.
- **Prioritize audio:** Never let UI code block audio processing!
- **Minimal redraws:** Only update changed regions on screen.
- **Avoid malloc/free in UI loop:** Pre-allocate all buffers and structures.

---

## 12. UI State Machine Design

- Use a clear state machine for navigation and editing.
- Track focus/cursor for each page.
- Separate input handling from rendering.

**Example:**

```c
typedef struct {
    UiPage current_page;
    int selected_param;
    int editing;
} UiState;

void ui_process(UiState *state, UiEvent evt) {
    // handle navigation, parameter editing, etc.
}
```

---

## 13. Example: Implementing a Basic Parameter Page in C

```c name=src/ui/ui_main.c
// Assume this runs every 16ms (60Hz UI update)
void draw_osc_page() {
    clear_screen();
    draw_text(0, 0, "Oscillator Params");
    draw_text(0, 16, "Waveform:");
    draw_text(64, 16, get_waveform_name(current_waveform));
    draw_text(0, 32, "Frequency:");
    draw_number(64, 32, current_frequency);
    // ...draw more parameters
    update_screen();
}

void handle_touch(int x, int y) {
    // Simple hit-test for buttons/fields
    if (in_rect(x, y, 0, 16, 128, 16)) {
        // User touched waveform selector, cycle waveform
        current_waveform = (current_waveform + 1) % NUM_WAVEFORMS;
    }
    if (in_rect(x, y, 0, 32, 128, 16)) {
        // User touched frequency, enter edit mode
        editing_frequency = 1;
    }
}
```

---

## 14. Advanced: Touch Gesture Recognition

- **Tap:** Select parameter.
- **Double-tap:** Reset to default.
- **Drag:** Adjust value (slider, XY pad).
- **Long press:** Show help or advanced options.

**Example:**
- Track touch-down, touch-up, time between events for advanced gestures.

---

## 15. Testing and Debugging the UI

- Simulate UI on PC with SDL or a terminal mockup before deploying to hardware display.
- Use screenshots or framebuffer dumps to verify rendering.
- Log all input events for debugging.
- Add a “test mode” page showing every hardware input value.

---

## 16. Exercises

1. **Prototype:** Write C code to update a main menu, oscillator, and envelope page.
2. **Simulate:** Implement a framebuffer and draw basic shapes/menus on PC.
3. **Integrate:** Connect rotary encoder or touch panel to your Pi, read and print values.
4. **Expand:** Add gesture recognition for tap and drag.
5. **Test:** Make a test page that displays all input values in real time.

---

**Next Chapter:**  
Calibration and assembly—final system integration, analog/digital calibration, assembling the instrument, and first sound tests.

---