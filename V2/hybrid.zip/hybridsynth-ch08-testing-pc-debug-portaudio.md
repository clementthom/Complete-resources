# Chapter 8: Testing on PC – PortAudio, Simulations, and Debugging

---

## Table of Contents

1. Why Test on PC First?
2. Introduction to PortAudio
3. Writing Unit Tests for Synth Modules
4. Test-Driven Development Workflow (TDD)
5. Debugging C Code (GDB, Valgrind, printf)
6. Simulating Synth Signal Flow
7. Building a Test Harness in C
8. Visualizing Audio Data (Plots, Waveforms)
9. Examples: Debugging Oscillators, Envelopes, and Voices
10. Exercises

---

## 1. Why Test on PC First?

- **Speed:** PC is faster to compile/run than embedded targets.
- **Tools:** Powerful debuggers and analyzers available.
- **Reliability:** Bugs are easier to find and fix before porting to hardware.
- **Audio Output:** You can hear and visualize your synth output immediately.

---

## 2. Introduction to PortAudio

**PortAudio** is a cross-platform audio I/O library.  
- Lets you play/record sound from C code on Linux, Windows, Mac.
- Used for rapid synth prototyping before moving to Pi/hardware.

**Install on Solus:**
```sh
sudo eopkg install portaudio-devel
```

---

## 3. Writing Unit Tests for Synth Modules

Break code into testable units: oscillators, envelopes, voices.

**Example: Test for Oscillator**
```c name=tests/test_oscillators.c
#include "../src/oscillators.h"
#include <stdio.h>
#include <assert.h>

void test_sine_wave() {
    Oscillator osc;
    osc.frequency = 440.0f;
    osc.phase = 0.0f;
    float sample = next_sine(&osc);
    assert(sample >= -1.0f && sample <= 1.0f);
}

int main() {
    test_sine_wave();
    printf("Oscillator tests passed!\n");
    return 0;
}
```
Compile and run:
```sh
gcc tests/test_oscillators.c src/oscillators.c -o test_osc -lm
./test_osc
```

---

## 4. Test-Driven Development Workflow (TDD)

- **Red:** Write a test for new functionality (it should fail).
- **Green:** Implement code to pass the test.
- **Refactor:** Clean up code, rerun tests.

This ensures your code works as intended and avoids regressions.

---

## 5. Debugging C Code (GDB, Valgrind, printf)

**GDB (GNU Debugger):**
- Debug line-by-line, inspect variables.
```sh
gcc -g src/main.c -o synth
gdb ./synth
```
- Common commands: `break`, `next`, `print`, `continue`, `quit`.

**Valgrind (Memory Leak Checker):**
```sh
valgrind ./synth
```
- Detect invalid memory use, leaks.

**printf Debugging:**
- Insert `printf("value: %f\n", var);` to trace execution.

---

## 6. Simulating Synth Signal Flow

Write C functions to simulate and log the signal:

```c
float test_signal_flow(Oscillator* osc, Envelope* env, int gate) {
    float env_value = next_envelope(env, gate);
    float sample = next_sine(osc) * env_value;
    printf("%f\n", sample);
    return sample;
}
```
- Output waveforms to CSV for plotting in Python/Excel.

---

## 7. Building a Test Harness in C

Build a main loop that generates N samples and writes them to a file:

```c name=tests/test_signal_flow.c
#include "../src/oscillators.h"
#include "../src/envelopes.h"
#include <stdio.h>

int main() {
    Oscillator osc = {440.0f, 0.0f};
    Envelope env;
    init_envelope(&env, 0.01f, 0.1f, 0.7f, 0.2f);
    int gate = 1;
    FILE* f = fopen("output.csv", "w");
    for (int i = 0; i < 48000; i++) {
        float env_val = next_envelope(&env, gate);
        float sample = next_sine(&osc) * env_val;
        fprintf(f, "%f\n", sample);
        if (i == 24000) gate = 0; // release at halfway
    }
    fclose(f);
    return 0;
}
```
Plot `output.csv` in Python or a spreadsheet to see your envelope.

---

## 8. Visualizing Audio Data (Plots, Waveforms)

**Python Example:**
```python
import matplotlib.pyplot as plt
data = [float(line.strip()) for line in open("output.csv")]
plt.plot(data)
plt.title("Synth Output")
plt.show()
```

**Audacity:**  
- Drag and drop `output.csv` (rename to `.txt` if needed) to view as a waveform.

---

## 9. Examples: Debugging Oscillators, Envelopes, and Voices

- Use unit tests to check oscillator range (always -1 to 1?).
- Print envelope values to ensure correct attack/decay/sustain/release.
- Test voice allocation: simulate many note-ons/note-offs and print voice states.
- Use PortAudio to listen for clicks, pops, or distortion.

---

## 10. Exercises

1. **Write a unit test** for your envelope generator (attack goes to 1.0, sustain holds, release falls to 0).
2. **Generate and plot** a 1-second sine wave at 440 Hz and a square wave at 220 Hz.
3. **Test audio output** for multiple voices, mixing their output.
4. **Simulate a bug:** Intentionally set phase increment wrong, listen and debug the result.

---

**Next Chapter:**  
Raspberry Pi integration—bare metal and Linux audio, interfacing with I2S/SPI DACs, and porting from PC to embedded.

---