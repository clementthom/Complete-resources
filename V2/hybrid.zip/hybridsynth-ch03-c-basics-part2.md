# Chapter 3: C Programming – From Zero to Embedded (Part 2)

---

## Table of Contents

12. Structs and Data Organization
13. Dynamic Memory and malloc/free
14. Modularization: Multiple Files and Headers
15. Building with Makefiles
16. Practical: Arrays of Voices and Parameters
17. Envelopes in C (Simple ADSR Example)
18. Debugging and Printing Values
19. Exercises

---

## 12. Structs and Data Organization

**Structs** group related data into a single unit.

```c
typedef struct {
    float frequency;
    float phase;
} Oscillator;

Oscillator osc;
osc.frequency = 440.0;
osc.phase = 0.0;
```

You can create an array of structs for polyphony:

```c
Oscillator voices[8];
for (int i = 0; i < 8; i++) {
    voices[i].frequency = 220.0 + i * 110.0;
    voices[i].phase = 0.0f;
}
```

---

## 13. Dynamic Memory and malloc/free

Dynamic allocation lets you create arrays at runtime:

```c
int num_voices = 8;
Oscillator* voices = malloc(num_voices * sizeof(Oscillator));
if (!voices) {
    // handle error
}
free(voices); // when done
```

**Rule:** Always `free()` what you `malloc()`!

---

## 14. Modularization: Multiple Files and Headers

Split large programs into `.c` and `.h` files.

Example:  
**oscillators.h**
```c
#ifndef OSCILLATORS_H
#define OSCILLATORS_H

typedef struct {
    float frequency;
    float phase;
} Oscillator;

void init_oscillators(Oscillator* voices, int num_voices);
float next_sine(Oscillator* voice);

#endif
```

**oscillators.c**
```c
#include "oscillators.h"
#include <math.h>

void init_oscillators(Oscillator* voices, int num_voices) {
    for (int i = 0; i < num_voices; i++) {
        voices[i].frequency = 440.0f;
        voices[i].phase = 0.0f;
    }
}

float next_sine(Oscillator* voice) {
    float sample = sinf(voice->phase);
    voice->phase += 2.0f * 3.14159f * voice->frequency / 48000.0f;
    if (voice->phase > 2.0f * 3.14159f) voice->phase -= 2.0f * 3.14159f;
    return sample;
}
```

---

## 15. Building with Makefiles

A **Makefile** automates builds.

**Makefile**
```makefile
CC = gcc
CFLAGS = -Wall -g
OBJS = src/main.o src/oscillators.o

all: synth

synth: $(OBJS)
	$(CC) $(CFLAGS) -o synth $(OBJS) -lm

src/%.o: src/%.c
	$(CC) $(CFLAGS) -c $< -o $@

clean:
	rm -f $(OBJS) synth
```

Build with:
```sh
make
```

Clean with:
```sh
make clean
```

---

## 16. Practical: Arrays of Voices and Parameters

**main.c**
```c
#include <stdio.h>
#include "oscillators.h"

#define NUM_VOICES 8

int main() {
    Oscillator voices[NUM_VOICES];
    init_oscillators(voices, NUM_VOICES);
    for (int i = 0; i < NUM_VOICES; i++) {
        voices[i].frequency = 220.0f + 110.0f * i;
    }
    for (int i = 0; i < NUM_VOICES; i++) {
        float sample = next_sine(&voices[i]);
        printf("Voice %d, sample: %f\n", i, sample);
    }
    return 0;
}
```

---

## 17. Envelopes in C (Simple ADSR Example)

An **ADSR envelope** has four stages: Attack, Decay, Sustain, Release.

**envelopes.h**
```c
#ifndef ENVELOPES_H
#define ENVELOPES_H

typedef enum {
    ENV_IDLE, ENV_ATTACK, ENV_DECAY, ENV_SUSTAIN, ENV_RELEASE
} EnvelopeStage;

typedef struct {
    EnvelopeStage stage;
    float level;
    float attackRate, decayRate, releaseRate;
    float sustainLevel;
} Envelope;

void init_envelope(Envelope* env, float a, float d, float s, float r);
float next_envelope(Envelope* env, int gate);

#endif
```

**envelopes.c**
```c
#include "envelopes.h"

void init_envelope(Envelope* env, float a, float d, float s, float r) {
    env->stage = ENV_IDLE;
    env->level = 0.0f;
    env->attackRate = a;
    env->decayRate = d;
    env->sustainLevel = s;
    env->releaseRate = r;
}

float next_envelope(Envelope* env, int gate) {
    switch(env->stage) {
        case ENV_IDLE:
            if (gate) env->stage = ENV_ATTACK;
            break;
        case ENV_ATTACK:
            env->level += env->attackRate;
            if (env->level >= 1.0f) {
                env->level = 1.0f;
                env->stage = ENV_DECAY;
            }
            break;
        case ENV_DECAY:
            env->level -= env->decayRate;
            if (env->level <= env->sustainLevel) {
                env->level = env->sustainLevel;
                env->stage = ENV_SUSTAIN;
            }
            break;
        case ENV_SUSTAIN:
            if (!gate) env->stage = ENV_RELEASE;
            break;
        case ENV_RELEASE:
            env->level -= env->releaseRate;
            if (env->level <= 0.0f) {
                env->level = 0.0f;
                env->stage = ENV_IDLE;
            }
            break;
    }
    return env->level;
}
```

---

## 18. Debugging and Printing Values

**Use printf() to debug:**
```c
printf("Envelope level: %f\n", env.level);
```

**Compile with debugging info:**
```sh
gcc -g src/main.c src/oscillators.c src/envelopes.c -o synth -lm
```

**Use gdb for debugging:**
```sh
gdb ./synth
```

---

## 19. Exercises

1. **Add an Envelope:**  
   Integrate `Envelope` structs into each voice.  
   Trigger the envelope with a `gate` variable and print levels.

2. **Try Different Envelope Rates:**  
   Experiment with attack, decay, sustain, and release settings.

3. **Write a Function:**  
   That combines oscillator and envelope: `float next_voice_sample(Oscillator*, Envelope*, int gate);`

---

**Next Chapter:**  
Digital audio basics, waveforms, sample rate, aliasing, DACs, and generating/test playing sound.

---