# Chapter 2: Project Management, Git, and Directory Structure

---

## Table of Contents

1. Introduction
2. Why Project Management?
3. Directory Structure: Best Practices
4. Using Git: Concepts and Commands
5. Using GitHub: Collaboration and Issues
6. README.md: Documentation as Code
7. Licensing and Open Source
8. Setting Up Your Hybrid Synth Project
9. Exercises

---

## 1. Introduction

Before any code or circuits, effective project management is crucial.  
You’ll learn how to organize code, collaborate, and maintain your project—skills essential for any complex engineering project.

---

## 2. Why Project Management?

- **Clarity:** Know what you’re building and what stage you're at.
- **Collaboration:** Work with others (or your future self) more easily.
- **Maintainability:** Code and hardware are easy to improve and fix.
- **Reproducibility:** Others can build your project.

---

## 3. Directory Structure: Best Practices

A well-structured project has clear separation of concerns.  
Here’s a breakdown for this project:

```
hybrid-synth/
├── README.md
├── LICENSE
├── src/                # All C source code
│   ├── main.c
│   ├── oscillators.c
│   ├── oscillators.h
│   ├── envelopes.c
│   ├── envelopes.h
│   └── ...             # More modules
├── include/            # Shared headers (optional for larger projects)
├── hardware/           # Schematics, PCB, and BOM
│   ├── analog-filter.sch.pdf
│   ├── dac-board.sch.pdf
│   └── bill-of-materials.md
├── tests/              # Automated and manual test code
│   ├── test_oscillators.c
│   └── test_filters.c
├── docs/               # Additional documentation
│   └── architecture.md
└── .gitignore          # Files to ignore in git
```

### Why modular C files?

Each sound engine component gets its own `.c`/`.h` files.  
Example: `oscillators.c` for all digital oscillator code.

---

## 4. Using Git: Concepts and Commands

**Git** is a version control system.

### Key Concepts

- **Repository (repo):** A folder tracked by git.
- **Commit:** A snapshot of your files.
- **Branch:** A parallel version of your project.
- **Merge:** Combine branches.
- **Remote:** A copy of your repo on another machine (e.g., GitHub).

### Basic Commands

```sh
git init                              # Start a new git repo
git status                            # See file changes
git add <file>                        # Stage a file for commit
git commit -m "Message"               # Commit staged files
git log                               # Show commit history
git branch <branch-name>              # Create a branch
git checkout <branch-name>            # Switch branches
git merge <branch-name>               # Merge into current branch
git remote add origin <url>           # Add remote (e.g., GitHub)
git push -u origin master             # Push to GitHub
git pull                              # Update from remote
```

---

## 5. Using GitHub: Collaboration and Issues

**GitHub** hosts your git repo online.  
You can:

- **Push/Pull:** Upload/download your code.
- **Issues:** Track bugs, features, tasks (like a to-do list).
- **Pull Requests:** Propose changes for review.
- **Wiki/Docs:** Host documentation.
- **Actions:** Automate testing/builds.

### Example: Creating an Issue

On GitHub, click the “Issues” tab, then “New Issue.”  
Describe a bug or feature, assign it if working with others.

---

## 6. README.md: Documentation as Code

A `README.md` is your project’s home page.

### Example

```markdown name=README.md
# Hybrid Synthesizer

A hybrid digital/analog synthesizer inspired by the Synclavier, Emulator III, PPG, and more.

## Features

- Digital oscillators via Raspberry Pi 4 + DACs
- Analog filter and VCA boards
- 8-stereo (16-mono) polyphony
- Modular C codebase
- PC simulation (PortAudio)
- Expandable to workstation/sequencer

## Getting Started

- Clone this repo
- See `src/` for code, `hardware/` for schematics
- Build with `make`, run on PC or Raspberry Pi

## License

MIT (see LICENSE)
```

---

## 7. Licensing and Open Source

**Why license?**  
- Protects your work
- Lets others know how they can use/contribute

### Common licenses

- **MIT:** Very permissive, allows commercial use.
- **GPLv3:** Requires derived works to also be open source.
- **Apache 2.0:** Like MIT, but with patent protection.

**To add a license:**

- Copy the text from [choosealicense.com](https://choosealicense.com/)
- Save as `LICENSE` in the project root.

---

## 8. Setting Up Your Hybrid Synth Project

1. **Clone or create your repo.**
2. **Add a .gitignore** for build files, OS junk:

```gitignore name=.gitignore
*.o
*.out
*.swp
*~
build/
```

3. **Commit your directory skeleton and README.**
4. **Push to GitHub.**

---

## 9. Exercises

1. **Create a new GitHub repo** called `hybrid-synth`.
2. **Set up the directory structure** above, create and commit empty files.
3. **Write a README.md** describing your project's vision.
4. **Add an Issue** for the first milestone: "Implement digital oscillators."
5. **Choose a license** and add it as `LICENSE`.

---

**Next Chapter:**  
Learn C programming from scratch, with an emphasis on embedded and real-time audio applications!

---